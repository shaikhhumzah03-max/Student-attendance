# Presentation-II: SQL Queries, Relational Algebra, and Viva Solutions
## Topic #26: Student Attendance and Leave Approval System
**Learner:** Shaikh Humzah (Roll No: 25WU0102251) · AIML Whales

---

## 1. Presentation-II Evaluated Viva Query

### Problem Statement:
> *"Retrieve the complete attendance profile of students in Section 'AIML-A (Whales)' who have an attendance percentage below 75.0% in the course 'Database Management Systems'. For each student, compute the total sessions conducted, sessions attended, unexcused absences, and the minimum number of consecutive upcoming classes they must attend to restore their eligibility to $\ge 75\%$."*

### SQL Query:
```sql
SELECT 
    s.student_id,
    s.roll_no,
    s.full_name,
    c.course_code,
    c.course_name,
    COUNT(a.attendance_id) AS total_conducted,
    SUM(CASE WHEN a.status IN ('Present', 'Late') THEN 1 ELSE 0 END) AS attended_sessions,
    SUM(CASE WHEN a.status = 'Absent' THEN 1 ELSE 0 END) AS absent_sessions,
    ROUND(
        (SUM(CASE WHEN a.status IN ('Present', 'Late') THEN 1.0 ELSE 0.0 END) * 100.0) / COUNT(a.attendance_id), 
        2
    ) AS current_percentage,
    -- Formula: To reach 75%, (attended + x) / (total + x) >= 0.75 => x >= (0.75 * total - attended) / (1 - 0.75)
    CAST(
        CEIL(
            (0.75 * COUNT(a.attendance_id) - SUM(CASE WHEN a.status IN ('Present', 'Late') THEN 1.0 ELSE 0.0 END)) 
            / (1.0 - 0.75)
        ) AS UNSIGNED
    ) AS consecutive_classes_needed
FROM students s
JOIN sections sec ON s.section_id = sec.section_id
JOIN courses c ON sec.course_id = c.course_id
JOIN class_sessions cs ON cs.section_id = sec.section_id
LEFT JOIN attendance a ON a.session_id = cs.session_id AND a.student_id = s.student_id
WHERE sec.section_name = 'AIML-A (Whales)' AND c.course_code = 'CS301'
GROUP BY s.student_id, c.course_id
HAVING current_percentage < 75.00
ORDER BY current_percentage ASC;
```

### Relational Algebra Representation:
$$\sigma_{\text{current\_pct} < 75} \left( \gamma_{\text{s.student\_id}, \text{c.course\_id}, \text{COUNT}(a) \to \text{total}, \text{SUM}(...) \to \text{attended}} \left( \sigma_{\text{section\_name} = 'AIML-A' \wedge \text{code} = 'CS301'} (Students \bowtie Sections \bowtie Courses \bowtie Sessions \bowtie Attendance) \right) \right)$$

### Sample Query Output:
| student_id | roll_no | full_name | course_code | total_conducted | attended_sessions | absent_sessions | current_percentage | consecutive_classes_needed |
|---|---|---|---|---|---|---|---|---|
| 15 | 25WU0102254 | Shaurya Dhingra | CS301 | 10 | 5 | 5 | 50.00% | 10 |
| 7 | 25WU0102250 | Shaik Abdul Raheem | CS301 | 10 | 6 | 4 | 60.00% | 6 |
| 11 | 25WU0102249 | Settipalli Satwik Siva Sai | CS301 | 10 | 6 | 4 | 60.00% | 6 |

---

## 2. Advanced Multi-Table Joins & Aggregations

### Query 2: Course-Wise Overall Attendance Health Overview
```sql
SELECT 
    c.course_code,
    c.course_name,
    d.dept_code,
    COUNT(DISTINCT cs.session_id) AS sessions_held,
    COUNT(DISTINCT s.student_id) AS enrolled_students,
    ROUND(
        (SUM(CASE WHEN a.status IN ('Present', 'Late') THEN 1.0 ELSE 0.0 END) * 100.0) / COUNT(a.attendance_id),
        2
    ) AS average_attendance_rate
FROM courses c
JOIN departments d ON c.department_id = d.department_id
JOIN sections sec ON sec.course_id = c.course_id
JOIN students s ON s.section_id = sec.section_id
JOIN class_sessions cs ON cs.section_id = sec.section_id
JOIN attendance a ON a.session_id = cs.session_id AND a.student_id = s.student_id
GROUP BY c.course_id
ORDER BY average_attendance_rate DESC;
```

---

## 3. Nested Subqueries & Correlated Analysis

### Query 3: Identify Students Who Have Taken Medical Leave but Still Have Critical Attendance Shortage
```sql
SELECT 
    s.roll_no,
    s.full_name,
    sec.section_name,
    la.start_date,
    la.end_date,
    la.reason,
    sa.attendance_percentage,
    sa.alert_level
FROM students s
JOIN sections sec ON s.section_id = sec.section_id
JOIN leave_applications la ON s.student_id = la.student_id
JOIN shortage_alerts sa ON s.student_id = sa.student_id
WHERE la.leave_type_id = (SELECT leave_type_id FROM leave_types WHERE type_name = 'Medical Leave')
  AND sa.alert_level IN ('Critical', 'Debarred')
  AND sa.is_resolved = 0;
```

---

## 4. Faculty Leave Review Audit with Correlated Counts
```sql
SELECT 
    f.faculty_id,
    f.full_name AS faculty_name,
    f.designation,
    COUNT(appr.approval_id) AS total_reviews_conducted,
    SUM(CASE WHEN appr.status = 'Approved' THEN 1 ELSE 0 END) AS approved_count,
    SUM(CASE WHEN appr.status = 'Rejected' THEN 1 ELSE 0 END) AS rejected_count
FROM faculty f
JOIN leave_approvals appr ON f.faculty_id = appr.reviewed_by_faculty_id
GROUP BY f.faculty_id
ORDER BY total_reviews_conducted DESC;
```
