# Presentation-II: Conceptual & Logical Relational Schema
## Entity-Relationship (ER) Diagram Specification
### Topic #26: Student Attendance and Leave Approval System
**Learner:** Shaikh Humzah (Roll No: 25WU0102251) · AIML Whales

---

## 1. Mermaid Entity-Relationship Diagram

```mermaid
erDiagram
    DEPARTMENTS ||--o{ FACULTY : employs
    DEPARTMENTS ||--o{ COURSES : offers
    FACULTY ||--o{ SECTIONS : instructs
    COURSES ||--o{ SECTIONS : divides_into
    SECTIONS ||--o{ STUDENTS : contains
    SECTIONS ||--o{ CLASS_SESSIONS : holds
    FACULTY ||--o{ CLASS_SESSIONS : conducts
    STUDENTS ||--o{ ATTENDANCE : logs
    CLASS_SESSIONS ||--o{ ATTENDANCE : records
    LEAVE_TYPES ||--o{ LEAVE_APPLICATIONS : categorizes
    STUDENTS ||--o{ LEAVE_APPLICATIONS : submits
    LEAVE_APPLICATIONS ||--o| LEAVE_APPROVALS : generates
    FACULTY ||--o{ LEAVE_APPROVALS : reviews
    CLASS_SESSIONS ||--o{ MAKEUP_SESSIONS : compensates
    SECTIONS ||--o{ MAKEUP_SESSIONS : schedules
    FACULTY ||--o{ MAKEUP_SESSIONS : leads
    STUDENTS ||--o{ SHORTAGE_ALERTS : incurs
    COURSES ||--o{ SHORTAGE_ALERTS : monitors

    DEPARTMENTS {
        int department_id PK
        string dept_name
        string dept_code UK
    }

    FACULTY {
        int faculty_id PK
        string full_name
        string email UK
        string phone
        int department_id FK
        string designation
    }

    COURSES {
        int course_id PK
        string course_code UK
        string course_name
        int credits
        int department_id FK
        int semester
    }

    SECTIONS {
        int section_id PK
        string section_name
        int course_id FK
        int faculty_id FK
        string academic_year
        int semester
    }

    STUDENTS {
        int student_id PK
        string roll_no UK
        string full_name
        string email UK
        string phone
        int section_id FK
        int semester
        int admission_year
    }

    CLASS_SESSIONS {
        int session_id PK
        int section_id FK
        int faculty_id FK
        date session_date
        string time_slot
        string room_no
        string topic_covered
        string status
    }

    ATTENDANCE {
        int attendance_id PK
        int session_id FK
        int student_id FK
        string status
        timestamp marked_at
        string remarks
    }

    LEAVE_TYPES {
        int leave_type_id PK
        string type_name UK
        int max_days_allowed
        string description
    }

    LEAVE_APPLICATIONS {
        int application_id PK
        int student_id FK
        int leave_type_id FK
        date start_date
        date end_date
        string reason
        date applied_date
        string status
    }

    LEAVE_APPROVALS {
        int approval_id PK
        int application_id FK
        int reviewed_by_faculty_id FK
        date decision_date
        string status
        string comments
    }

    MAKEUP_SESSIONS {
        int makeup_id PK
        int original_session_id FK
        int section_id FK
        int faculty_id FK
        date scheduled_date
        string time_slot
        string reason
        string status
    }

    SHORTAGE_ALERTS {
        int alert_id PK
        int student_id FK
        int course_id FK
        float attendance_percentage
        string alert_level
        date generated_date
        int is_resolved
    }
```

---

## 2. Normalization to Third Normal Form (3NF)

### First Normal Form (1NF)
- All attributes are atomic (indivisible scalars).
- No repeating groups or multivalued columns (e.g., student phone numbers and remarks are atomic, and attendance records are stored as individual rows rather than arrays).
- Each table has a defined primary key.

### Second Normal Form (2NF)
- Satisfies 1NF.
- No partial dependencies exist: in all tables with composite candidate keys (such as `attendance(session_id, student_id)`), every non-key attribute (`status`, `marked_at`, `remarks`) is fully functionally dependent on the entire composite key.
- Separated entities into distinct relations: `students`, `courses`, `sections`, `class_sessions`.

### Third Normal Form (3NF)
- Satisfies 2NF.
- No transitive functional dependencies ($X \to Y$ and $Y \to Z$ where $X$ is primary key and $Y$ is not a superkey).
- Department information (`dept_name`, `dept_code`) is isolated in `departments`, rather than transitively dependent through `faculty` or `courses`.
- Faculty details (`full_name`, `designation`) are referenced via `faculty_id`, avoiding duplication across sessions.
- Leave approval audit (`reviewed_by_faculty_id`, `decision_date`, `comments`) is decoupled into `leave_approvals` with a 1-to-1 foreign key to `leave_applications`.
