-- ==============================================================================
-- DATABASE MANAGEMENT SYSTEMS (DBMS) COURSE PROJECT
-- Topic #26: Student Attendance and Leave Approval System
-- Student: Shaikh Humzah (Roll No: 25WU0102251) - AIML Whales
-- Database Dialect: MySQL 8.0+ / MariaDB / Relational Standards
-- ==============================================================================

DROP DATABASE IF EXISTS student_attendance_db;
CREATE DATABASE student_attendance_db CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE student_attendance_db;

-- -----------------------------------------------------------------------------
-- 1. Table: departments
-- -----------------------------------------------------------------------------
CREATE TABLE departments (
    department_id INT AUTO_INCREMENT PRIMARY KEY,
    dept_name VARCHAR(100) NOT NULL UNIQUE,
    dept_code VARCHAR(20) NOT NULL UNIQUE
) ENGINE=InnoDB;

-- -----------------------------------------------------------------------------
-- 2. Table: faculty
-- -----------------------------------------------------------------------------
CREATE TABLE faculty (
    faculty_id INT AUTO_INCREMENT PRIMARY KEY,
    full_name VARCHAR(100) NOT NULL,
    email VARCHAR(100) NOT NULL UNIQUE,
    phone VARCHAR(25),
    department_id INT NOT NULL,
    designation VARCHAR(60) NOT NULL,
    CONSTRAINT fk_faculty_department 
        FOREIGN KEY (department_id) REFERENCES departments(department_id) 
        ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB;

-- -----------------------------------------------------------------------------
-- 3. Table: courses
-- -----------------------------------------------------------------------------
CREATE TABLE courses (
    course_id INT AUTO_INCREMENT PRIMARY KEY,
    course_code VARCHAR(20) NOT NULL UNIQUE,
    course_name VARCHAR(120) NOT NULL,
    credits INT NOT NULL CHECK (credits > 0),
    department_id INT NOT NULL,
    semester INT NOT NULL CHECK (semester BETWEEN 1 AND 8),
    CONSTRAINT fk_courses_department 
        FOREIGN KEY (department_id) REFERENCES departments(department_id) 
        ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB;

-- -----------------------------------------------------------------------------
-- 4. Table: sections
-- -----------------------------------------------------------------------------
CREATE TABLE sections (
    section_id INT AUTO_INCREMENT PRIMARY KEY,
    section_name VARCHAR(60) NOT NULL,
    course_id INT NOT NULL,
    faculty_id INT NOT NULL,
    academic_year VARCHAR(20) NOT NULL,
    semester INT NOT NULL,
    CONSTRAINT fk_sections_course 
        FOREIGN KEY (course_id) REFERENCES courses(course_id) 
        ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT fk_sections_faculty 
        FOREIGN KEY (faculty_id) REFERENCES faculty(faculty_id) 
        ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB;

-- -----------------------------------------------------------------------------
-- 5. Table: students
-- -----------------------------------------------------------------------------
CREATE TABLE students (
    student_id INT AUTO_INCREMENT PRIMARY KEY,
    roll_no VARCHAR(30) NOT NULL UNIQUE,
    full_name VARCHAR(100) NOT NULL,
    email VARCHAR(100) NOT NULL UNIQUE,
    phone VARCHAR(25),
    section_id INT NOT NULL,
    semester INT NOT NULL,
    admission_year INT NOT NULL,
    CONSTRAINT fk_students_section 
        FOREIGN KEY (section_id) REFERENCES sections(section_id) 
        ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB;

-- -----------------------------------------------------------------------------
-- 6. Table: class_sessions
-- -----------------------------------------------------------------------------
CREATE TABLE class_sessions (
    session_id INT AUTO_INCREMENT PRIMARY KEY,
    section_id INT NOT NULL,
    faculty_id INT NOT NULL,
    session_date DATE NOT NULL,
    time_slot VARCHAR(40) NOT NULL,
    room_no VARCHAR(30) NOT NULL,
    topic_covered VARCHAR(200) NOT NULL,
    status ENUM('Conducted', 'Scheduled', 'Cancelled') NOT NULL DEFAULT 'Conducted',
    CONSTRAINT fk_sessions_section 
        FOREIGN KEY (section_id) REFERENCES sections(section_id) 
        ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT fk_sessions_faculty 
        FOREIGN KEY (faculty_id) REFERENCES faculty(faculty_id) 
        ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB;

-- -----------------------------------------------------------------------------
-- 7. Table: attendance
-- -----------------------------------------------------------------------------
CREATE TABLE attendance (
    attendance_id INT AUTO_INCREMENT PRIMARY KEY,
    session_id INT NOT NULL,
    student_id INT NOT NULL,
    status ENUM('Present', 'Absent', 'Late', 'Excused') NOT NULL,
    marked_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    remarks VARCHAR(255),
    CONSTRAINT uq_session_student UNIQUE (session_id, student_id),
    CONSTRAINT fk_attendance_session 
        FOREIGN KEY (session_id) REFERENCES class_sessions(session_id) 
        ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT fk_attendance_student 
        FOREIGN KEY (student_id) REFERENCES students(student_id) 
        ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB;

-- -----------------------------------------------------------------------------
-- 8. Table: leave_types
-- -----------------------------------------------------------------------------
CREATE TABLE leave_types (
    leave_type_id INT AUTO_INCREMENT PRIMARY KEY,
    type_name VARCHAR(60) NOT NULL UNIQUE,
    max_days_allowed INT NOT NULL CHECK (max_days_allowed > 0),
    description VARCHAR(255)
) ENGINE=InnoDB;

-- -----------------------------------------------------------------------------
-- 9. Table: leave_applications
-- -----------------------------------------------------------------------------
CREATE TABLE leave_applications (
    application_id INT AUTO_INCREMENT PRIMARY KEY,
    student_id INT NOT NULL,
    leave_type_id INT NOT NULL,
    start_date DATE NOT NULL,
    end_date DATE NOT NULL,
    reason TEXT NOT NULL,
    applied_date DATE NOT NULL,
    status ENUM('Pending', 'Approved', 'Rejected') NOT NULL DEFAULT 'Pending',
    CONSTRAINT chk_leave_dates CHECK (end_date >= start_date),
    CONSTRAINT fk_leaves_student 
        FOREIGN KEY (student_id) REFERENCES students(student_id) 
        ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT fk_leaves_type 
        FOREIGN KEY (leave_type_id) REFERENCES leave_types(leave_type_id) 
        ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB;

-- -----------------------------------------------------------------------------
-- 10. Table: leave_approvals
-- -----------------------------------------------------------------------------
CREATE TABLE leave_approvals (
    approval_id INT AUTO_INCREMENT PRIMARY KEY,
    application_id INT NOT NULL UNIQUE,
    reviewed_by_faculty_id INT NOT NULL,
    decision_date DATE NOT NULL,
    status ENUM('Approved', 'Rejected') NOT NULL,
    comments VARCHAR(255),
    CONSTRAINT fk_approvals_application 
        FOREIGN KEY (application_id) REFERENCES leave_applications(application_id) 
        ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT fk_approvals_faculty 
        FOREIGN KEY (reviewed_by_faculty_id) REFERENCES faculty(faculty_id) 
        ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB;

-- -----------------------------------------------------------------------------
-- 11. Table: makeup_sessions
-- -----------------------------------------------------------------------------
CREATE TABLE makeup_sessions (
    makeup_id INT AUTO_INCREMENT PRIMARY KEY,
    original_session_id INT NULL,
    section_id INT NOT NULL,
    faculty_id INT NOT NULL,
    scheduled_date DATE NOT NULL,
    time_slot VARCHAR(40) NOT NULL,
    reason VARCHAR(255) NOT NULL,
    status ENUM('Scheduled', 'Completed', 'Cancelled') NOT NULL DEFAULT 'Scheduled',
    CONSTRAINT fk_makeup_original 
        FOREIGN KEY (original_session_id) REFERENCES class_sessions(session_id) 
        ON DELETE SET NULL ON UPDATE CASCADE,
    CONSTRAINT fk_makeup_section 
        FOREIGN KEY (section_id) REFERENCES sections(section_id) 
        ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT fk_makeup_faculty 
        FOREIGN KEY (faculty_id) REFERENCES faculty(faculty_id) 
        ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB;

-- -----------------------------------------------------------------------------
-- 12. Table: shortage_alerts
-- -----------------------------------------------------------------------------
CREATE TABLE shortage_alerts (
    alert_id INT AUTO_INCREMENT PRIMARY KEY,
    student_id INT NOT NULL,
    course_id INT NOT NULL,
    attendance_percentage DECIMAL(5,2) NOT NULL CHECK (attendance_percentage BETWEEN 0 AND 100),
    alert_level ENUM('Warning', 'Critical', 'Debarred') NOT NULL,
    generated_date DATE NOT NULL,
    is_resolved TINYINT(1) NOT NULL DEFAULT 0,
    CONSTRAINT fk_alerts_student 
        FOREIGN KEY (student_id) REFERENCES students(student_id) 
        ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT fk_alerts_course 
        FOREIGN KEY (course_id) REFERENCES courses(course_id) 
        ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB;

-- ==============================================================================
-- INDEXING FOR OPTIMIZED QUERY PERFORMANCE
-- ==============================================================================
CREATE INDEX idx_student_roll ON students(roll_no);
CREATE INDEX idx_session_date ON class_sessions(session_date);
CREATE INDEX idx_attendance_status ON attendance(status);
CREATE INDEX idx_leave_status ON leave_applications(status);

-- ==============================================================================
-- DATABASE VIEWS
-- ==============================================================================

-- View 1: Student Attendance Summary
CREATE OR REPLACE VIEW v_student_attendance_summary AS
SELECT 
    s.student_id,
    s.roll_no,
    s.full_name,
    sec.section_name,
    c.course_code,
    c.course_name,
    COUNT(a.attendance_id) AS total_sessions,
    SUM(CASE WHEN a.status IN ('Present', 'Late') THEN 1 ELSE 0 END) AS attended_sessions,
    SUM(CASE WHEN a.status = 'Absent' THEN 1 ELSE 0 END) AS absent_sessions,
    ROUND(
        CASE 
            WHEN COUNT(a.attendance_id) > 0 
            THEN (SUM(CASE WHEN a.status IN ('Present', 'Late') THEN 1.0 ELSE 0.0 END) * 100.0) / COUNT(a.attendance_id) 
            ELSE 0.0 
        END, 2
    ) AS attendance_percentage,
    CASE 
        WHEN COUNT(a.attendance_id) = 0 THEN 'No Data'
        WHEN (SUM(CASE WHEN a.status IN ('Present', 'Late') THEN 1.0 ELSE 0.0 END) * 100.0) / COUNT(a.attendance_id) >= 75.0 THEN 'Safe'
        WHEN (SUM(CASE WHEN a.status IN ('Present', 'Late') THEN 1.0 ELSE 0.0 END) * 100.0) / COUNT(a.attendance_id) >= 65.0 THEN 'Warning'
        ELSE 'Critical Shortage'
    END AS status_badge
FROM students s
JOIN sections sec ON s.section_id = sec.section_id
JOIN courses c ON sec.course_id = c.course_id
LEFT JOIN class_sessions cs ON cs.section_id = sec.section_id
LEFT JOIN attendance a ON a.session_id = cs.session_id AND a.student_id = s.student_id
GROUP BY s.student_id, c.course_id;

-- View 2: Pending Leave Applications
CREATE OR REPLACE VIEW v_pending_leave_applications AS
SELECT 
    la.application_id,
    s.roll_no,
    s.full_name AS student_name,
    lt.type_name AS leave_type,
    la.start_date,
    la.end_date,
    DATEDIFF(la.end_date, la.start_date) + 1 AS total_days,
    la.reason,
    la.applied_date,
    la.status
FROM leave_applications la
JOIN students s ON la.student_id = s.student_id
JOIN leave_types lt ON la.leave_type_id = lt.leave_type_id
WHERE la.status = 'Pending';

-- ==============================================================================
-- SEED DATA INSERTION (270+ RECORDS EXCEEDING MIN 60 ENTRIES REQUIREMENT)
-- ==============================================================================

-- 1. Departments (4 rows)
INSERT INTO departments (dept_name, dept_code) VALUES
('Computer Science & Engineering', 'CSE'),
('Artificial Intelligence & Machine Learning', 'AIML'),
('Data Science & Engineering', 'DSE'),
('Electronics & Communication Engineering', 'ECE');

-- 2. Faculty (8 rows)
INSERT INTO faculty (full_name, email, phone, department_id, designation) VALUES
('Dr. Arisetti V. Rao', 'avrao@university.edu', '+91 98480 11223', 1, 'Professor & HOD'),
('Prof. Meenakshi Sundaram', 'meenakshi.s@university.edu', '+91 98480 22334', 2, 'Associate Professor'),
('Dr. Rajesh Nambiar', 'rajesh.n@university.edu', '+91 98480 33445', 2, 'Assistant Professor'),
('Dr. Priya Swaminathan', 'priya.s@university.edu', '+91 98480 44556', 1, 'Associate Professor'),
('Prof. K. Venkatesh', 'k.venkatesh@university.edu', '+91 98480 55667', 3, 'Assistant Professor'),
('Dr. Shalini Deshmukh', 'shalini.d@university.edu', '+91 98480 66778', 4, 'Professor'),
('Prof. Anand Vardhan', 'anand.v@university.edu', '+91 98480 77889', 2, 'Assistant Professor'),
('Dr. Sunita Kulkarni', 'sunita.k@university.edu', '+91 98480 88990', 1, 'Associate Professor');

-- 3. Courses (6 rows)
INSERT INTO courses (course_code, course_name, credits, department_id, semester) VALUES
('CS301', 'Database Management Systems', 4, 1, 4),
('AI302', 'Machine Learning Foundations', 4, 2, 4),
('CS303', 'Operating Systems & Concurrency', 3, 1, 4),
('AI304', 'Deep Neural Networks', 4, 2, 4),
('DS305', 'Data Warehousing & Mining', 3, 3, 4),
('EC306', 'Microcontrollers & Embedded Systems', 3, 4, 4);

-- 4. Sections (6 rows)
INSERT INTO sections (section_name, course_id, faculty_id, academic_year, semester) VALUES
('AIML-A (Whales)', 1, 2, '2025-2026', 4),
('AIML-B (Panthers)', 1, 3, '2025-2026', 4),
('AIML-A (Whales)', 2, 7, '2025-2026', 4),
('CSE-A', 3, 4, '2025-2026', 4),
('AIML-A (Whales)', 4, 2, '2025-2026', 4),
('DSE-A', 5, 5, '2025-2026', 4);

-- 5. Students (24 rows)
INSERT INTO students (roll_no, full_name, email, phone, section_id, semester, admission_year) VALUES
('25WU0102251', 'Shaikh Humzah', 'shaikh.humzah@univ.edu', '+91 91234 56701', 1, 4, 2024),
('25WU0102138', 'M Pranay Kumar Reddy', 'pranay.reddy@univ.edu', '+91 91234 56702', 2, 4, 2024),
('25WU0102243', 'Sanjyit Suresh Kumar', 'sanjyit.sk@univ.edu', '+91 91234 56703', 1, 4, 2024),
('25WU0102128', 'Konduru Sharva Teja', 'sharva.teja@univ.edu', '+91 91234 56704', 2, 4, 2024),
('25WU0102253', 'Gandla Sharvari', 'gandla.sharvari@univ.edu', '+91 91234 56705', 1, 4, 2024),
('25WU0102142', 'Maddala Sai Chethana', 'chethana.m@univ.edu', '+91 91234 56706', 2, 4, 2024),
('25WU0102250', 'Shaik Abdul Raheem', 'abdul.raheem@univ.edu', '+91 91234 56707', 1, 4, 2024),
('25WU0102137', 'Lingampally Mohith', 'mohith.l@univ.edu', '+91 91234 56708', 2, 4, 2024),
('25WU0102248', 'Sashrika Reddy Alimity', 'sashrika.r@univ.edu', '+91 91234 56709', 1, 4, 2024),
('25WU0102134', 'Kurakula Harshitha', 'harshitha.k@univ.edu', '+91 91234 56710', 2, 4, 2024),
('25WU0102249', 'Settipalli Satwik Siva Sai', 'satwik.s@univ.edu', '+91 91234 56711', 1, 4, 2024),
('25WU0102135', 'Lade Bilvesh Datta', 'bilvesh.d@univ.edu', '+91 91234 56712', 2, 4, 2024),
('25WU0102252', 'Shailesh Charan Pathlavath', 'shailesh.c@univ.edu', '+91 91234 56713', 1, 4, 2024),
('25WU0102139', 'M Sai Manoj', 'sai.manoj@univ.edu', '+91 91234 56714', 2, 4, 2024),
('25WU0102254', 'Shaurya Dhingra', 'shaurya.d@univ.edu', '+91 91234 56715', 1, 4, 2024),
('25WU0102144', 'Mallavarapu Suchith', 'suchith.m@univ.edu', '+91 91234 56716', 2, 4, 2024),
('25WU0102255', 'Sheikh Arsh Ali', 'arsh.ali@univ.edu', '+91 91234 56717', 1, 4, 2024),
('25WU0102146', 'Mamunoori Reethu Chandra', 'reethu.c@univ.edu', '+91 91234 56718', 2, 4, 2024),
('25WU0102258', 'Shrestha Mal', 'shrestha.mal@univ.edu', '+91 91234 56719', 1, 4, 2024),
('25WU0102147', 'Manash Roy', 'manash.roy@univ.edu', '+91 91234 56720', 2, 4, 2024),
('25WU0102260', 'Shudhanshu Shekhar', 'shudhanshu.s@univ.edu', '+91 91234 56721', 1, 4, 2024),
('25WU0102149', 'Mane Heya', 'heya.mane@univ.edu', '+91 91234 56722', 2, 4, 2024),
('25WU0102262', 'Siddhant Agarwal', 'siddhant.a@univ.edu', '+91 91234 56723', 1, 4, 2024),
('25WU0102151', 'Manthena Naga Sri Rohan', 'rohan.m@univ.edu', '+91 91234 56724', 2, 4, 2024);

-- 6. Class Sessions (15 rows)
INSERT INTO class_sessions (section_id, faculty_id, session_date, time_slot, room_no, topic_covered, status) VALUES
(1, 2, '2026-09-01', '09:00 - 10:00 AM', 'LH-201', 'Introduction to Relational DBMS & ER Modeling', 'Conducted'),
(1, 2, '2026-09-03', '09:00 - 10:00 AM', 'LH-201', 'Relational Algebra & Tuple Relational Calculus', 'Conducted'),
(1, 2, '2026-09-08', '09:00 - 10:00 AM', 'LH-201', 'SQL DDL, DML and Integrity Constraints', 'Conducted'),
(1, 2, '2026-09-10', '09:00 - 10:00 AM', 'LH-201', 'Complex SQL Joins and Subqueries', 'Conducted'),
(1, 2, '2026-09-15', '09:00 - 10:00 AM', 'LH-201', 'Functional Dependencies & Normal Forms (1NF, 2NF, 3NF)', 'Conducted'),
(1, 2, '2026-09-17', '09:00 - 10:00 AM', 'LH-201', 'BCNF and Multivalued Dependencies', 'Conducted'),
(1, 2, '2026-09-22', '09:00 - 10:00 AM', 'LH-201', 'Transaction Processing, ACID & Serializability', 'Conducted'),
(1, 2, '2026-09-24', '09:00 - 10:00 AM', 'LH-201', 'Concurrency Control: Two-Phase Locking & Timestamping', 'Conducted'),
(1, 2, '2026-09-29', '09:00 - 10:00 AM', 'LH-201', 'Indexing & B+ Trees in Relational Engines', 'Conducted'),
(1, 2, '2026-10-01', '09:00 - 10:00 AM', 'LH-201', 'Database Security, Views and Grant Management', 'Conducted'),
(2, 3, '2026-09-02', '10:00 - 11:00 AM', 'LH-202', 'Relational Model Fundamentals', 'Conducted'),
(2, 3, '2026-09-04', '10:00 - 11:00 AM', 'LH-202', 'SQL Queries & Aggregations', 'Conducted'),
(2, 3, '2026-09-09', '10:00 - 11:00 AM', 'LH-202', 'Normalization & 3NF Decomposition', 'Conducted'),
(1, 2, '2026-10-08', '09:00 - 10:00 AM', 'LH-201', 'NoSQL & Distributed Relational Scaling', 'Scheduled'),
(1, 2, '2026-10-10', '09:00 - 10:00 AM', 'LH-201', 'Review-3 Final Project UI & DB Evaluation', 'Scheduled');

-- 7. Leave Types (5 rows)
INSERT INTO leave_types (type_name, max_days_allowed, description) VALUES
('Medical Leave', 10, 'Health illness, hospitalization, or physician mandated rest with medical certificate'),
('Academic / Conference Leave', 7, 'Attending recognized workshops, paper presentations, or hackathons'),
('On Duty (OD) / Event Leave', 5, 'Representing college in sports, cultural, or student club activities'),
('Personal / Casual Leave', 3, 'Family emergency, urgent personal affairs with parent consent'),
('Bereavement Leave', 5, 'Compassionate leave for immediate family bereavements');

-- 8. Leave Applications (16 rows)
INSERT INTO leave_applications (student_id, leave_type_id, start_date, end_date, reason, applied_date, status) VALUES
(1, 2, '2026-09-16', '2026-09-17', 'Attending IEEE Student Conference in Hyderabad to present DBMS paper', '2026-09-12', 'Approved'),
(7, 1, '2026-09-10', '2026-09-12', 'Severe viral infection and fever under prescription', '2026-09-09', 'Approved'),
(15, 1, '2026-09-14', '2026-09-18', 'Undergoing medical diagnostic checkups and quarantine for jaundice', '2026-09-13', 'Pending'),
(17, 3, '2026-09-21', '2026-09-23', 'Representing university in Inter-Collegiate Football Championship', '2026-09-18', 'Approved'),
(3, 4, '2026-09-25', '2026-09-25', 'Sister wedding ceremony out of station', '2026-09-20', 'Approved'),
(5, 1, '2026-09-28', '2026-09-29', 'Severe migraine and dental procedure', '2026-09-27', 'Approved'),
(9, 2, '2026-10-02', '2026-10-04', 'Smart India Hackathon Zonal Round Participation', '2026-09-29', 'Approved'),
(11, 4, '2026-10-05', '2026-10-06', 'Family relocation and house shifting assistance', '2026-10-01', 'Rejected'),
(13, 1, '2026-10-06', '2026-10-07', 'Seasonal flu with medical prescription attached', '2026-10-05', 'Pending'),
(2, 3, '2026-09-15', '2026-09-16', 'Organizing campus technical symposium (Whales & Panthers)', '2026-09-10', 'Approved'),
(4, 1, '2026-09-18', '2026-09-19', 'Hospitalized for acute allergic reaction', '2026-09-17', 'Approved'),
(6, 2, '2026-09-22', '2026-09-24', 'ACM ICPC Regional Preliminary Contest travel', '2026-09-19', 'Approved'),
(8, 4, '2026-09-29', '2026-09-30', 'Personal vacation trip', '2026-09-25', 'Rejected'),
(10, 1, '2026-10-08', '2026-10-09', 'Fracture follow-up consultation with orthopedic surgeon', '2026-10-06', 'Pending'),
(12, 3, '2026-10-07', '2026-10-08', 'National Robotics League demonstration in Bangalore', '2026-10-04', 'Pending'),
(14, 1, '2026-10-03', '2026-10-04', 'Typhoid recovery follow up', '2026-10-02', 'Approved');

-- 9. Leave Approvals (12 rows)
INSERT INTO leave_approvals (application_id, reviewed_by_faculty_id, decision_date, status, comments) VALUES
(1, 2, '2026-09-14', 'Approved', 'Conference invite verified. Attendance waiver granted for 2 days.'),
(2, 2, '2026-09-10', 'Approved', 'Medical certificate from Govt hospital verified.'),
(4, 2, '2026-09-19', 'Approved', 'Approved by sports directorate and HOD.'),
(5, 2, '2026-09-21', 'Approved', 'Parental confirmation email received and confirmed.'),
(6, 2, '2026-09-28', 'Approved', 'Medical note accepted. Ensure makeup sessions attended.'),
(7, 2, '2026-09-30', 'Approved', 'Hackathon permission letter countersigned.'),
(8, 2, '2026-10-02', 'Rejected', 'Personal leave without prior approval during exam preparatory week.'),
(10, 3, '2026-09-11', 'Approved', 'Symposium organizing committee approval granted.'),
(11, 3, '2026-09-18', 'Approved', 'Valid hospitalization documents uploaded.'),
(12, 3, '2026-09-20', 'Approved', 'Official university delegation to ICPC.'),
(13, 3, '2026-09-26', 'Rejected', 'Personal travel cannot be excused as formal leave.'),
(16, 3, '2026-10-03', 'Approved', 'Medical fitness certificate submitted.');

-- 10. Makeup Sessions (8 rows)
INSERT INTO makeup_sessions (original_session_id, section_id, faculty_id, scheduled_date, time_slot, reason, status) VALUES
(6, 1, 2, '2026-09-19', '03:00 - 04:30 PM', 'Makeup class for BCNF and Multivalued Dependencies', 'Completed'),
(7, 1, 2, '2026-09-26', '02:00 - 03:30 PM', 'Makeup session for ACID Transactions and Recovery', 'Completed'),
(11, 2, 3, '2026-09-05', '03:30 - 05:00 PM', 'Extra tutorial on Relational Algebra proofs', 'Completed'),
(NULL, 1, 2, '2026-10-09', '02:30 - 04:00 PM', 'Pre-exam revision lab for students with < 75% attendance', 'Scheduled'),
(NULL, 2, 3, '2026-10-10', '03:00 - 04:30 PM', 'Remedial SQL Subqueries and Views workshop', 'Scheduled'),
(8, 1, 2, '2026-09-27', '04:00 - 05:30 PM', 'Concurrency control problem solving clinic', 'Completed'),
(NULL, 4, 4, '2026-10-12', '10:00 - 11:30 AM', 'Operating Systems Semaphore makeup lab', 'Scheduled'),
(NULL, 1, 2, '2026-10-14', '03:00 - 04:30 PM', 'Review 3 SQL viva preparation session', 'Scheduled');

-- 11. Shortage Alerts (10 rows)
INSERT INTO shortage_alerts (student_id, course_id, attendance_percentage, alert_level, generated_date, is_resolved) VALUES
(7, 1, 60.00, 'Warning', '2026-09-25', 0),
(15, 1, 50.00, 'Critical', '2026-09-25', 0),
(17, 1, 70.00, 'Warning', '2026-09-26', 1),
(11, 1, 60.00, 'Warning', '2026-09-28', 0),
(21, 1, 70.00, 'Warning', '2026-09-30', 0),
(8, 1, 66.70, 'Warning', '2026-09-25', 0),
(14, 1, 66.70, 'Warning', '2026-09-25', 1),
(20, 1, 33.30, 'Debarred', '2026-10-02', 0),
(24, 1, 66.70, 'Warning', '2026-10-02', 0),
(22, 1, 66.70, 'Warning', '2026-10-02', 1);

-- 12. Attendance Records (156 entries generated across conducted sessions)
-- Section 1 (Whales): Sessions 1 through 10
-- Section 2 (Panthers): Sessions 11 through 13
INSERT INTO attendance (session_id, student_id, status, remarks) VALUES
-- Shaikh Humzah (Roll: 25WU0102251) - exemplary 90%+ attendance
(1, 1, 'Present', 'On time'),
(2, 1, 'Present', 'On time'),
(3, 1, 'Present', 'On time'),
(4, 1, 'Present', 'On time'),
(5, 1, 'Present', 'On time'),
(6, 1, 'Late', 'Permitted 5 mins late'),
(7, 1, 'Present', 'On time'),
(8, 1, 'Present', 'On time'),
(9, 1, 'Present', 'On time'),
(10, 1, 'Present', 'On time'),
-- Sanjyit Suresh Kumar (Roll: 25WU0102243)
(1, 3, 'Present', 'Participated in class'),
(2, 3, 'Present', 'Participated in class'),
(3, 3, 'Present', 'Participated in class'),
(4, 3, 'Present', 'Participated in class'),
(5, 3, 'Present', 'Participated in class'),
(6, 3, 'Present', 'Participated in class'),
(7, 3, 'Present', 'Participated in class'),
(8, 3, 'Present', 'Participated in class'),
(9, 3, 'Present', 'Participated in class'),
(10, 3, 'Present', 'Participated in class'),
-- Gandla Sharvari (Roll: 25WU0102253)
(1, 5, 'Present', 'Regular mark'),
(2, 5, 'Present', 'Regular mark'),
(3, 5, 'Present', 'Regular mark'),
(4, 5, 'Present', 'Regular mark'),
(5, 5, 'Absent', 'Medical leave submitted'),
(6, 5, 'Present', 'Regular mark'),
(7, 5, 'Present', 'Regular mark'),
(8, 5, 'Present', 'Regular mark'),
(9, 5, 'Present', 'Regular mark'),
(10, 5, 'Absent', 'Unexcused'),
-- Shaik Abdul Raheem (Roll: 25WU0102250) - Shortage case
(1, 7, 'Present', 'Verified'),
(2, 7, 'Present', 'Verified'),
(3, 7, 'Absent', 'Unexcused absence'),
(4, 7, 'Present', 'Verified'),
(5, 7, 'Present', 'Verified'),
(6, 7, 'Absent', 'Unexcused absence'),
(7, 7, 'Absent', 'Unexcused absence'),
(8, 7, 'Present', 'Verified'),
(9, 7, 'Present', 'Verified'),
(10, 7, 'Absent', 'Unexcused absence'),
-- Sashrika Reddy Alimity
(1, 9, 'Present', 'Regular mark'),
(2, 9, 'Present', 'Regular mark'),
(3, 9, 'Present', 'Regular mark'),
(4, 9, 'Absent', 'Absent'),
(5, 9, 'Present', 'Regular mark'),
(6, 9, 'Present', 'Regular mark'),
(7, 9, 'Present', 'Regular mark'),
(8, 9, 'Present', 'Regular mark'),
(9, 9, 'Absent', 'Absent'),
(10, 9, 'Present', 'Regular mark'),
-- Settipalli Satwik Siva Sai
(1, 11, 'Present', 'Regular mark'),
(2, 11, 'Absent', 'Absent'),
(3, 11, 'Present', 'Regular mark'),
(4, 11, 'Present', 'Regular mark'),
(5, 11, 'Absent', 'Absent'),
(6, 11, 'Present', 'Regular mark'),
(7, 11, 'Absent', 'Absent'),
(8, 11, 'Present', 'Regular mark'),
(9, 11, 'Present', 'Regular mark'),
(10, 11, 'Absent', 'Shortage warning'),
-- Shailesh Charan Pathlavath
(1, 13, 'Present', 'Regular mark'),
(2, 13, 'Present', 'Regular mark'),
(3, 13, 'Present', 'Regular mark'),
(4, 13, 'Present', 'Regular mark'),
(5, 13, 'Present', 'Regular mark'),
(6, 13, 'Present', 'Regular mark'),
(7, 13, 'Present', 'Regular mark'),
(8, 13, 'Absent', 'Absent'),
(9, 13, 'Present', 'Regular mark'),
(10, 13, 'Present', 'Regular mark'),
-- Shaurya Dhingra (Roll: 25WU0102254) - Critical shortage
(1, 15, 'Present', 'Marked by faculty'),
(2, 15, 'Absent', 'Medical leave pending'),
(3, 15, 'Present', 'Marked by faculty'),
(4, 15, 'Absent', 'Medical leave pending'),
(5, 15, 'Present', 'Marked by faculty'),
(6, 15, 'Absent', 'Medical leave pending'),
(7, 15, 'Present', 'Marked by faculty'),
(8, 15, 'Absent', 'Medical leave pending'),
(9, 15, 'Present', 'Marked by faculty'),
(10, 15, 'Absent', 'Critical shortage threshold reached'),
-- Sheikh Arsh Ali
(1, 17, 'Present', 'Present'),
(2, 17, 'Present', 'Present'),
(3, 17, 'Excused', 'Sports club event'),
(4, 17, 'Present', 'Present'),
(5, 17, 'Present', 'Present'),
(6, 17, 'Present', 'Present'),
(7, 17, 'Excused', 'Inter-college tournament'),
(8, 17, 'Present', 'Present'),
(9, 17, 'Present', 'Present'),
(10, 17, 'Present', 'Present'),
-- Shrestha Mal
(1, 19, 'Present', 'Regular mark'),
(2, 19, 'Present', 'Regular mark'),
(3, 19, 'Present', 'Regular mark'),
(4, 19, 'Present', 'Regular mark'),
(5, 19, 'Present', 'Regular mark'),
(6, 19, 'Absent', 'Absent'),
(7, 19, 'Present', 'Regular mark'),
(8, 19, 'Present', 'Regular mark'),
(9, 19, 'Present', 'Regular mark'),
(10, 19, 'Present', 'Regular mark'),
-- Shudhanshu Shekhar
(1, 21, 'Present', 'Regular mark'),
(2, 21, 'Absent', 'Absent'),
(3, 21, 'Present', 'Regular mark'),
(4, 21, 'Present', 'Regular mark'),
(5, 21, 'Absent', 'Absent'),
(6, 21, 'Present', 'Regular mark'),
(7, 21, 'Absent', 'Absent'),
(8, 21, 'Present', 'Regular mark'),
(9, 21, 'Present', 'Regular mark'),
(10, 21, 'Present', 'Regular mark'),
-- Siddhant Agarwal
(1, 23, 'Present', 'Regular mark'),
(2, 23, 'Present', 'Regular mark'),
(3, 23, 'Present', 'Regular mark'),
(4, 23, 'Present', 'Regular mark'),
(5, 23, 'Present', 'Regular mark'),
(6, 23, 'Present', 'Regular mark'),
(7, 23, 'Present', 'Regular mark'),
(8, 23, 'Present', 'Regular mark'),
(9, 23, 'Absent', 'Absent'),
(10, 23, 'Present', 'Regular mark'),
-- Section 2 (Panthers) Attendance: Sessions 11, 12, 13
(11, 2, 'Present', 'Regular mark'),
(12, 2, 'Present', 'Regular mark'),
(13, 2, 'Present', 'Regular mark'),
(11, 4, 'Present', 'Regular mark'),
(12, 4, 'Absent', 'Absent'),
(13, 4, 'Present', 'Regular mark'),
(11, 6, 'Present', 'Regular mark'),
(12, 6, 'Present', 'Regular mark'),
(13, 6, 'Present', 'Regular mark'),
(11, 8, 'Absent', 'Absent'),
(12, 8, 'Present', 'Regular mark'),
(13, 8, 'Present', 'Regular mark'),
(11, 10, 'Present', 'Regular mark'),
(12, 10, 'Present', 'Regular mark'),
(13, 10, 'Present', 'Regular mark'),
(11, 12, 'Present', 'Regular mark'),
(12, 12, 'Absent', 'Absent'),
(13, 12, 'Present', 'Regular mark'),
(11, 14, 'Present', 'Regular mark'),
(12, 14, 'Present', 'Regular mark'),
(13, 14, 'Absent', 'Absent'),
(11, 16, 'Present', 'Regular mark'),
(12, 16, 'Present', 'Regular mark'),
(13, 16, 'Present', 'Regular mark'),
(11, 18, 'Present', 'Regular mark'),
(12, 18, 'Present', 'Regular mark'),
(13, 18, 'Present', 'Regular mark'),
(11, 20, 'Absent', 'Absent'),
(12, 20, 'Absent', 'Absent'),
(13, 20, 'Present', 'Regular mark'),
(11, 22, 'Present', 'Regular mark'),
(12, 22, 'Absent', 'Absent'),
(13, 22, 'Present', 'Regular mark'),
(11, 24, 'Present', 'Regular mark'),
(12, 24, 'Present', 'Regular mark'),
(13, 24, 'Absent', 'Absent');

-- ==============================================================================
-- VERIFICATION STATEMENT
-- ==============================================================================
SELECT 'MySQL Database Initialized Successfully with 270+ Records across 12 Tables' AS status_report;
