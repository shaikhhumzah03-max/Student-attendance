#!/usr/bin/env bash
# Presentation-II Interactive Query CLI Launcher
# Student: Shaikh Humzah (Roll No: 25WU0102251)
cd "$(dirname "$0")/.." || exit 1
python3 query_cli.py "$@"
