"""
Automated Verification & CRUD Integrity Test Suite
Student Attendance & Leave Approval System (Topic #26)
Shaikh Humzah (Roll No: 25WU0102251)
"""

import sys
import os
import json
import sqlite3

# Ensure app path
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from app.database import get_connection, init_database, seed_database, DB_PATH

def run_tests():
    print("=" * 70)
    print("RUNNING DBMS REVIEW 3 INTEGRITY & CRUD TEST SUITE")
    print("=" * 70)

    # 1. Initialize and Seed
    print("\n[TEST 1] Initializing & Seeding Relational Database...")
    init_database()
    counts = seed_database()
    total_records = sum(counts.values())
    print(f"  ✓ Database seeded successfully with {total_records} total records across {len(counts)} tables.")
    assert total_records >= 60, f"Expected >= 60 records, got {total_records}"
    print(f"  ✓ Requirement 'min 60 entries': PASSED (Actual: {total_records} records)")

    conn = get_connection()
    cursor = conn.cursor()

    # 2. Verify 3NF Normalized Entities
    print("\n[TEST 2] Verifying 3NF Relational Schema & Foreign Keys...")
    tables = [
        'departments', 'faculty', 'courses', 'sections', 'students',
        'class_sessions', 'attendance', 'leave_types', 'leave_applications',
        'leave_approvals', 'makeup_sessions', 'shortage_alerts'
    ]
    for tbl in tables:
        cnt = cursor.execute(f"SELECT COUNT(*) FROM {tbl}").fetchone()[0]
        print(f"  ✓ Table '{tbl}': {cnt} records")
        assert cnt > 0, f"Table {tbl} is empty!"

    # 3. Test Student LIVE CRUD
    print("\n[TEST 3] Testing Students Live CRUD Operations...")
    # CREATE (Insert)
    cursor.execute("""
        INSERT INTO students (roll_no, full_name, email, phone, section_id, semester, admission_year)
        VALUES ('25WU0102999', 'Test Learner Alpha', 'test.alpha@univ.edu', '+91 99999 00001', 1, 4, 2024)
    """)
    new_student_id = cursor.lastrowid
    conn.commit()
    print(f"  ✓ INSERT: Created Student ID #{new_student_id} ('25WU0102999')")

    # READ
    st = cursor.execute("SELECT * FROM students WHERE student_id = ?", (new_student_id,)).fetchone()
    assert st['roll_no'] == '25WU0102999', "Read verification failed"
    print(f"  ✓ READ: Successfully fetched record for '{st['full_name']}'")

    # UPDATE
    cursor.execute("""
        UPDATE students SET full_name = 'Test Learner Alpha Modified', phone = '+91 99999 88888'
        WHERE student_id = ?
    """, (new_student_id,))
    conn.commit()
    st_up = cursor.execute("SELECT full_name FROM students WHERE student_id = ?", (new_student_id,)).fetchone()
    assert st_up['full_name'] == 'Test Learner Alpha Modified', "Update verification failed"
    print(f"  ✓ UPDATE: Successfully modified record to '{st_up['full_name']}'")

    # DELETE
    cursor.execute("DELETE FROM students WHERE student_id = ?", (new_student_id,))
    conn.commit()
    st_del = cursor.execute("SELECT * FROM students WHERE student_id = ?", (new_student_id,)).fetchone()
    assert st_del is None, "Delete verification failed"
    print(f"  ✓ DELETE: Successfully removed Student ID #{new_student_id} from database")

    # 4. Test Attendance Marking & Unique Constraint
    print("\n[TEST 4] Testing Attendance Marking & Integrity Constraints...")
    # Mark attendance
    cursor.execute("""
        INSERT INTO attendance (session_id, student_id, status, remarks)
        VALUES (1, 1, 'Present', 'Automated test check')
        ON CONFLICT(session_id, student_id) DO UPDATE SET status = 'Late', remarks = 'Updated to Late'
    """)
    conn.commit()
    att = cursor.execute("SELECT status, remarks FROM attendance WHERE session_id = 1 AND student_id = 1").fetchone()
    assert att['status'] == 'Late', "Upsert status check failed"
    print(f"  ✓ UPSERT: Attendance record updated with conflict resolution to '{att['status']}'")

    # Check constraint violation handling
    try:
        cursor.execute("INSERT INTO attendance (session_id, student_id, status) VALUES (1, 24, 'InvalidStatus')")
        conn.commit()
        raise AssertionError("Check constraint on status should have failed!")
    except sqlite3.IntegrityError:
        print("  ✓ CONSTRAINT ENFORCEMENT: Invalid status 'InvalidStatus' correctly rejected by CHECK constraint.")

    # 5. Test Leave Submission & Approval Workflow
    print("\n[TEST 5] Testing Multi-tier Leave Approval Workflow & Transaction...")
    cursor.execute("""
        INSERT INTO leave_applications (student_id, leave_type_id, start_date, end_date, reason, applied_date, status)
        VALUES (1, 1, '2026-10-15', '2026-10-16', 'Medical checkup', '2026-10-07', 'Pending')
    """)
    leave_id = cursor.lastrowid
    conn.commit()
    print(f"  ✓ LEAVE CREATED: Application #{leave_id} submitted with status 'Pending'")

    # Approve
    cursor.execute("UPDATE leave_applications SET status = 'Approved' WHERE application_id = ?", (leave_id,))
    cursor.execute("""
        INSERT INTO leave_approvals (application_id, reviewed_by_faculty_id, decision_date, status, comments)
        VALUES (?, 2, '2026-10-07', 'Approved', 'Verified medical certificate')
    """, (leave_id,))
    conn.commit()
    
    appr = cursor.execute("""
        SELECT la.status as app_status, lap.status as decision, f.full_name as reviewer
        FROM leave_applications la
        JOIN leave_approvals lap ON la.application_id = lap.application_id
        JOIN faculty f ON lap.reviewed_by_faculty_id = f.faculty_id
        WHERE la.application_id = ?
    """, (leave_id,)).fetchone()
    print(f"  ✓ LEAVE APPROVED: Application #{leave_id} approved by '{appr['reviewer']}'")
    assert appr['app_status'] == 'Approved' and appr['decision'] == 'Approved'

    # Cleanup test leave
    cursor.execute("DELETE FROM leave_applications WHERE application_id = ?", (leave_id,))
    conn.commit()

    # 6. Test Views and Complex SQL Queries (Joins, Aggregates, Group By)
    print("\n[TEST 6] Testing Complex SQL Queries & Database Views...")
    summary = cursor.execute("SELECT * FROM v_student_attendance_summary LIMIT 5").fetchall()
    print(f"  ✓ VIEW 'v_student_attendance_summary' returned {len(summary)} sample rows:")
    for row in summary[:3]:
        print(f"     • {row['roll_no']} | {row['full_name']} | {row['attended_sessions']}/{row['total_sessions']} ({row['attendance_percentage']}%) | [{row['status_badge']}]")

    # 3-Table Join
    join_res = cursor.execute("""
        SELECT s.roll_no, s.full_name, sec.section_name, c.course_code, f.full_name as teacher
        FROM students s
        JOIN sections sec ON s.section_id = sec.section_id
        JOIN courses c ON sec.course_id = c.course_id
        JOIN faculty f ON sec.faculty_id = f.faculty_id
        LIMIT 3
    """).fetchall()
    print(f"  ✓ 4-Table JOIN (students -> sections -> courses -> faculty): {len(join_res)} rows verified.")

    # Aggregate & Shortage filter
    shortages = cursor.execute("""
        SELECT s.roll_no, s.full_name,
               ROUND((SUM(CASE WHEN a.status IN ('Present', 'Late') THEN 1.0 ELSE 0.0 END) * 100.0) / COUNT(a.attendance_id), 1) as pct
        FROM students s
        JOIN sections sec ON s.section_id = sec.section_id
        JOIN class_sessions cs ON cs.section_id = sec.section_id
        JOIN attendance a ON a.session_id = cs.session_id AND a.student_id = s.student_id
        GROUP BY s.student_id
        HAVING pct < 75.0
    """).fetchall()
    print(f"  ✓ Shortage Aggregate (<75% attendance): Found {len(shortages)} students with shortage alerts.")

    conn.close()
    print("\n" + "=" * 70)
    print("ALL 6 TESTS PASSED FLAWLESSLY! RELATIONAL DATABASE IS FULLY COMPLIANT.")
    print("=" * 70)

if __name__ == '__main__':
    run_tests()
