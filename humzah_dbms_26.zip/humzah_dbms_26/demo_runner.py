#!/usr/bin/env python3
"""
Interactive CLI Runner & Test Harness for DBMS Project (Topic #26)
Student: Shaikh Humzah (Roll No: 25WU0102251) - AIML Whales
Zero-dependency Python 3 standard library implementation.
"""

import sys
import os
import time
import sqlite3

# Ensure app path
ROOT_DIR = os.path.dirname(os.path.abspath(__file__))
if ROOT_DIR not in sys.path:
    sys.path.insert(0, ROOT_DIR)

from app.database import get_connection, init_database, seed_database, DB_PATH
from app.server import run_server

def print_header(title):
    print("\n" + "=" * 70)
    print(f"  {title.upper()}")
    print("=" * 70)

def test_schema_and_seed():
    print_header("Initializing & Seeding Relational Database")
    init_database()
    counts = seed_database()
    total = sum(counts.values())
    print(f"\n✓ Database seeded successfully with {total} total records across {len(counts)} tables.\n")
    for tbl, cnt in counts.items():
        print(f"  • {tbl.ljust(22)} : {str(cnt).rjust(4)} rows")
    print(f"\n✓ Requirement 'min 60 entries': PASSED (Actual: {total} records)")

def run_live_crud():
    print_header("Live CRUD Demonstration on Relational Database")
    conn = get_connection()
    cursor = conn.cursor()

    # 1. CREATE
    print("\n[1. CREATE] Inserting New Student Record...")
    cursor.execute("""
        INSERT INTO students (roll_no, full_name, email, phone, section_id, semester, admission_year)
        VALUES ('25WU0102999', 'Zaid Al-Mansoor', 'zaid.m@univ.edu', '+91 91234 99999', 1, 4, 2024)
    """)
    new_id = cursor.lastrowid
    conn.commit()
    print(f"  ✓ INSERT INTO students VALUES (...) -> Successfully created ID #{new_id} ('25WU0102999')")

    # 2. READ
    print("\n[2. READ] Fetching newly inserted student...")
    st = cursor.execute("SELECT * FROM students WHERE student_id = ?", (new_id,)).fetchone()
    print(f"  ✓ Retrieved: ID #{st['student_id']} | Roll: {st['roll_no']} | Name: {st['full_name']} | Email: {st['email']}")

    # 3. UPDATE
    print("\n[3. UPDATE] Modifying student phone and email...")
    cursor.execute("UPDATE students SET phone = '+91 99999 12345' WHERE student_id = ?", (new_id,))
    conn.commit()
    st_up = cursor.execute("SELECT phone FROM students WHERE student_id = ?", (new_id,)).fetchone()
    print(f"  ✓ UPDATE students SET phone = ... -> Phone updated to '{st_up['phone']}'")

    # 4. LIVE ATTENDANCE UPSERT
    print("\n[4. UPSERT] Marking session attendance for student...")
    cursor.execute("""
        INSERT INTO attendance (session_id, student_id, status, remarks)
        VALUES (1, ?, 'Present', 'Marked via CLI demo runner')
        ON CONFLICT(session_id, student_id) DO UPDATE SET status = excluded.status
    """, (new_id,))
    conn.commit()
    att = cursor.execute("SELECT * FROM attendance WHERE session_id = 1 AND student_id = ?", (new_id,)).fetchone()
    print(f"  ✓ Attendance recorded: Session #1 | Student #{new_id} | Status: '{att['status']}'")

    # 5. DELETE
    print("\n[5. DELETE] Removing test student record...")
    cursor.execute("DELETE FROM students WHERE student_id = ?", (new_id,))
    conn.commit()
    check = cursor.execute("SELECT * FROM students WHERE student_id = ?", (new_id,)).fetchone()
    print(f"  ✓ DELETE FROM students WHERE student_id = {new_id} -> Record successfully erased (Found: {check is not None})")

    conn.close()
    print("\n✓ Live CRUD lifecycle demonstration completed successfully!")

def run_analytical_queries():
    print_header("Executing 5 Analytical Reports & Relational Views")
    conn = get_connection()
    cursor = conn.cursor()

    # Query 1: Presentation-II Shortage Remedial Query
    print("\n[QUERY 1] Evaluated Shortage Remedial Query (Attendance < 75% in DBMS):")
    sql1 = """
        SELECT 
            s.roll_no, s.full_name, c.course_code,
            COUNT(a.attendance_id) AS total_sessions,
            SUM(CASE WHEN a.status IN ('Present', 'Late') THEN 1 ELSE 0 END) AS attended,
            ROUND((SUM(CASE WHEN a.status IN ('Present', 'Late') THEN 1.0 ELSE 0.0 END) * 100.0) / COUNT(a.attendance_id), 1) AS pct,
            (CAST((0.75 * COUNT(a.attendance_id) - SUM(CASE WHEN a.status IN ('Present', 'Late') THEN 1 ELSE 0 END)) / 0.25 AS INTEGER) + 1) AS needed_classes
        FROM students s
        JOIN sections sec ON s.section_id = sec.section_id
        JOIN courses c ON sec.course_id = c.course_id
        JOIN class_sessions cs ON cs.section_id = sec.section_id
        LEFT JOIN attendance a ON a.session_id = cs.session_id AND a.student_id = s.student_id
        WHERE sec.section_name = 'AIML-A (Whales)' AND c.course_code = 'CS301'
        GROUP BY s.student_id, c.course_id
        HAVING pct < 75.00
        ORDER BY pct ASC;
    """
    rows1 = cursor.execute(sql1).fetchall()
    print("  " + "-" * 75)
    print(f"  {'ROLL NO':<14} | {'NAME':<24} | {'ATTENDED':<10} | {'PCT':<8} | {'CLASSES NEEDED'}")
    print("  " + "-" * 75)
    for r in rows1:
        print(f"  {r['roll_no']:<14} | {r['full_name']:<24} | {str(r['attended'])+'/'+str(r['total_sessions']):<10} | {str(r['pct'])+'%':<8} | {r['needed_classes']}")

    # Query 2: Course Attendance Health Overview
    print("\n[QUERY 2] Course Attendance Performance Overview:")
    sql2 = """
        SELECT 
            c.course_code, c.course_name, COUNT(DISTINCT cs.session_id) as sessions_held,
            ROUND((SUM(CASE WHEN a.status IN ('Present', 'Late') THEN 1.0 ELSE 0.0 END) * 100.0) / COUNT(a.attendance_id), 1) as avg_att
        FROM courses c
        JOIN sections sec ON sec.course_id = c.course_id
        JOIN class_sessions cs ON cs.section_id = sec.section_id
        JOIN attendance a ON a.session_id = cs.session_id
        GROUP BY c.course_id;
    """
    rows2 = cursor.execute(sql2).fetchall()
    for r in rows2:
        print(f"  • {r['course_code']} ({r['course_name']}): {r['sessions_held']} Sessions Conducted | Avg Attendance: {r['avg_att']}%")

    # Query 3: Student Attendance Summary View
    print("\n[QUERY 3] Sampling Database View 'v_student_attendance_summary':")
    rows3 = cursor.execute("SELECT roll_no, full_name, attendance_percentage, status_badge FROM v_student_attendance_summary LIMIT 4").fetchall()
    for r in rows3:
        print(f"  • {r['roll_no']} | {r['full_name']} | {r['attendance_percentage']}% | [{r['status_badge']}]")

    conn.close()

def run_negative_tests():
    print_header("Negative Constraint Violation Tests (Live Error Demonstration)")
    conn = get_connection()
    cursor = conn.cursor()

    tests = [
        ("1. Duplicate Student Roll Number", 
         "INSERT INTO students (roll_no, full_name, email, phone, section_id, semester, admission_year) VALUES ('25WU0102251', 'Dup', 'dup@u.edu', '123', 1, 4, 2024)",
         "UNIQUE constraint failed"),
        ("2. Foreign Key Non-Existent Section 999", 
         "INSERT INTO students (roll_no, full_name, email, phone, section_id, semester, admission_year) VALUES ('25WU0102991', 'Ghost', 'g@u.edu', '123', 999, 4, 2024)",
         "FOREIGN KEY constraint failed"),
        ("3. Duplicate Attendance for Same Session & Student", 
         "INSERT INTO attendance (session_id, student_id, status) VALUES (1, 1, 'Present')",
         "UNIQUE constraint failed"),
        ("4. Invalid Status Domain Check ('Holiday')", 
         "INSERT INTO attendance (session_id, student_id, status) VALUES (14, 1, 'Holiday')",
         "CHECK constraint failed"),
        ("5. Temporal Logic Violation (end_date < start_date)", 
         "INSERT INTO leave_applications (student_id, leave_type_id, start_date, end_date, reason, applied_date) VALUES (1, 1, '2026-10-15', '2026-10-10', 'Time Travel', '2026-10-07')",
         "CHECK constraint failed"),
        ("6. Zero Course Credits Violation (credits > 0)", 
         "INSERT INTO courses (course_code, course_name, credits, department_id, semester) VALUES ('CS999', 'Zero', 0, 1, 4)",
         "CHECK constraint failed")
    ]

    for name, sql, expected_sub in tests:
        try:
            cursor.execute(sql)
            conn.commit()
            print(f"  ✕ FAILED: {name} was unexpectedly allowed!")
        except sqlite3.IntegrityError as e:
            print(f"  ✓ PASSED: {name}")
            print(f"    └── Caught by Engine: {str(e)}")

    conn.close()

def inspect_table_counts():
    print_header("Database Table Live Row Inventory")
    conn = get_connection()
    cursor = conn.cursor()
    tables = [
        'departments', 'faculty', 'courses', 'sections', 'students',
        'class_sessions', 'attendance', 'leave_types', 'leave_applications',
        'leave_approvals', 'makeup_sessions', 'shortage_alerts'
    ]
    total = 0
    print(f"  {'TABLE NAME':<24} | {'ROW COUNT':<10} | {'STATUS'}")
    print("  " + "-" * 50)
    for t in tables:
        cnt = cursor.execute(f"SELECT COUNT(*) FROM {t}").fetchone()[0]
        total += cnt
        print(f"  {t:<24} | {str(cnt).rjust(6)} rows | Active")
    print("  " + "-" * 50)
    print(f"  {'TOTAL DATABASE ROWS':<24} | {str(total).rjust(6)} rows | 3NF Normalized")
    conn.close()

def main_menu():
    while True:
        print("\n" + "=" * 70)
        print("  STUDENT ATTENDANCE & LEAVE APPROVAL SYSTEM — CLI HARNESS")
        print("  Shaikh Humzah (25WU0102251) · Topic #26 · AIML Whales")
        print("=" * 70)
        print("  [1] Initialize & Re-seed Database (270+ Records)")
        print("  [2] Run Live CRUD Demonstration")
        print("  [3] Execute Analytical Queries & Views")
        print("  [4] Run Negative Constraint Tests (Engine Violations)")
        print("  [5] Inspect Table Row Counts Live")
        print("  [6] Launch Apple Minimalist Web UI (Port 8000)")
        print("  [7] Exit")
        print("-" * 70)
        choice = input("Select an option [1-7]: ").strip()

        if choice == '1':
            test_schema_and_seed()
        elif choice == '2':
            run_live_crud()
        elif choice == '3':
            run_analytical_queries()
        elif choice == '4':
            run_negative_tests()
        elif choice == '5':
            inspect_table_counts()
        elif choice == '6':
            print("\nLaunching Apple Web UI Server at http://localhost:8000...")
            run_server()
        elif choice == '7':
            print("\nExiting CLI Harness. Good luck with Review 3 presentation!")
            break
        else:
            print("\nInvalid choice. Please enter a number between 1 and 7.")

if __name__ == '__main__':
    if len(sys.argv) > 1 and sys.argv[1] == '--all':
        test_schema_and_seed()
        run_live_crud()
        run_analytical_queries()
        run_negative_tests()
        inspect_table_counts()
    else:
        main_menu()
