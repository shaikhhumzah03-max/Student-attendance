#!/usr/bin/env python3
"""
Interactive SQL Query CLI for Presentation-II Viva Evaluation
Student: Shaikh Humzah (Roll No: 25WU0102251) - AIML Whales
Topic #26: Student Attendance and Leave Approval System

Allows live typing and execution of any SQL query given by the evaluator,
formatting results in one clean, aligned table.
"""

import sys
import os
import time
import sqlite3
import re

# Ensure path
ROOT_DIR = os.path.dirname(os.path.abspath(__file__))
if ROOT_DIR not in sys.path:
    sys.path.insert(0, ROOT_DIR)

from app.database import get_connection, DB_PATH

PRESETS = {
    "1": (
        "Shortage Remedial Query (Attendance < 75% in DBMS with needed classes)",
        """SELECT 
    s.roll_no, 
    s.full_name, 
    c.course_code,
    COUNT(a.attendance_id) AS total_sessions,
    SUM(CASE WHEN a.status IN ('Present', 'Late') THEN 1 ELSE 0 END) AS attended,
    ROUND((SUM(CASE WHEN a.status IN ('Present', 'Late') THEN 1.0 ELSE 0.0 END) * 100.0) / COUNT(a.attendance_id), 1) AS percentage,
    (CAST((0.75 * COUNT(a.attendance_id) - SUM(CASE WHEN a.status IN ('Present', 'Late') THEN 1 ELSE 0 END)) / 0.25 AS INTEGER) + 1) AS needed_classes
FROM students s
JOIN sections sec ON s.section_id = sec.section_id
JOIN courses c ON sec.course_id = c.course_id
JOIN class_sessions cs ON cs.section_id = sec.section_id
LEFT JOIN attendance a ON a.session_id = cs.session_id AND a.student_id = s.student_id
WHERE sec.section_name = 'AIML-A (Whales)' AND c.course_code = 'CS301'
GROUP BY s.student_id, c.course_id
HAVING percentage < 75.00
ORDER BY percentage ASC;"""
    ),
    "2": (
        "4-Table JOIN (Students -> Sections -> Courses -> Faculty)",
        """SELECT 
    s.roll_no, 
    s.full_name, 
    sec.section_name, 
    c.course_code, 
    f.full_name AS faculty_in_charge
FROM students s
JOIN sections sec ON s.section_id = sec.section_id
JOIN courses c ON sec.course_id = c.course_id
JOIN faculty f ON sec.faculty_id = f.faculty_id
LIMIT 8;"""
    ),
    "3": (
        "Course-Wise Attendance Health & Enrollment Overview",
        """SELECT 
    c.course_code, 
    c.course_name, 
    d.dept_code,
    COUNT(DISTINCT cs.session_id) AS sessions_held,
    COUNT(DISTINCT s.student_id) AS enrolled_students,
    ROUND((SUM(CASE WHEN a.status IN ('Present', 'Late') THEN 1.0 ELSE 0.0 END) * 100.0) / COUNT(a.attendance_id), 1) AS avg_attendance_pct
FROM courses c
JOIN departments d ON c.department_id = d.department_id
JOIN sections sec ON sec.course_id = c.course_id
JOIN students s ON s.section_id = sec.section_id
JOIN class_sessions cs ON cs.section_id = sec.section_id
JOIN attendance a ON a.session_id = cs.session_id AND a.student_id = s.student_id
GROUP BY c.course_id
ORDER BY avg_attendance_pct DESC;"""
    ),
    "4": (
        "Faculty Leave Review Decision Audit",
        """SELECT 
    f.faculty_id, 
    f.full_name AS faculty_name, 
    f.designation,
    COUNT(appr.approval_id) AS total_reviews,
    SUM(CASE WHEN appr.status = 'Approved' THEN 1 ELSE 0 END) AS approved_count,
    SUM(CASE WHEN appr.status = 'Rejected' THEN 1 ELSE 0 END) AS rejected_count
FROM faculty f
JOIN leave_approvals appr ON f.faculty_id = appr.reviewed_by_faculty_id
GROUP BY f.faculty_id
ORDER BY total_reviews DESC;"""
    ),
    "5": (
        "Active Shortage Debarment Risk List (< 75% attendance)",
        """SELECT 
    sa.alert_id, 
    s.roll_no, 
    s.full_name, 
    c.course_code, 
    sa.attendance_percentage, 
    sa.alert_level, 
    sa.generated_date
FROM shortage_alerts sa
JOIN students s ON sa.student_id = s.student_id
JOIN courses c ON sa.course_id = c.course_id
WHERE sa.is_resolved = 0
ORDER BY sa.attendance_percentage ASC;"""
    ),
    "6": (
        "Database View: v_student_attendance_summary (Sample Rows)",
        """SELECT roll_no, full_name, section_name, course_code, attended_sessions, total_sessions, attendance_percentage, status_badge
FROM v_student_attendance_summary 
LIMIT 8;"""
    ),
    "7": (
        "Status Group By Aggregation on Attendance Table",
        """SELECT 
    status, 
    COUNT(*) AS total_count,
    ROUND((COUNT(*) * 100.0) / (SELECT COUNT(*) FROM attendance), 1) AS percentage_of_total
FROM attendance 
GROUP BY status;"""
    ),
    "8": (
        "Conducted Class Sessions with Total Students Marked",
        """SELECT 
    cs.session_id, 
    cs.session_date, 
    cs.time_slot, 
    cs.room_no, 
    sec.section_name, 
    cs.topic_covered,
    COUNT(a.attendance_id) AS attendance_logged
FROM class_sessions cs
JOIN sections sec ON cs.section_id = sec.section_id
LEFT JOIN attendance a ON a.session_id = cs.session_id
GROUP BY cs.session_id
LIMIT 8;"""
    ),
    "9": (
        "Table Inventory: Live Row Counts across all 12 Schema Relations",
        """SELECT 'departments' AS table_name, COUNT(*) AS row_count FROM departments
UNION ALL SELECT 'faculty', COUNT(*) FROM faculty
UNION ALL SELECT 'courses', COUNT(*) FROM courses
UNION ALL SELECT 'sections', COUNT(*) FROM sections
UNION ALL SELECT 'students', COUNT(*) FROM students
UNION ALL SELECT 'class_sessions', COUNT(*) FROM class_sessions
UNION ALL SELECT 'attendance', COUNT(*) FROM attendance
UNION ALL SELECT 'leave_types', COUNT(*) FROM leave_types
UNION ALL SELECT 'leave_applications', COUNT(*) FROM leave_applications
UNION ALL SELECT 'leave_approvals', COUNT(*) FROM leave_approvals
UNION ALL SELECT 'makeup_sessions', COUNT(*) FROM makeup_sessions
UNION ALL SELECT 'shortage_alerts', COUNT(*) FROM shortage_alerts;"""
    )
}

def format_table(headers, rows):
    """
    Renders headers and rows in ONE clean, perfectly aligned Unicode box-drawing table.
    """
    if not headers:
        return "Empty result set."

    # Convert all cells to strings
    str_rows = []
    for r in rows:
        str_rows.append([str(val) if val is not None else "NULL" for val in r])

    # Compute column widths
    col_widths = [len(str(h)) for h in headers]
    for r in str_rows:
        for i, val in enumerate(r):
            if len(val) > col_widths[i]:
                col_widths[i] = len(val)

    # Caps for display (max 45 chars per column)
    col_widths = [min(w, 45) for w in col_widths]

    # Box-drawing elements
    top_border = "┌─" + "─┬─".join("─" * w for w in col_widths) + "─┐"
    header_sep = "├─" + "─┼─".join("─" * w for w in col_widths) + "─┤"
    bot_border = "└─" + "─┴─".join("─" * w for w in col_widths) + "─┘"

    lines = [top_border]

    # Header line
    header_cells = [f"{str(h).ljust(w)[:w]}" for h, w in zip(headers, col_widths)]
    lines.append("│ " + " │ ".join(header_cells) + " │")
    lines.append(header_sep)

    # Row lines
    if not str_rows:
        empty_msg = "No rows returned."
        total_w = sum(col_widths) + (len(col_widths) - 1) * 3
        lines.append("│ " + empty_msg.center(total_w) + " │")
    else:
        for r in str_rows:
            row_cells = [f"{val.ljust(w)[:w]}" for val, w in zip(r, col_widths)]
            lines.append("│ " + " │ ".join(row_cells) + " │")

    lines.append(bot_border)
    return "\n".join(lines)

def execute_query(conn, sql):
    sql = sql.strip().rstrip(";")
    if not sql:
        return

    start_t = time.perf_counter()
    cursor = conn.cursor()
    try:
        cursor.execute(sql)
        duration_ms = (time.perf_counter() - start_t) * 1000

        if cursor.description:
            headers = [d[0] for d in cursor.description]
            rows = cursor.fetchall()
            table_str = format_table(headers, rows)
            print("\n" + table_str)
            print(f"[{len(rows)} row{'s' if len(rows) != 1 else ''} in set ({duration_ms:.2f} ms)]\n")
        else:
            conn.commit()
            print(f"\nQuery OK, {cursor.rowcount} row(s) affected ({duration_ms:.2f} ms)\n")
    except sqlite3.Error as e:
        print(f"\n[ERROR] SQL Execution Failed: {str(e)}\n")

def print_welcome():
    print("=" * 80)
    print("  ATTENDSYNC INTERACTIVE QUERY CLI — PRESENTATION II EVALUATION")
    print("  Shaikh Humzah (Roll No: 25WU0102251) · Topic #26 · AIML Whales")
    print("=" * 80)
    print("  • Type ANY SQL query given by your examiner and press Enter.")
    print("  • Type '1' through '9' for instant 1-click Preset Viva Queries.")
    print("  • Type 'tables' to list all 12 schema tables.")
    print("  • Type 'desc <table_name>' to view table schema columns.")
    print("  • Type 'exit' or 'quit' to close.")
    print("=" * 80)
    print("PRESET VIVA QUERIES AVAILABLE:")
    for k, (name, _) in PRESETS.items():
        print(f"  [{k}] {name}")
    print("-" * 80)

def main():
    conn = get_connection()

    # Direct CLI argument support: e.g. python3 query_cli.py "SELECT * FROM students LIMIT 5;" or python3 query_cli.py 1
    if len(sys.argv) > 1:
        arg_query = " ".join(sys.argv[1:]).strip()
        if arg_query in PRESETS:
            name, sql = PRESETS[arg_query]
            print(f"\n--- Running Preset [{arg_query}]: {name} ---")
            print(f"SQL: {sql}\n")
            execute_query(conn, sql)
        elif arg_query.lower() == 'tables':
            execute_query(conn, "SELECT name AS table_name FROM sqlite_master WHERE type='table' AND name != 'sqlite_sequence';")
        elif arg_query.lower().startswith('desc ') or arg_query.lower().startswith('describe '):
            tbl = arg_query.split()[1].strip(";")
            execute_query(conn, f"PRAGMA table_info({tbl});")
        else:
            execute_query(conn, arg_query)
        conn.close()
        return

    print_welcome()

    buffer = []
    while True:
        try:
            prompt = "AttendSync SQL> " if not buffer else "            ...> "
            user_input = input(prompt)

            # If user wants to quit
            if not buffer and user_input.strip().lower() in ['exit', 'quit', 'q']:
                print("\nExiting SQL CLI. Good luck with Presentation II!")
                break

            if not buffer and user_input.strip().lower() == 'help':
                print_welcome()
                continue

            if not buffer and user_input.strip().lower() == 'tables':
                execute_query(conn, "SELECT name AS table_name FROM sqlite_master WHERE type='table' AND name != 'sqlite_sequence';")
                continue

            if not buffer and (user_input.strip().lower().startswith('desc ') or user_input.strip().lower().startswith('describe ')):
                tbl = user_input.strip().split()[1].strip(";")
                execute_query(conn, f"PRAGMA table_info({tbl});")
                continue

            # Check if 1-key preset (only if buffer is empty)
            if not buffer and user_input.strip() in PRESETS:
                name, sql = PRESETS[user_input.strip()]
                print(f"\n--- Running Preset [{user_input.strip()}]: {name} ---")
                print(f"SQL: {sql}\n")
                execute_query(conn, sql)
                continue

            # Accumulate query line
            stripped = user_input.strip()
            if not stripped and not buffer:
                continue

            buffer.append(user_input)

            # If statement ends with semicolon or is a single complete statement
            full_statement = " ".join(buffer).strip()
            if full_statement.endswith(";") or (not buffer[0].strip().endswith(";") and len(buffer) == 1 and not full_statement.upper().startswith(("SELECT", "WITH", "INSERT", "UPDATE", "DELETE", "CREATE"))):
                execute_query(conn, full_statement)
                buffer = []
            elif full_statement.endswith(";"):
                execute_query(conn, full_statement)
                buffer = []
            elif len(buffer) >= 1 and full_statement.endswith(";"):
                execute_query(conn, full_statement)
                buffer = []

        except (KeyboardInterrupt, EOFError):
            print("\nExiting SQL CLI.")
            break

    conn.close()

if __name__ == '__main__':
    main()

