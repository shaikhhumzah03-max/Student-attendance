# Student Attendance and Leave Approval System (Topic #26)
### DBMS Course Project — AIML Whales & Panthers
**Design and Implementation of a Relational Database Management System for Student Attendance and Leave Approval System.**

---

## Student Information
- **Name:** Shaikh Humzah
- **Roll Number:** 25WU0102251
- **Course:** Database Management Systems (CS301)
- **Section:** AIML Whales (Merged with AIML Panthers)
- **Topic Number:** Serial No. 26
- **One-Line Description:** A normalized 3NF relational database management system with an Apple-inspired minimalist light mode UI for real-time course-wise attendance tracking, multi-tier leave approval, shortage alerts, and interactive database table inspection.

---

## Repository Structure (Per Official Instructions)
```
humzah_dbms_26/
├── Presentation-I/
│   └── Presentation_I_Problem_Description.md  # Scope, objectives, stakeholders, requirements
├── Presentation-II/
│   ├── student_attendance_system_mysql.sql    # Full MySQL DDL, DML (270+ rows), views, triggers
│   ├── ER_Diagram_Specification.md            # Mermaid ER diagram & 3NF normalization proof
│   └── Presentation_II_Queries_and_Solutions.md # Complex queries, joins, relational algebra
├── Presentation-III/
│   ├── Presentation_III_UI_Demo_Guide.md      # Live demo script for Review 3 viva
│   └── UI_Screenshots_and_Flows.md            # Screen-by-screen breakdown (insert, delete, view)
├── Project-Report/
│   └── Comprehensive_DBMS_Project_Report.md   # Complete 16-section final project report
├── app/
│   ├── database.py                            # SQLite database schema, constraints, 270+ seed rows
│   ├── server.py                              # Zero-dependency Python REST API & web server
│   └── static/
│       ├── index.html                         # Apple minimalist light mode layout
│       ├── style.css                          # Apple HIG design system (SF Pro, Frosted Glass)
│       └── app.js                             # Vanilla JS SPA with Live CRUD & SQL Console
├── run.py                                     # One-click launch entrypoint (python3 run.py)
├── test_system.py                             # Automated test suite (6/6 tests passing)
└── README.md                                  # Repository overview and setup guide
```

---

## Key Features & Review 3 Highlights
1. **Proper Database of 270+ Realistic Entries:** Far exceeds the 60-entry minimum, spanning 12 normalized tables (`departments`, `faculty`, `courses`, `sections`, `students`, `class_sessions`, `attendance`, `leave_types`, `leave_applications`, `leave_approvals`, `makeup_sessions`, `shortage_alerts`).
2. **Apple-Inspired Minimalist Light Mode UI:** Clean white card surfaces (`#FFFFFF`), subtle canvas gray (`#F5F5F7`), SF Pro typography, translucent frosted headers (`backdrop-filter: blur(20px)`), and Apple Dynamic Island toast alerts.
3. **Live Real-Time CRUD Operations:**
   - **Create:** Insert new student or session; record immediately renders with smooth highlight pulse.
   - **Read:** Search and filter students, sessions, leaves, and table grids in real time.
   - **Update (Roll-Call):** 1-click status pills (`Present`, `Absent`, `Late`, `Excused`) atomically mutate the `attendance` table.
   - **Delete:** Remove records with instant DOM transition and database table counter updates.
4. **Dedicated Database Tables Inspector:** Inspect any of the 12 database tables, view column data types and primary keys, insert raw rows, delete rows, and witness live row count updates.
5. **Interactive SQL Console:** Run arbitrary raw SQL queries (`SELECT`, `JOIN`, `GROUP BY`, `DML`) with execution times reported in milliseconds.

---

## Quickstart Guide

### 1. Launch the Live Application
```bash
# Clone the repository
git clone https://github.com/shaikh-humzah/DBMS-Course-Project.git
cd DBMS-Course-Project

# Start the zero-dependency Python server
python3 run.py
```
Open **`http://localhost:8000`** in Safari or Chrome.

### 2. Run Verification Test Suite
```bash
python3 test_system.py
```
All 6 tests verify 3NF foreign key integrity, constraint enforcement, live CRUD, leave approval transactions, and aggregate views.

### 3. Import MySQL Database Script (For MySQL / MariaDB)
```bash
mysql -u root -p < Presentation-II/student_attendance_system_mysql.sql
```
