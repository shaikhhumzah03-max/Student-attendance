"""
Database Management Module for Student Attendance and Leave Approval System (Topic #26)
Student: Shaikh Humzah (Roll No: 25WU0102251)
Course: DBMS Course Project - AIML Whales
"""

import sqlite3
import os
from datetime import datetime, date

DB_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), "attendance_system.db")

SCHEMA_SQL = """
PRAGMA foreign_keys = ON;

-- 1. Departments
CREATE TABLE IF NOT EXISTS departments (
    department_id INTEGER PRIMARY KEY AUTOINCREMENT,
    dept_name TEXT NOT NULL UNIQUE,
    dept_code TEXT NOT NULL UNIQUE
);

-- 2. Faculty
CREATE TABLE IF NOT EXISTS faculty (
    faculty_id INTEGER PRIMARY KEY AUTOINCREMENT,
    full_name TEXT NOT NULL,
    email TEXT NOT NULL UNIQUE,
    phone TEXT,
    department_id INTEGER NOT NULL,
    designation TEXT NOT NULL,
    FOREIGN KEY (department_id) REFERENCES departments(department_id) ON DELETE RESTRICT
);

-- 3. Courses
CREATE TABLE IF NOT EXISTS courses (
    course_id INTEGER PRIMARY KEY AUTOINCREMENT,
    course_code TEXT NOT NULL UNIQUE,
    course_name TEXT NOT NULL,
    credits INTEGER NOT NULL CHECK (credits > 0),
    department_id INTEGER NOT NULL,
    semester INTEGER NOT NULL CHECK (semester BETWEEN 1 AND 8),
    FOREIGN KEY (department_id) REFERENCES departments(department_id) ON DELETE RESTRICT
);

-- 4. Sections
CREATE TABLE IF NOT EXISTS sections (
    section_id INTEGER PRIMARY KEY AUTOINCREMENT,
    section_name TEXT NOT NULL,
    course_id INTEGER NOT NULL,
    faculty_id INTEGER NOT NULL,
    academic_year TEXT NOT NULL,
    semester INTEGER NOT NULL,
    FOREIGN KEY (course_id) REFERENCES courses(course_id) ON DELETE CASCADE,
    FOREIGN KEY (faculty_id) REFERENCES faculty(faculty_id) ON DELETE RESTRICT
);

-- 5. Students
CREATE TABLE IF NOT EXISTS students (
    student_id INTEGER PRIMARY KEY AUTOINCREMENT,
    roll_no TEXT NOT NULL UNIQUE,
    full_name TEXT NOT NULL,
    email TEXT NOT NULL UNIQUE,
    phone TEXT,
    section_id INTEGER NOT NULL,
    semester INTEGER NOT NULL,
    admission_year INTEGER NOT NULL,
    FOREIGN KEY (section_id) REFERENCES sections(section_id) ON DELETE RESTRICT
);

-- 6. Class Sessions
CREATE TABLE IF NOT EXISTS class_sessions (
    session_id INTEGER PRIMARY KEY AUTOINCREMENT,
    section_id INTEGER NOT NULL,
    faculty_id INTEGER NOT NULL,
    session_date DATE NOT NULL,
    time_slot TEXT NOT NULL,
    room_no TEXT NOT NULL,
    topic_covered TEXT NOT NULL,
    status TEXT NOT NULL DEFAULT 'Conducted' CHECK (status IN ('Conducted', 'Scheduled', 'Cancelled')),
    FOREIGN KEY (section_id) REFERENCES sections(section_id) ON DELETE CASCADE,
    FOREIGN KEY (faculty_id) REFERENCES faculty(faculty_id) ON DELETE RESTRICT
);

-- 7. Attendance
CREATE TABLE IF NOT EXISTS attendance (
    attendance_id INTEGER PRIMARY KEY AUTOINCREMENT,
    session_id INTEGER NOT NULL,
    student_id INTEGER NOT NULL,
    status TEXT NOT NULL CHECK (status IN ('Present', 'Absent', 'Late', 'Excused')),
    marked_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    remarks TEXT,
    UNIQUE(session_id, student_id),
    FOREIGN KEY (session_id) REFERENCES class_sessions(session_id) ON DELETE CASCADE,
    FOREIGN KEY (student_id) REFERENCES students(student_id) ON DELETE CASCADE
);

-- 8. Leave Types
CREATE TABLE IF NOT EXISTS leave_types (
    leave_type_id INTEGER PRIMARY KEY AUTOINCREMENT,
    type_name TEXT NOT NULL UNIQUE,
    max_days_allowed INTEGER NOT NULL CHECK (max_days_allowed > 0),
    description TEXT
);

-- 9. Leave Applications
CREATE TABLE IF NOT EXISTS leave_applications (
    application_id INTEGER PRIMARY KEY AUTOINCREMENT,
    student_id INTEGER NOT NULL,
    leave_type_id INTEGER NOT NULL,
    start_date DATE NOT NULL,
    end_date DATE NOT NULL CHECK (end_date >= start_date),
    reason TEXT NOT NULL,
    applied_date DATE NOT NULL,
    status TEXT NOT NULL DEFAULT 'Pending' CHECK (status IN ('Pending', 'Approved', 'Rejected')),
    FOREIGN KEY (student_id) REFERENCES students(student_id) ON DELETE CASCADE,
    FOREIGN KEY (leave_type_id) REFERENCES leave_types(leave_type_id) ON DELETE RESTRICT
);

-- 10. Leave Approvals
CREATE TABLE IF NOT EXISTS leave_approvals (
    approval_id INTEGER PRIMARY KEY AUTOINCREMENT,
    application_id INTEGER NOT NULL UNIQUE,
    reviewed_by_faculty_id INTEGER NOT NULL,
    decision_date DATE NOT NULL,
    status TEXT NOT NULL CHECK (status IN ('Approved', 'Rejected')),
    comments TEXT,
    FOREIGN KEY (application_id) REFERENCES leave_applications(application_id) ON DELETE CASCADE,
    FOREIGN KEY (reviewed_by_faculty_id) REFERENCES faculty(faculty_id) ON DELETE RESTRICT
);

-- 11. Makeup Sessions
CREATE TABLE IF NOT EXISTS makeup_sessions (
    makeup_id INTEGER PRIMARY KEY AUTOINCREMENT,
    original_session_id INTEGER,
    section_id INTEGER NOT NULL,
    faculty_id INTEGER NOT NULL,
    scheduled_date DATE NOT NULL,
    time_slot TEXT NOT NULL,
    reason TEXT NOT NULL,
    status TEXT NOT NULL DEFAULT 'Scheduled' CHECK (status IN ('Scheduled', 'Completed', 'Cancelled')),
    FOREIGN KEY (original_session_id) REFERENCES class_sessions(session_id) ON DELETE SET NULL,
    FOREIGN KEY (section_id) REFERENCES sections(section_id) ON DELETE CASCADE,
    FOREIGN KEY (faculty_id) REFERENCES faculty(faculty_id) ON DELETE RESTRICT
);

-- 12. Shortage Alerts
CREATE TABLE IF NOT EXISTS shortage_alerts (
    alert_id INTEGER PRIMARY KEY AUTOINCREMENT,
    student_id INTEGER NOT NULL,
    course_id INTEGER NOT NULL,
    attendance_percentage REAL NOT NULL CHECK (attendance_percentage BETWEEN 0 AND 100),
    alert_level TEXT NOT NULL CHECK (alert_level IN ('Warning', 'Critical', 'Debarred')),
    generated_date DATE NOT NULL,
    is_resolved INTEGER NOT NULL DEFAULT 0 CHECK (is_resolved IN (0, 1)),
    FOREIGN KEY (student_id) REFERENCES students(student_id) ON DELETE CASCADE,
    FOREIGN KEY (course_id) REFERENCES courses(course_id) ON DELETE CASCADE
);

-- VIEWS
CREATE VIEW IF NOT EXISTS v_student_attendance_summary AS
SELECT 
    s.student_id,
    s.roll_no,
    s.full_name,
    sec.section_name,
    c.course_code,
    c.course_name,
    COUNT(a.attendance_id) AS total_sessions,
    SUM(CASE WHEN a.status IN ('Present', 'Late') THEN 1 ELSE 0 END) AS attended_sessions,
    SUM(CASE WHEN a.status = 'Absent' THEN 1 ELSE 0 END) AS absent_sessions,
    ROUND(
        CASE 
            WHEN COUNT(a.attendance_id) > 0 
            THEN (SUM(CASE WHEN a.status IN ('Present', 'Late') THEN 1.0 ELSE 0.0 END) * 100.0) / COUNT(a.attendance_id) 
            ELSE 0.0 
        END, 2
    ) AS attendance_percentage,
    CASE 
        WHEN COUNT(a.attendance_id) = 0 THEN 'No Data'
        WHEN (SUM(CASE WHEN a.status IN ('Present', 'Late') THEN 1.0 ELSE 0.0 END) * 100.0) / COUNT(a.attendance_id) >= 75.0 THEN 'Safe'
        WHEN (SUM(CASE WHEN a.status IN ('Present', 'Late') THEN 1.0 ELSE 0.0 END) * 100.0) / COUNT(a.attendance_id) >= 65.0 THEN 'Warning'
        ELSE 'Critical Shortage'
    END AS status_badge
FROM students s
JOIN sections sec ON s.section_id = sec.section_id
JOIN courses c ON sec.course_id = c.course_id
LEFT JOIN class_sessions cs ON cs.section_id = sec.section_id
LEFT JOIN attendance a ON a.session_id = cs.session_id AND a.student_id = s.student_id
GROUP BY s.student_id, c.course_id;

CREATE VIEW IF NOT EXISTS v_pending_leave_applications AS
SELECT 
    la.application_id,
    s.roll_no,
    s.full_name AS student_name,
    lt.type_name AS leave_type,
    la.start_date,
    la.end_date,
    CAST((julianday(la.end_date) - julianday(la.start_date) + 1) AS INTEGER) AS total_days,
    la.reason,
    la.applied_date,
    la.status
FROM leave_applications la
JOIN students s ON la.student_id = s.student_id
JOIN leave_types lt ON la.leave_type_id = lt.leave_type_id
WHERE la.status = 'Pending';
"""

def get_connection():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    return conn

def init_database():
    conn = get_connection()
    cursor = conn.cursor()
    cursor.executescript(SCHEMA_SQL)
    conn.commit()
    conn.close()

def seed_database():
    """Populate database with rich realistic records exceeding 60+ entries"""
    conn = get_connection()
    cursor = conn.cursor()

    # Clear existing tables
    tables = [
        'shortage_alerts', 'makeup_sessions', 'leave_approvals', 'leave_applications',
        'leave_types', 'attendance', 'class_sessions', 'students', 'sections',
        'courses', 'faculty', 'departments'
    ]
    for tbl in tables:
        cursor.execute(f"DELETE FROM {tbl};")
        cursor.execute(f"DELETE FROM sqlite_sequence WHERE name='{tbl}';")

    # 1. Departments (4 records)
    departments = [
        ('Computer Science & Engineering', 'CSE'),
        ('Artificial Intelligence & Machine Learning', 'AIML'),
        ('Data Science & Engineering', 'DSE'),
        ('Electronics & Communication Engineering', 'ECE')
    ]
    cursor.executemany("INSERT INTO departments (dept_name, dept_code) VALUES (?, ?)", departments)

    # 2. Faculty (8 records)
    faculty = [
        ('Dr. Arisetti V. Rao', 'avrao@university.edu', '+91 98480 11223', 1, 'Professor & HOD'),
        ('Prof. Meenakshi Sundaram', 'meenakshi.s@university.edu', '+91 98480 22334', 2, 'Associate Professor'),
        ('Dr. Rajesh Nambiar', 'rajesh.n@university.edu', '+91 98480 33445', 2, 'Assistant Professor'),
        ('Dr. Priya Swaminathan', 'priya.s@university.edu', '+91 98480 44556', 1, 'Associate Professor'),
        ('Prof. K. Venkatesh', 'k.venkatesh@university.edu', '+91 98480 55667', 3, 'Assistant Professor'),
        ('Dr. Shalini Deshmukh', 'shalini.d@university.edu', '+91 98480 66778', 4, 'Professor'),
        ('Prof. Anand Vardhan', 'anand.v@university.edu', '+91 98480 77889', 2, 'Assistant Professor'),
        ('Dr. Sunita Kulkarni', 'sunita.k@university.edu', '+91 98480 88990', 1, 'Associate Professor')
    ]
    cursor.executemany("""
        INSERT INTO faculty (full_name, email, phone, department_id, designation)
        VALUES (?, ?, ?, ?, ?)
    """, faculty)

    # 3. Courses (6 records)
    courses = [
        ('CS301', 'Database Management Systems', 4, 1, 4),
        ('AI302', 'Machine Learning Foundations', 4, 2, 4),
        ('CS303', 'Operating Systems & Concurrency', 3, 1, 4),
        ('AI304', 'Deep Neural Networks', 4, 2, 4),
        ('DS305', 'Data Warehousing & Mining', 3, 3, 4),
        ('EC306', 'Microcontrollers & Embedded Systems', 3, 4, 4)
    ]
    cursor.executemany("""
        INSERT INTO courses (course_code, course_name, credits, department_id, semester)
        VALUES (?, ?, ?, ?, ?)
    """, courses)

    # 4. Sections (6 records)
    sections = [
        ('AIML-A (Whales)', 1, 2, '2025-2026', 4),  # DBMS - Prof Meenakshi
        ('AIML-B (Panthers)', 1, 3, '2025-2026', 4),# DBMS - Dr Rajesh
        ('AIML-A (Whales)', 2, 7, '2025-2026', 4),  # ML - Prof Anand
        ('CSE-A', 3, 4, '2025-2026', 4),           # OS - Dr Priya
        ('AIML-A (Whales)', 4, 2, '2025-2026', 4),  # DNN - Prof Meenakshi
        ('DSE-A', 5, 5, '2025-2026', 4)            # DWM - Prof Venkatesh
    ]
    cursor.executemany("""
        INSERT INTO sections (section_name, course_id, faculty_id, academic_year, semester)
        VALUES (?, ?, ?, ?, ?)
    """, sections)

    # 5. Students (24 records)
    students = [
        ('25WU0102251', 'Shaikh Humzah', 'shaikh.humzah@univ.edu', '+91 91234 56701', 1, 4, 2024),
        ('25WU0102138', 'M Pranay Kumar Reddy', 'pranay.reddy@univ.edu', '+91 91234 56702', 2, 4, 2024),
        ('25WU0102243', 'Sanjyit Suresh Kumar', 'sanjyit.sk@univ.edu', '+91 91234 56703', 1, 4, 2024),
        ('25WU0102128', 'Konduru Sharva Teja', 'sharva.teja@univ.edu', '+91 91234 56704', 2, 4, 2024),
        ('25WU0102253', 'Gandla Sharvari', 'gandla.sharvari@univ.edu', '+91 91234 56705', 1, 4, 2024),
        ('25WU0102142', 'Maddala Sai Chethana', 'chethana.m@univ.edu', '+91 91234 56706', 2, 4, 2024),
        ('25WU0102250', 'Shaik Abdul Raheem', 'abdul.raheem@univ.edu', '+91 91234 56707', 1, 4, 2024),
        ('25WU0102137', 'Lingampally Mohith', 'mohith.l@univ.edu', '+91 91234 56708', 2, 4, 2024),
        ('25WU0102248', 'Sashrika Reddy Alimity', 'sashrika.r@univ.edu', '+91 91234 56709', 1, 4, 2024),
        ('25WU0102134', 'Kurakula Harshitha', 'harshitha.k@univ.edu', '+91 91234 56710', 2, 4, 2024),
        ('25WU0102249', 'Settipalli Satwik Siva Sai', 'satwik.s@univ.edu', '+91 91234 56711', 1, 4, 2024),
        ('25WU0102135', 'Lade Bilvesh Datta', 'bilvesh.d@univ.edu', '+91 91234 56712', 2, 4, 2024),
        ('25WU0102252', 'Shailesh Charan Pathlavath', 'shailesh.c@univ.edu', '+91 91234 56713', 1, 4, 2024),
        ('25WU0102139', 'M Sai Manoj', 'sai.manoj@univ.edu', '+91 91234 56714', 2, 4, 2024),
        ('25WU0102254', 'Shaurya Dhingra', 'shaurya.d@univ.edu', '+91 91234 56715', 1, 4, 2024),
        ('25WU0102144', 'Mallavarapu Suchith', 'suchith.m@univ.edu', '+91 91234 56716', 2, 4, 2024),
        ('25WU0102255', 'Sheikh Arsh Ali', 'arsh.ali@univ.edu', '+91 91234 56717', 1, 4, 2024),
        ('25WU0102146', 'Mamunoori Reethu Chandra', 'reethu.c@univ.edu', '+91 91234 56718', 2, 4, 2024),
        ('25WU0102258', 'Shrestha Mal', 'shrestha.mal@univ.edu', '+91 91234 56719', 1, 4, 2024),
        ('25WU0102147', 'Manash Roy', 'manash.roy@univ.edu', '+91 91234 56720', 2, 4, 2024),
        ('25WU0102260', 'Shudhanshu Shekhar', 'shudhanshu.s@univ.edu', '+91 91234 56721', 1, 4, 2024),
        ('25WU0102149', 'Mane Heya', 'heya.mane@univ.edu', '+91 91234 56722', 2, 4, 2024),
        ('25WU0102262', 'Siddhant Agarwal', 'siddhant.a@univ.edu', '+91 91234 56723', 1, 4, 2024),
        ('25WU0102151', 'Manthena Naga Sri Rohan', 'rohan.m@univ.edu', '+91 91234 56724', 2, 4, 2024)
    ]
    cursor.executemany("""
        INSERT INTO students (roll_no, full_name, email, phone, section_id, semester, admission_year)
        VALUES (?, ?, ?, ?, ?, ?, ?)
    """, students)

    # 6. Class Sessions (15 records)
    sessions = [
        (1, 2, '2026-09-01', '09:00 - 10:00 AM', 'LH-201', 'Introduction to Relational DBMS & ER Modeling', 'Conducted'),
        (1, 2, '2026-09-03', '09:00 - 10:00 AM', 'LH-201', 'Relational Algebra & Tuple Relational Calculus', 'Conducted'),
        (1, 2, '2026-09-08', '09:00 - 10:00 AM', 'LH-201', 'SQL DDL, DML and Integrity Constraints', 'Conducted'),
        (1, 2, '2026-09-10', '09:00 - 10:00 AM', 'LH-201', 'Complex SQL Joins and Subqueries', 'Conducted'),
        (1, 2, '2026-09-15', '09:00 - 10:00 AM', 'LH-201', 'Functional Dependencies & Normal Forms (1NF, 2NF, 3NF)', 'Conducted'),
        (1, 2, '2026-09-17', '09:00 - 10:00 AM', 'LH-201', 'BCNF and Multivalued Dependencies', 'Conducted'),
        (1, 2, '2026-09-22', '09:00 - 10:00 AM', 'LH-201', 'Transaction Processing, ACID & Serializability', 'Conducted'),
        (1, 2, '2026-09-24', '09:00 - 10:00 AM', 'LH-201', 'Concurrency Control: Two-Phase Locking & Timestamping', 'Conducted'),
        (1, 2, '2026-09-29', '09:00 - 10:00 AM', 'LH-201', 'Indexing & B+ Trees in Relational Engines', 'Conducted'),
        (1, 2, '2026-10-01', '09:00 - 10:00 AM', 'LH-201', 'Database Security, Views and Grant Management', 'Conducted'),
        (2, 3, '2026-09-02', '10:00 - 11:00 AM', 'LH-202', 'Relational Model Fundamentals', 'Conducted'),
        (2, 3, '2026-09-04', '10:00 - 11:00 AM', 'LH-202', 'SQL Queries & Aggregations', 'Conducted'),
        (2, 3, '2026-09-09', '10:00 - 11:00 AM', 'LH-202', 'Normalization & 3NF Decomposition', 'Conducted'),
        (1, 2, '2026-10-08', '09:00 - 10:00 AM', 'LH-201', 'NoSQL & Distributed Relational Scaling', 'Scheduled'),
        (1, 2, '2026-10-10', '09:00 - 10:00 AM', 'LH-201', 'Review-3 Final Project UI & DB Evaluation', 'Scheduled')
    ]
    cursor.executemany("""
        INSERT INTO class_sessions (section_id, faculty_id, session_date, time_slot, room_no, topic_covered, status)
        VALUES (?, ?, ?, ?, ?, ?, ?)
    """, sessions)

    # 7. Attendance Records (120+ entries across conducted sessions)
    # Students 1, 3, 5, 7, 9, 11, 13, 15, 17, 19, 21, 23 belong to Section 1 (AIML-A)
    whales_student_ids = [1, 3, 5, 7, 9, 11, 13, 15, 17, 19, 21, 23]
    # Conducted sessions for Section 1 are session_ids 1 to 10
    conducted_whales_sessions = list(range(1, 11))
    
    attendance_records = []
    # Humzah (id 1): high attendance (9/10 present)
    # Sanjyit (id 3): 10/10 present
    # Sharvari (id 5): 8/10 present
    # Abdul Raheem (id 7): 6/10 (Shortage warning ~60%)
    # Shaurya Dhingra (id 15): 5/10 (Critical shortage 50%)
    
    for s_idx, sid in enumerate(whales_student_ids):
        for sess_id in conducted_whales_sessions:
            if sid == 1: # Humzah (our student)
                st = 'Present' if sess_id != 6 else 'Late'
                rem = 'On time' if st == 'Present' else 'Permitted 5 mins late'
            elif sid == 3: # Sanjyit
                st = 'Present'
                rem = 'Participated in class'
            elif sid == 7: # Abdul Raheem (Shortage case)
                st = 'Present' if sess_id in [1, 2, 4, 5, 8, 9] else 'Absent'
                rem = 'Verified' if st == 'Present' else 'Unexcused absence'
            elif sid == 15: # Shaurya (Critical shortage case)
                st = 'Present' if sess_id in [1, 3, 5, 7, 9] else 'Absent'
                rem = 'Marked by faculty' if st == 'Present' else 'Medical leave pending'
            elif sid == 17: # Sheikh Arsh Ali
                st = 'Present' if sess_id not in [3, 7] else 'Excused'
                rem = 'Sports club event' if st == 'Excused' else 'Present'
            else:
                # realistic general pattern
                st = 'Present' if (sid + sess_id) % 5 != 0 else 'Absent'
                rem = 'Automated session scan' if st == 'Present' else 'Absent'

            attendance_records.append((sess_id, sid, st, rem))

    # Also add Section 2 attendance for conducted sessions 11, 12, 13
    panthers_student_ids = [2, 4, 6, 8, 10, 12, 14, 16, 18, 20, 22, 24]
    for sid in panthers_student_ids:
        for sess_id in [11, 12, 13]:
            st = 'Present' if (sid + sess_id) % 4 != 0 else 'Absent'
            rem = 'Regular mark'
            attendance_records.append((sess_id, sid, st, rem))

    cursor.executemany("""
        INSERT INTO attendance (session_id, student_id, status, remarks)
        VALUES (?, ?, ?, ?)
    """, attendance_records)

    # 8. Leave Types (5 records)
    leave_types = [
        ('Medical Leave', 10, 'Health illness, hospitalization, or physician mandated rest with medical certificate'),
        ('Academic / Conference Leave', 7, 'Attending recognized workshops, paper presentations, or hackathons'),
        ('On Duty (OD) / Event Leave', 5, 'Representing college in sports, cultural, or student club activities'),
        ('Personal / Casual Leave', 3, 'Family emergency, urgent personal affairs with parent consent'),
        ('Bereavement Leave', 5, 'Compassionate leave for immediate family bereavements')
    ]
    cursor.executemany("""
        INSERT INTO leave_types (type_name, max_days_allowed, description)
        VALUES (?, ?, ?)
    """, leave_types)

    # 9. Leave Applications (16 records)
    leave_applications = [
        (1, 2, '2026-09-16', '2026-09-17', 'Attending IEEE Student Conference in Hyderabad to present DBMS paper', '2026-09-12', 'Approved'),
        (7, 1, '2026-09-10', '2026-09-12', 'Severe viral infection and fever under prescription', '2026-09-09', 'Approved'),
        (15, 1, '2026-09-14', '2026-09-18', 'Undergoing medical diagnostic checkups and quarantine for jaundice', '2026-09-13', 'Pending'),
        (17, 3, '2026-09-21', '2026-09-23', 'Representing university in Inter-Collegiate Football Championship', '2026-09-18', 'Approved'),
        (3, 4, '2026-09-25', '2026-09-25', 'Sister wedding ceremony out of station', '2026-09-20', 'Approved'),
        (5, 1, '2026-09-28', '2026-09-29', 'Severe migraine and dental procedure', '2026-09-27', 'Approved'),
        (9, 2, '2026-10-02', '2026-10-04', 'Smart India Hackathon Zonal Round Participation', '2026-09-29', 'Approved'),
        (11, 4, '2026-10-05', '2026-10-06', 'Family relocation and house shifting assistance', '2026-10-01', 'Rejected'),
        (13, 1, '2026-10-06', '2026-10-07', 'Seasonal flu with medical prescription attached', '2026-10-05', 'Pending'),
        (2, 3, '2026-09-15', '2026-09-16', 'Organizing campus technical symposium (Whales & Panthers)', '2026-09-10', 'Approved'),
        (4, 1, '2026-09-18', '2026-09-19', 'Hospitalized for acute allergic reaction', '2026-09-17', 'Approved'),
        (6, 2, '2026-09-22', '2026-09-24', 'ACM ICPC Regional Preliminary Contest travel', '2026-09-19', 'Approved'),
        (8, 4, '2026-09-29', '2026-09-30', 'Personal vacation trip', '2026-09-25', 'Rejected'),
        (10, 1, '2026-10-08', '2026-10-09', 'Fracture follow-up consultation with orthopedic surgeon', '2026-10-06', 'Pending'),
        (12, 3, '2026-10-07', '2026-10-08', 'National Robotics League demonstration in Bangalore', '2026-10-04', 'Pending'),
        (14, 1, '2026-10-03', '2026-10-04', 'Typhoid recovery follow up', '2026-10-02', 'Approved')
    ]
    cursor.executemany("""
        INSERT INTO leave_applications (student_id, leave_type_id, start_date, end_date, reason, applied_date, status)
        VALUES (?, ?, ?, ?, ?, ?, ?)
    """, leave_applications)

    # 10. Leave Approvals (12 records)
    leave_approvals = [
        (1, 2, '2026-09-14', 'Approved', 'Conference invite verified. Attendance waiver granted for 2 days.'),
        (2, 2, '2026-09-10', 'Approved', 'Medical certificate from Govt hospital verified.'),
        (4, 2, '2026-09-19', 'Approved', 'Approved by sports directorate and HOD.'),
        (5, 2, '2026-09-21', 'Approved', 'Parental confirmation email received and confirmed.'),
        (6, 2, '2026-09-28', 'Approved', 'Medical note accepted. Ensure makeup sessions attended.'),
        (7, 2, '2026-09-30', 'Approved', 'Hackathon permission letter countersigned.'),
        (8, 2, '2026-10-02', 'Rejected', 'Personal leave without prior approval during exam preparatory week.'),
        (10, 3, '2026-09-11', 'Approved', 'Symposium organizing committee approval granted.'),
        (11, 3, '2026-09-18', 'Approved', 'Valid hospitalization documents uploaded.'),
        (12, 3, '2026-09-20', 'Approved', 'Official university delegation to ICPC.'),
        (13, 3, '2026-09-26', 'Rejected', 'Personal travel cannot be excused as formal leave.'),
        (16, 3, '2026-10-03', 'Approved', 'Medical fitness certificate submitted.')
    ]
    cursor.executemany("""
        INSERT INTO leave_approvals (application_id, reviewed_by_faculty_id, decision_date, status, comments)
        VALUES (?, ?, ?, ?, ?)
    """, leave_approvals)

    # 11. Makeup Sessions (8 records)
    makeup_sessions = [
        (6, 1, 2, '2026-09-19', '03:00 - 04:30 PM', 'Makeup class for BCNF and Multivalued Dependencies', 'Completed'),
        (7, 1, 2, '2026-09-26', '02:00 - 03:30 PM', 'Makeup session for ACID Transactions and Recovery', 'Completed'),
        (11, 2, 3, '2026-09-05', '03:30 - 05:00 PM', 'Extra tutorial on Relational Algebra proofs', 'Completed'),
        (None, 1, 2, '2026-10-09', '02:30 - 04:00 PM', 'Pre-exam revision lab for students with < 75% attendance', 'Scheduled'),
        (None, 2, 3, '2026-10-10', '03:00 - 04:30 PM', 'Remedial SQL Subqueries and Views workshop', 'Scheduled'),
        (8, 1, 2, '2026-09-27', '04:00 - 05:30 PM', 'Concurrency control problem solving clinic', 'Completed'),
        (None, 4, 4, '2026-10-12', '10:00 - 11:30 AM', 'Operating Systems Semaphore makeup lab', 'Scheduled'),
        (None, 1, 2, '2026-10-14', '03:00 - 04:30 PM', 'Review 3 SQL viva preparation session', 'Scheduled')
    ]
    cursor.executemany("""
        INSERT INTO makeup_sessions (original_session_id, section_id, faculty_id, scheduled_date, time_slot, reason, status)
        VALUES (?, ?, ?, ?, ?, ?, ?)
    """, makeup_sessions)

    # 12. Shortage Alerts (10 records)
    alerts = [
        (7, 1, 60.0, 'Warning', '2026-09-25', 0),
        (15, 1, 50.0, 'Critical', '2026-09-25', 0),
        (17, 1, 70.0, 'Warning', '2026-09-26', 1), # resolved via sports leave
        (11, 1, 60.0, 'Warning', '2026-09-28', 0),
        (21, 1, 70.0, 'Warning', '2026-09-30', 0),
        (8, 1, 66.7, 'Warning', '2026-09-25', 0),
        (14, 1, 66.7, 'Warning', '2026-09-25', 1),
        (20, 1, 33.3, 'Debarred', '2026-10-02', 0),
        (24, 1, 66.7, 'Warning', '2026-10-02', 0),
        (22, 1, 66.7, 'Warning', '2026-10-02', 1)
    ]
    cursor.executemany("""
        INSERT INTO shortage_alerts (student_id, course_id, attendance_percentage, alert_level, generated_date, is_resolved)
        VALUES (?, ?, ?, ?, ?, ?)
    """, alerts)

    conn.commit()
    
    # Calculate row count summary
    summary = {}
    for tbl in tables:
        c = cursor.execute(f"SELECT COUNT(*) FROM {tbl}").fetchone()[0]
        summary[tbl] = c
    
    conn.close()
    return summary

if __name__ == '__main__':
    init_database()
    counts = seed_database()
    print("Database Initialized and Seeded Successfully!")
    total = sum(counts.values())
    print(f"Total Records Seeded: {total}")
    for k, v in counts.items():
        print(f"  - {k}: {v} rows")
