/**
 * Apple-Inspired Client SPA for Student Attendance & Leave Approval System (Topic #26)
 * Student: Shaikh Humzah (Roll No: 25WU0102251) - AIML Whales
 */

// Global State
let currentTab = 'dashboard';
let appOptions = { departments: [], faculty: [], courses: [], sections: [], leave_types: [] };
let activeInspectorTable = 'students';
let activeAttendanceSessionId = null;

// Document Ready
document.addEventListener('DOMContentLoaded', () => {
  initNavigation();
  initModals();
  initSqlConsole();
  fetchOptions();
  loadDashboardData();
  
  // Set default inspector table
  initTableInspector();
});

/* ----------------- DYNAMIC ISLAND TOAST NOTIFICATION ----------------- */
function showIslandToast(title, subtitle, type = 'success') {
  const island = document.getElementById('dynamic-island');
  const icon = document.getElementById('island-icon');
  const titleEl = document.getElementById('island-title');
  const subEl = document.getElementById('island-subtitle');

  titleEl.textContent = title;
  subEl.textContent = subtitle;

  icon.className = 'island-icon ' + (type === 'danger' ? 'danger' : (type === 'blue' ? 'blue' : ''));
  icon.textContent = type === 'danger' ? '✕' : (type === 'blue' ? 'ℹ' : '✓');

  island.classList.add('visible');
  clearTimeout(window.__islandTimer);
  window.__islandTimer = setTimeout(() => {
    island.classList.remove('visible');
  }, 3200);
}

/* ----------------- NAVIGATION & TABS ----------------- */
function initNavigation() {
  const navItems = document.querySelectorAll('.nav-item');
  const tabViews = document.querySelectorAll('.tab-view');
  const pageTitle = document.getElementById('page-title');
  const pageSubtitle = document.getElementById('page-subtitle');
  const primaryActionText = document.getElementById('primary-action-text');

  const tabTitles = {
    dashboard: { title: 'Dashboard Overview', sub: 'Real-time attendance metrics and institutional statistics', action: '+ New Student' },
    students: { title: 'Students Management', sub: 'Full CRUD operations with live database synchronization', action: '+ New Student' },
    attendance: { title: 'Live Attendance Sheet', sub: 'Real-time roll-call marking and instant percentage recalculation', action: '+ New Session' },
    sessions: { title: 'Class Sessions', sub: 'Institutional lecture and lab scheduling records', action: '+ New Session' },
    leaves: { title: 'Leave Applications', sub: 'Multi-tier student leave requests and faculty approvals', action: '+ Submit Leave' },
    alerts: { title: 'Shortage Alerts', sub: 'Mandatory monitoring of students below 75% attendance', action: '⚡ Run Audit' },
    tables: { title: 'Database Tables Inspector', sub: 'Review 3 live schema inspection, row counts, and table mutations', action: '+ Insert Row' },
    sql: { title: 'Interactive SQL Console', sub: 'Execute raw queries, joins, and aggregates directly on SQLite', action: '▶ Execute SQL' }
  };

  navItems.forEach(btn => {
    btn.addEventListener('click', () => {
      const target = btn.dataset.tab;
      if (!target) return;
      switchTab(target);
    });
  });

  // Header quick buttons
  document.getElementById('btn-quick-sql').addEventListener('click', () => switchTab('sql'));
  document.getElementById('btn-inspect-all-tables').addEventListener('click', () => switchTab('tables'));
  document.getElementById('btn-primary-action').addEventListener('click', handlePrimaryHeaderAction);
  document.getElementById('btn-reset-db').addEventListener('click', handleResetDatabase);
}

function switchTab(target) {
  currentTab = target;
  document.querySelectorAll('.nav-item').forEach(b => b.classList.toggle('active', b.dataset.tab === target));
  document.querySelectorAll('.tab-view').forEach(v => v.classList.toggle('active', v.id === `view-${target}`));

  const tabTitles = {
    dashboard: { title: 'Dashboard Overview', sub: 'Real-time attendance metrics and institutional statistics', action: '+ New Student' },
    students: { title: 'Students Management', sub: 'Full CRUD operations with live database synchronization', action: '+ New Student' },
    attendance: { title: 'Live Attendance Sheet', sub: 'Real-time roll-call marking and instant percentage recalculation', action: '+ New Session' },
    sessions: { title: 'Class Sessions', sub: 'Institutional lecture and lab scheduling records', action: '+ New Session' },
    leaves: { title: 'Leave Applications', sub: 'Multi-tier student leave requests and faculty approvals', action: '+ Submit Leave' },
    alerts: { title: 'Shortage Alerts', sub: 'Mandatory monitoring of students below 75% attendance', action: '⚡ Run Audit' },
    tables: { title: 'Database Tables Inspector', sub: 'Review 3 live schema inspection, row counts, and table mutations', action: '+ Insert Row' },
    sql: { title: 'Interactive SQL Console', sub: 'Execute raw queries, joins, and aggregates directly on SQLite', action: '▶ Execute SQL' }
  };

  const info = tabTitles[target] || { title: 'Portal', sub: '', action: 'Action' };
  document.getElementById('page-title').textContent = info.title;
  document.getElementById('page-subtitle').textContent = info.sub;
  document.getElementById('primary-action-text').textContent = info.action;

  // Trigger data reload for active tab
  if (target === 'dashboard') loadDashboardData();
  else if (target === 'students') loadStudentsData();
  else if (target === 'attendance') loadAttendanceSessions();
  else if (target === 'sessions') loadSessionsData();
  else if (target === 'leaves') loadLeavesData();
  else if (target === 'alerts') loadAlertsData();
  else if (target === 'tables') loadInspectorTableData(activeInspectorTable);
}

function handlePrimaryHeaderAction() {
  if (currentTab === 'dashboard' || currentTab === 'students') {
    openModal('modal-student');
  } else if (currentTab === 'attendance' || currentTab === 'sessions') {
    openModal('modal-session');
  } else if (currentTab === 'leaves') {
    openModal('modal-leave');
  } else if (currentTab === 'alerts') {
    runShortageAudit();
  } else if (currentTab === 'tables') {
    openInsertRowModal();
  } else if (currentTab === 'sql') {
    executeSqlQuery();
  }
}

/* ----------------- OPTIONS & DROPDOWNS ----------------- */
async function fetchOptions() {
  try {
    const res = await fetch('/api/options');
    appOptions = await res.json();
    populateDropdowns();
  } catch (err) {
    console.error('Failed to load options:', err);
  }
}

function populateDropdowns() {
  // Student modal sections
  const secSelect = document.getElementById('student-section');
  secSelect.innerHTML = appOptions.sections.map(s => 
    `<option value="${s.section_id}">${s.section_name} — ${s.course_code}: ${s.course_name}</option>`
  ).join('');

  // Session modal sections
  const sessSec = document.getElementById('session-section');
  sessSec.innerHTML = appOptions.sections.map(s => 
    `<option value="${s.section_id}">${s.section_name} (${s.course_code})</option>`
  ).join('');

  // Session modal faculty
  const sessFac = document.getElementById('session-faculty');
  sessFac.innerHTML = appOptions.faculty.map(f => 
    `<option value="${f.faculty_id}">${f.full_name} (${f.designation})</option>`
  ).join('');

  // Leave student dropdown
  // populated when students load
  const leaveTypeSelect = document.getElementById('leave-type');
  leaveTypeSelect.innerHTML = appOptions.leave_types.map(lt => 
    `<option value="${lt.leave_type_id}">${lt.type_name} (Max ${lt.max_days_allowed} Days)</option>`
  ).join('');
}

/* ----------------- 1. DASHBOARD OVERVIEW ----------------- */
async function loadDashboardData() {
  try {
    const res = await fetch('/api/stats');
    const data = await res.json();

    document.getElementById('kpi-attendance-rate').textContent = `${data.overall_attendance_rate}%`;
    document.getElementById('kpi-students-count').textContent = data.students_count;
    document.getElementById('kpi-sessions-count').textContent = data.sessions_count;
    document.getElementById('kpi-db-records').textContent = data.total_db_records;
    document.getElementById('sidebar-total-records').textContent = `${data.total_db_records} Records`;
    document.getElementById('sidebar-leave-badge').textContent = data.pending_leaves;

    // Render table counts breakdown
    const container = document.getElementById('dashboard-table-counts');
    container.innerHTML = Object.entries(data.table_counts).map(([tbl, count]) => `
      <div class="tbl-chip" onclick="inspectSpecificTable('${tbl}')">
        <div class="tbl-chip-name">${tbl}</div>
        <div class="tbl-chip-count">${count}</div>
      </div>
    `).join('');

    // Load Mini Shortage
    loadDashboardShortage();
  } catch (err) {
    console.error('Failed to load dashboard:', err);
  }
}

async function loadDashboardShortage() {
  try {
    const res = await fetch('/api/reports/shortage');
    const data = await res.json();
    const container = document.getElementById('dashboard-shortage-list');

    if (!data.shortage_students || data.shortage_students.length === 0) {
      container.innerHTML = `<p class="card-sub">No students currently in shortage!</p>`;
      return;
    }

    container.innerHTML = data.shortage_students.slice(0, 5).map(s => `
      <div class="shortage-mini-item">
        <div>
          <div class="shortage-student-title">${s.full_name} (${s.roll_no})</div>
          <div class="shortage-student-sub">${s.course_code} · Attended ${s.attended_sessions}/${s.total_sessions} sessions</div>
        </div>
        <div>
          <span class="pill pill-critical">${s.attendance_percentage}%</span>
        </div>
      </div>
    `).join('');
  } catch (err) {
    console.error('Shortage list error:', err);
  }
}

function inspectSpecificTable(tbl) {
  activeInspectorTable = tbl;
  switchTab('tables');
}

/* ----------------- 2. STUDENTS (LIVE CRUD) ----------------- */
async function loadStudentsData() {
  const search = document.getElementById('students-search').value.trim();
  const activeSegment = document.querySelector('#section-filter-segment .segment-btn.active');
  const sectionFilter = activeSegment ? activeSegment.dataset.filter : '';

  try {
    const url = `/api/students?q=${encodeURIComponent(search)}&section_id=${sectionFilter}`;
    const res = await fetch(url);
    const data = await res.json();

    const tbody = document.getElementById('students-table-body');
    if (!data.students || data.students.length === 0) {
      tbody.innerHTML = `<tr><td colspan="8" style="text-align:center; padding: 24px; color: var(--apple-text-secondary);">No student records found.</td></tr>`;
      return;
    }

    tbody.innerHTML = data.students.map(s => `
      <tr id="student-row-${s.student_id}">
        <td><strong>#${s.student_id}</strong></td>
        <td><code>${s.roll_no}</code></td>
        <td><strong>${s.full_name}</strong></td>
        <td>
          <div>${s.email}</div>
          <div style="font-size:11px; color:var(--apple-text-secondary);">${s.phone || 'N/A'}</div>
        </td>
        <td>
          <div>${s.section_name}</div>
          <div style="font-size:11px; color:var(--apple-text-secondary);">${s.course_code}</div>
        </td>
        <td>
          <strong>${s.attendance_percentage}%</strong>
          <div style="font-size:10px; color:var(--apple-text-secondary);">${s.total_attended}/${s.total_marked} classes</div>
        </td>
        <td>
          <span class="pill pill-${s.status_badge.toLowerCase().replace(' ', '-')}">${s.status_badge}</span>
        </td>
        <td class="text-right">
          <div class="table-actions">
            <button class="btn-action-sm" onclick="editStudent(${JSON.stringify(s).replace(/"/g, '&quot;')})">Edit</button>
            <button class="btn-action-sm danger" onclick="deleteStudent(${s.student_id}, '${s.full_name}', '${s.roll_no}')">Delete</button>
          </div>
        </td>
      </tr>
    `).join('');

    // Update leave applicant student dropdown
    const leaveStudentSelect = document.getElementById('leave-student');
    if (leaveStudentSelect) {
      leaveStudentSelect.innerHTML = data.students.map(s => 
        `<option value="${s.student_id}">${s.roll_no} — ${s.full_name}</option>`
      ).join('');
    }
  } catch (err) {
    console.error('Failed to load students:', err);
  }
}

// Search & Filter listeners
document.getElementById('students-search').addEventListener('input', debounce(loadStudentsData, 250));
document.querySelectorAll('#section-filter-segment .segment-btn').forEach(btn => {
  btn.addEventListener('click', () => {
    document.querySelectorAll('#section-filter-segment .segment-btn').forEach(b => b.classList.remove('active'));
    btn.classList.add('active');
    loadStudentsData();
  });
});

document.getElementById('btn-add-student-modal').addEventListener('click', () => {
  document.getElementById('form-student').reset();
  document.getElementById('student-form-id').value = '';
  document.getElementById('modal-student-title').textContent = 'Add New Student';
  openModal('modal-student');
});

function editStudent(s) {
  document.getElementById('student-form-id').value = s.student_id;
  document.getElementById('student-roll').value = s.roll_no;
  document.getElementById('student-name').value = s.full_name;
  document.getElementById('student-email').value = s.email;
  document.getElementById('student-phone').value = s.phone || '';
  document.getElementById('student-section').value = s.section_id;
  document.getElementById('student-semester').value = s.semester || 4;
  document.getElementById('modal-student-title').textContent = `Edit Student: ${s.roll_no}`;
  openModal('modal-student');
}

// Student Form Submit (Insert / Update)
document.getElementById('form-student').addEventListener('submit', async (e) => {
  e.preventDefault();
  const id = document.getElementById('student-form-id').value;
  const payload = {
    roll_no: document.getElementById('student-roll').value.trim(),
    full_name: document.getElementById('student-name').value.trim(),
    email: document.getElementById('student-email').value.trim(),
    phone: document.getElementById('student-phone').value.trim(),
    section_id: parseInt(document.getElementById('student-section').value),
    semester: parseInt(document.getElementById('student-semester').value),
    admission_year: 2024
  };

  try {
    let res;
    if (id) {
      res = await fetch(`/api/students/${id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      });
    } else {
      res = await fetch('/api/students', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      });
    }

    const data = await res.json();
    if (!res.ok) throw new Error(data.error || 'Failed to save student');

    closeModal('modal-student');
    showIslandToast(
      id ? 'Student Updated' : 'Student Inserted into Database',
      id ? `Record #${id} modified in students table` : `${payload.full_name} (${payload.roll_no}) saved`,
      'success'
    );
    await loadStudentsData();
    loadDashboardData();

    // Visual highlight on target row
    const targetId = id || data.student?.student_id;
    if (targetId) {
      const row = document.getElementById(`student-row-${targetId}`);
      if (row) row.classList.add('row-highlight');
    }
  } catch (err) {
    alert(err.message);
  }
});

// Student Delete
async function deleteStudent(id, name, roll) {
  if (!confirm(`Are you sure you want to delete student "${name}" (${roll})?\nThis will remove the student record and related attendance from the database.`)) {
    return;
  }

  try {
    const res = await fetch(`/api/students/${id}`, { method: 'DELETE' });
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || 'Failed to delete');

    showIslandToast('Student Deleted from Database', `Record #${id} (${name}) removed. Remaining: ${data.remaining_students}`, 'danger');
    
    const row = document.getElementById(`student-row-${id}`);
    if (row) {
      row.style.transition = 'all 0.3s ease';
      row.style.opacity = '0';
      row.style.transform = 'scale(0.95)';
      setTimeout(() => loadStudentsData(), 300);
    } else {
      loadStudentsData();
    }
    loadDashboardData();
  } catch (err) {
    alert(err.message);
  }
}

/* ----------------- 3. LIVE ATTENDANCE SHEET ----------------- */
async function loadAttendanceSessions() {
  try {
    const res = await fetch('/api/sessions');
    const data = await res.json();
    const select = document.getElementById('attendance-session-select');

    if (!data.sessions || data.sessions.length === 0) {
      select.innerHTML = '<option value="">No sessions available</option>';
      return;
    }

    select.innerHTML = data.sessions.map(s => 
      `<option value="${s.session_id}">Session #${s.session_id} · ${s.session_date} (${s.time_slot}) — ${s.section_name}</option>`
    ).join('');

    // Select the first session or maintain active
    if (!activeAttendanceSessionId || !data.sessions.some(s => s.session_id == activeAttendanceSessionId)) {
      activeAttendanceSessionId = data.sessions[0].session_id;
    }
    select.value = activeAttendanceSessionId;
    loadSessionAttendanceSheet(activeAttendanceSessionId);
  } catch (err) {
    console.error('Failed to load attendance sessions:', err);
  }
}

document.getElementById('attendance-session-select').addEventListener('change', (e) => {
  activeAttendanceSessionId = e.target.value;
  loadSessionAttendanceSheet(activeAttendanceSessionId);
});

async function loadSessionAttendanceSheet(sessionId) {
  if (!sessionId) return;
  try {
    const res = await fetch(`/api/session-attendance?session_id=${sessionId}`);
    const data = await res.json();

    const info = document.getElementById('session-info-display');
    info.innerHTML = `
      <div><strong>Topic:</strong> ${data.session.topic_covered}</div>
      <div><strong>Course & Faculty:</strong> ${data.session.course_code} (${data.session.course_name}) · ${data.session.faculty_name}</div>
      <div><strong>Room:</strong> ${data.session.room_no} · <strong>Section:</strong> ${data.session.section_name}</div>
    `;

    const tbody = document.getElementById('attendance-sheet-body');
    if (!data.attendance || data.attendance.length === 0) {
      tbody.innerHTML = `<tr><td colspan="7" style="text-align:center; padding:24px;">No students enrolled in this section.</td></tr>`;
      return;
    }

    tbody.innerHTML = data.attendance.map(row => `
      <tr id="att-row-${row.student_id}">
        <td><code>${row.roll_no}</code></td>
        <td><strong>${row.full_name}</strong></td>
        <td>${row.email}</td>
        <td>
          <span class="pill pill-${row.status.toLowerCase()}" id="pill-status-${row.student_id}">${row.status}</span>
        </td>
        <td>
          <div class="status-pill-group">
            <button class="btn-status-toggle ${row.status === 'Present' ? 'active-present' : ''}" 
              onclick="markAttendanceLive(${sessionId}, ${row.student_id}, 'Present')">Present</button>
            <button class="btn-status-toggle ${row.status === 'Absent' ? 'active-absent' : ''}" 
              onclick="markAttendanceLive(${sessionId}, ${row.student_id}, 'Absent')">Absent</button>
            <button class="btn-status-toggle ${row.status === 'Late' ? 'active-late' : ''}" 
              onclick="markAttendanceLive(${sessionId}, ${row.student_id}, 'Late')">Late</button>
            <button class="btn-status-toggle ${row.status === 'Excused' ? 'active-excused' : ''}" 
              onclick="markAttendanceLive(${sessionId}, ${row.student_id}, 'Excused')">Excused</button>
          </div>
        </td>
        <td style="font-size:12px; color:var(--apple-text-secondary);">${row.remarks || '—'}</td>
        <td class="text-right">
          ${row.attendance_id ? `
            <button class="btn-action-sm danger" onclick="deleteAttendanceRecord(${row.attendance_id}, ${sessionId})">Clear</button>
          ` : '—'}
        </td>
      </tr>
    `).join('');
  } catch (err) {
    console.error('Session attendance error:', err);
  }
}

// Live One-Click Status Mutation
async function markAttendanceLive(sessionId, studentId, status) {
  try {
    const res = await fetch('/api/attendance/mark', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        session_id: sessionId,
        student_id: studentId,
        status: status,
        remarks: `Live marked via AttendSync at ${new Date().toLocaleTimeString()}`
      })
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || 'Failed to mark');

    showIslandToast('Attendance Updated Live', `${data.record.full_name} marked as '${status}' in SQLite`, 'success');

    // Update the row visually
    const row = document.getElementById(`att-row-${studentId}`);
    if (row) {
      row.classList.remove('row-highlight');
      void row.offsetWidth; // trigger reflow
      row.classList.add('row-highlight');
    }
    loadSessionAttendanceSheet(sessionId);
    loadDashboardData();
  } catch (err) {
    alert(err.message);
  }
}

async function deleteAttendanceRecord(attendanceId, sessionId) {
  if (!confirm('Clear this attendance record from database?')) return;
  try {
    const res = await fetch(`/api/attendance/${attendanceId}`, { method: 'DELETE' });
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || 'Failed to clear');
    showIslandToast('Attendance Cleared', `Attendance record #${attendanceId} removed`, 'danger');
    loadSessionAttendanceSheet(sessionId);
    loadDashboardData();
  } catch (err) {
    alert(err.message);
  }
}

// Bulk Actions
document.getElementById('btn-bulk-present').addEventListener('click', () => bulkMarkAttendance('Present'));
document.getElementById('btn-bulk-absent').addEventListener('click', () => bulkMarkAttendance('Absent'));

async function bulkMarkAttendance(status) {
  if (!activeAttendanceSessionId) return;
  try {
    const res = await fetch('/api/attendance/bulk', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        session_id: activeAttendanceSessionId,
        status: status,
        remarks: `Bulk marked as ${status}`
      })
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.error);

    showIslandToast('Bulk Attendance Marked', `${data.count} students marked as '${status}'`, 'success');
    loadSessionAttendanceSheet(activeAttendanceSessionId);
    loadDashboardData();
  } catch (err) {
    alert(err.message);
  }
}

/* ----------------- 4. CLASS SESSIONS ----------------- */
async function loadSessionsData() {
  try {
    const res = await fetch('/api/sessions');
    const data = await res.json();
    const tbody = document.getElementById('sessions-table-body');

    tbody.innerHTML = data.sessions.map(s => `
      <tr id="session-row-${s.session_id}">
        <td><strong>#${s.session_id}</strong></td>
        <td>
          <strong>${s.session_date}</strong>
          <div style="font-size:11px; color:var(--apple-text-secondary);">${s.time_slot}</div>
        </td>
        <td><span class="col-tag">${s.room_no}</span></td>
        <td>
          <div>${s.section_name}</div>
          <div style="font-size:11px; color:var(--apple-text-secondary);">${s.course_code}</div>
        </td>
        <td>${s.faculty_name}</td>
        <td><strong>${s.topic_covered}</strong></td>
        <td>
          <span class="pill pill-${s.marked_students > 0 ? 'present' : 'warning'}">
            ${s.marked_students}/${s.total_enrolled} Marked
          </span>
        </td>
        <td class="text-right">
          <div class="table-actions">
            <button class="btn-action-sm" onclick="openSessionAttendance(${s.session_id})">Roll-Call</button>
            <button class="btn-action-sm danger" onclick="deleteSession(${s.session_id}, '${s.topic_covered}')">Delete</button>
          </div>
        </td>
      </tr>
    `).join('');
  } catch (err) {
    console.error('Failed to load sessions:', err);
  }
}

document.getElementById('btn-add-session-modal').addEventListener('click', () => {
  document.getElementById('form-session').reset();
  const today = new Date().toISOString().split('T')[0];
  document.getElementById('session-date').value = today;
  openModal('modal-session');
});

document.getElementById('form-session').addEventListener('submit', async (e) => {
  e.preventDefault();
  const payload = {
    section_id: parseInt(document.getElementById('session-section').value),
    faculty_id: parseInt(document.getElementById('session-faculty').value),
    session_date: document.getElementById('session-date').value,
    time_slot: document.getElementById('session-time').value.trim(),
    room_no: document.getElementById('session-room').value.trim(),
    topic_covered: document.getElementById('session-topic').value.trim(),
    status: 'Conducted'
  };

  try {
    const res = await fetch('/api/sessions', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload)
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.error);

    closeModal('modal-session');
    showIslandToast('Session Created in Database', `Session #${data.session_id} scheduled`, 'success');
    loadSessionsData();
    loadDashboardData();
  } catch (err) {
    alert(err.message);
  }
});

function openSessionAttendance(sessId) {
  activeAttendanceSessionId = sessId;
  switchTab('attendance');
}

async function deleteSession(id, topic) {
  if (!confirm(`Delete Session #${id} ("${topic}")?\nThis will also cascade delete logged attendance for this session.`)) return;
  try {
    const res = await fetch(`/api/sessions/${id}`, { method: 'DELETE' });
    const data = await res.json();
    if (!res.ok) throw new Error(data.error);

    showIslandToast('Session Deleted', `Session #${id} deleted from database`, 'danger');
    loadSessionsData();
    loadDashboardData();
  } catch (err) {
    alert(err.message);
  }
}

/* ----------------- 5. LEAVE APPROVAL WORKFLOW ----------------- */
async function loadLeavesData() {
  try {
    const res = await fetch('/api/leaves');
    const data = await res.json();
    const tbody = document.getElementById('leaves-table-body');

    tbody.innerHTML = data.leaves.map(l => `
      <tr id="leave-row-${l.application_id}">
        <td><strong>#${l.application_id}</strong></td>
        <td>
          <strong>${l.student_name}</strong>
          <div style="font-size:11px; color:var(--apple-text-secondary);">${l.roll_no} (${l.section_name})</div>
        </td>
        <td><span class="col-tag">${l.leave_type}</span></td>
        <td>
          <div>${l.start_date} → ${l.end_date}</div>
          <div style="font-size:11px; color:var(--apple-text-secondary);">Applied: ${l.applied_date}</div>
        </td>
        <td><strong>${l.total_days} Days</strong></td>
        <td style="max-width:220px; font-size:12px;">${l.reason}</td>
        <td>
          <span class="pill pill-${l.status === 'Approved' ? 'present' : (l.status === 'Rejected' ? 'absent' : 'warning')}">
            ${l.status}
          </span>
        </td>
        <td style="font-size:12px;">
          ${l.reviewed_by ? `
            <div>${l.reviewed_by}</div>
            <div style="font-size:10px; color:var(--apple-text-secondary);">${l.comments || ''}</div>
          ` : '<span style="color:var(--apple-text-tertiary);">Pending Review</span>'}
        </td>
        <td class="text-right">
          <div class="table-actions">
            ${l.status === 'Pending' ? `
              <button class="btn-action-sm success" onclick="decideLeave(${l.application_id}, 'Approved')">Approve</button>
              <button class="btn-action-sm danger" onclick="decideLeave(${l.application_id}, 'Rejected')">Reject</button>
            ` : `
              <button class="btn-action-sm danger" onclick="deleteLeave(${l.application_id})">Delete</button>
            `}
          </div>
        </td>
      </tr>
    `).join('');
  } catch (err) {
    console.error('Failed to load leaves:', err);
  }
}

document.getElementById('btn-submit-leave-modal').addEventListener('click', () => {
  document.getElementById('form-leave').reset();
  const today = new Date().toISOString().split('T')[0];
  document.getElementById('leave-start').value = today;
  document.getElementById('leave-end').value = today;
  openModal('modal-leave');
});

document.getElementById('form-leave').addEventListener('submit', async (e) => {
  e.preventDefault();
  const payload = {
    student_id: parseInt(document.getElementById('leave-student').value),
    leave_type_id: parseInt(document.getElementById('leave-type').value),
    start_date: document.getElementById('leave-start').value,
    end_date: document.getElementById('leave-end').value,
    reason: document.getElementById('leave-reason').value.trim()
  };

  try {
    const res = await fetch('/api/leaves', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload)
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.error);

    closeModal('modal-leave');
    showIslandToast('Leave Application Submitted', `Application #${data.application_id} pending faculty approval`, 'blue');
    loadLeavesData();
    loadDashboardData();
  } catch (err) {
    alert(err.message);
  }
});

async function decideLeave(appId, decision) {
  const comment = prompt(`Enter faculty remarks for ${decision}:`, `Verified credentials and attendance compliance`);
  if (comment === null) return;

  try {
    const res = await fetch(`/api/leaves/${appId}/action`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        decision: decision,
        faculty_id: 2,
        comments: comment
      })
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.error);

    showIslandToast('Faculty Decision Recorded', `Application #${appId} has been ${decision}!`, decision === 'Approved' ? 'success' : 'danger');
    loadLeavesData();
    loadDashboardData();
  } catch (err) {
    alert(err.message);
  }
}

async function deleteLeave(appId) {
  if (!confirm(`Delete Leave Application #${appId}?`)) return;
  try {
    const res = await fetch(`/api/leaves/${appId}`, { method: 'DELETE' });
    const data = await res.json();
    if (!res.ok) throw new Error(data.error);

    showIslandToast('Leave Deleted', `Application #${appId} deleted`, 'danger');
    loadLeavesData();
    loadDashboardData();
  } catch (err) {
    alert(err.message);
  }
}

/* ----------------- 6. SHORTAGE ALERTS ----------------- */
async function loadAlertsData() {
  try {
    const res = await fetch('/api/alerts');
    const data = await res.json();
    const tbody = document.getElementById('alerts-table-body');

    tbody.innerHTML = data.alerts.map(a => `
      <tr id="alert-row-${a.alert_id}">
        <td><strong>#${a.alert_id}</strong></td>
        <td>
          <strong>${a.student_name}</strong>
          <div style="font-size:11px; color:var(--apple-text-secondary);">${a.roll_no}</div>
        </td>
        <td>
          <div>${a.course_code}</div>
          <div style="font-size:11px; color:var(--apple-text-secondary);">${a.course_name}</div>
        </td>
        <td><strong>${a.attendance_percentage}%</strong></td>
        <td>
          <span class="pill pill-${a.alert_level.toLowerCase()}">${a.alert_level}</span>
        </td>
        <td>${a.generated_date}</td>
        <td>
          <span class="pill pill-${a.is_resolved ? 'safe' : 'critical'}">
            ${a.is_resolved ? 'Resolved' : 'Active'}
          </span>
        </td>
        <td class="text-right">
          ${!a.is_resolved ? `
            <button class="btn-action-sm success" onclick="resolveAlert(${a.alert_id})">Mark Resolved</button>
          ` : `
            <span style="font-size:11px; color:var(--apple-text-tertiary);">Completed</span>
          `}
        </td>
      </tr>
    `).join('');
  } catch (err) {
    console.error('Failed to load alerts:', err);
  }
}

document.getElementById('btn-trigger-audit').addEventListener('click', runShortageAudit);
document.getElementById('btn-run-shortage-audit').addEventListener('click', runShortageAudit);

async function runShortageAudit() {
  try {
    const res = await fetch('/api/alerts/generate', { method: 'POST', body: '{}' });
    const data = await res.json();
    if (!res.ok) throw new Error(data.error);

    showIslandToast('Audit Complete', `${data.new_alerts} new alerts generated in database!`, 'blue');
    loadAlertsData();
    loadDashboardData();
  } catch (err) {
    alert(err.message);
  }
}

async function resolveAlert(alertId) {
  try {
    const res = await fetch(`/api/alerts/${alertId}/resolve`, { method: 'PUT', body: '{}' });
    const data = await res.json();
    if (!res.ok) throw new Error(data.error);

    showIslandToast('Alert Resolved', `Shortage alert #${alertId} marked as resolved`, 'success');
    loadAlertsData();
    loadDashboardData();
  } catch (err) {
    alert(err.message);
  }
}

/* ----------------- 7. DATABASE TABLES INSPECTOR (MANDATORY REQUIREMENT) ----------------- */
let currentInspectorSchema = [];
let currentInspectorPK = 'id';

async function initTableInspector() {
  try {
    const res = await fetch('/api/tables');
    const data = await res.json();
    const select = document.getElementById('inspector-table-select');

    select.innerHTML = data.tables.map(t => 
      `<option value="${t.name}">${t.name} (${t.row_count} rows)</option>`
    ).join('');

    select.value = activeInspectorTable;
    select.addEventListener('change', (e) => {
      activeInspectorTable = e.target.value;
      loadInspectorTableData(activeInspectorTable);
    });

    document.getElementById('inspector-search-input').addEventListener('input', debounce(() => {
      loadInspectorTableData(activeInspectorTable);
    }, 250));

    document.getElementById('btn-inspector-insert-row').addEventListener('click', openInsertRowModal);
  } catch (err) {
    console.error('Failed to init table inspector:', err);
  }
}

async function loadInspectorTableData(tableName) {
  if (!tableName) return;
  const search = document.getElementById('inspector-search-input').value.trim();

  try {
    const res = await fetch(`/api/table/${tableName}?q=${encodeURIComponent(search)}`);
    const data = await res.json();

    currentInspectorSchema = data.columns;
    currentInspectorPK = data.primary_key;

    document.getElementById('meta-row-count').textContent = data.total_rows;
    document.getElementById('meta-pk').textContent = currentInspectorPK;

    // Render columns schema bar
    const schemaBar = document.getElementById('inspector-columns-bar');
    schemaBar.innerHTML = data.columns.map(c => `
      <span class="col-tag ${c.pk ? 'pk' : ''}">
        ${c.pk ? '🔑 ' : ''}${c.name}
        <span class="col-tag-type">${c.type}</span>
      </span>
    `).join('');

    // Render Table Header
    const thead = document.getElementById('inspector-table-head');
    thead.innerHTML = `
      <tr>
        ${data.columns.map(c => `<th>${c.name.toUpperCase()}</th>`).join('')}
        <th class="text-right">DB ACTION</th>
      </tr>
    `;

    // Render Table Rows
    const tbody = document.getElementById('inspector-table-body');
    if (!data.rows || data.rows.length === 0) {
      tbody.innerHTML = `<tr><td colspan="${data.columns.length + 1}" style="text-align:center; padding:24px; color:var(--apple-text-secondary);">Table has 0 rows matching query.</td></tr>`;
      return;
    }

    tbody.innerHTML = data.rows.map(row => {
      const pkVal = row[currentInspectorPK];
      return `
        <tr id="tbl-row-${tableName}-${pkVal}">
          ${data.columns.map(c => `
            <td>${formatCell(row[c.name])}</td>
          `).join('')}
          <td class="text-right">
            <button class="btn-action-sm danger" onclick="deleteTableRowLive('${tableName}', '${pkVal}')">
              Delete
            </button>
          </td>
        </tr>
      `;
    }).join('');

    // Update select badge
    const select = document.getElementById('inspector-table-select');
    if (select) select.value = tableName;
  } catch (err) {
    console.error('Failed to inspect table:', err);
  }
}

function formatCell(val) {
  if (val === null || val === undefined) return '<span style="color:#C7C7CC;">NULL</span>';
  if (typeof val === 'string' && val.length > 50) return `<span title="${val}">${val.substring(0, 48)}…</span>`;
  return String(val);
}

// Live Table Row Deletion
async function deleteTableRowLive(table, pkVal) {
  if (!confirm(`Delete row with ${currentInspectorPK} = ${pkVal} directly from table "${table}"?`)) return;

  try {
    const res = await fetch(`/api/table/${table}/${pkVal}`, { method: 'DELETE' });
    const data = await res.json();
    if (!res.ok) throw new Error(data.error);

    showIslandToast(
      'Row Deleted from Database',
      `DELETE FROM ${table} WHERE ${currentInspectorPK} = ${pkVal} (Remaining: ${data.remaining_rows})`,
      'danger'
    );

    const row = document.getElementById(`tbl-row-${table}-${pkVal}`);
    if (row) {
      row.style.opacity = '0';
      setTimeout(() => loadInspectorTableData(table), 250);
    } else {
      loadInspectorTableData(table);
    }
    loadDashboardData();
  } catch (err) {
    alert(err.message);
  }
}

// Open Generic Insert Row Modal
function openInsertRowModal() {
  document.getElementById('modal-table-insert-title').textContent = `Insert Row into "${activeInspectorTable}"`;
  const container = document.getElementById('dynamic-insert-fields');

  // Generate input fields for non-autoincrement columns
  const fieldsHtml = currentInspectorSchema.map(col => {
    if (col.pk && col.type.toUpperCase().includes('INT')) {
      return ''; // Auto increment
    }
    return `
      <div class="form-group">
        <label>${col.name} <span style="font-size:11px; color:var(--apple-text-tertiary);">(${col.type}${col.notnull ? ', Required' : ''})</span></label>
        <input type="text" name="${col.name}" class="apple-input dynamic-col-input" 
          ${col.notnull ? 'required' : ''} placeholder="Enter ${col.name}..." />
      </div>
    `;
  }).join('');

  container.innerHTML = fieldsHtml || '<p>No editable columns available.</p>';
  openModal('modal-table-insert');
}

// Insert Row Form Submit
document.getElementById('form-table-insert').addEventListener('submit', async (e) => {
  e.preventDefault();
  const inputs = document.querySelectorAll('.dynamic-col-input');
  const payloadData = {};

  inputs.forEach(inp => {
    if (inp.value.trim() !== '') {
      payloadData[inp.name] = inp.value.trim();
    }
  });

  try {
    const res = await fetch(`/api/table/${activeInspectorTable}`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ data: payloadData })
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.error);

    closeModal('modal-table-insert');
    showIslandToast(
      'Row Inserted into Database',
      `INSERT INTO ${activeInspectorTable} [ID #${data.inserted_id}]. Total rows: ${data.total_rows}`,
      'success'
    );
    await loadInspectorTableData(activeInspectorTable);
    loadDashboardData();

    // Visual highlight on newly inserted row
    const targetRow = document.getElementById(`tbl-row-${activeInspectorTable}-${data.inserted_id}`);
    if (targetRow) targetRow.classList.add('row-highlight');
  } catch (err) {
    alert(err.message);
  }
});

/* ----------------- 8. LIVE SQL CONSOLE ----------------- */
function initSqlConsole() {
  const input = document.getElementById('sql-query-input');
  document.getElementById('btn-run-sql').addEventListener('click', executeSqlQuery);

  input.addEventListener('keydown', (e) => {
    if ((e.metaKey || e.ctrlKey) && e.key === 'Enter') {
      e.preventDefault();
      executeSqlQuery();
    }
  });

  document.querySelectorAll('.btn-preset').forEach(btn => {
    btn.addEventListener('click', () => {
      input.value = btn.dataset.query;
      executeSqlQuery();
    });
  });

  // Default query
  input.value = 'SELECT * FROM v_student_attendance_summary LIMIT 10;';
}

async function executeSqlQuery() {
  const query = document.getElementById('sql-query-input').value.trim();
  const metaEl = document.getElementById('sql-execution-meta');
  const resultsCard = document.getElementById('sql-results-card');
  const resultsSub = document.getElementById('sql-results-sub');
  const thead = document.getElementById('sql-results-head');
  const tbody = document.getElementById('sql-results-body');

  if (!query) {
    alert('Please enter a SQL query.');
    return;
  }

  metaEl.textContent = 'Executing query on SQLite...';

  try {
    const start = performance.now();
    const res = await fetch('/api/query', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ sql: query })
    });
    const data = await res.json();

    if (!res.ok) {
      metaEl.innerHTML = `<span style="color:var(--apple-red);">Error: ${data.error}</span>`;
      resultsSub.textContent = data.error;
      thead.innerHTML = '';
      tbody.innerHTML = `<tr><td style="color:var(--apple-red); padding:16px;">${data.error}</td></tr>`;
      showIslandToast('Query Execution Failed', data.error, 'danger');
      return;
    }

    if (data.type === 'SELECT') {
      metaEl.innerHTML = `✓ Query executed in <strong>${data.duration_ms} ms</strong> · <strong>${data.row_count} rows</strong> returned`;
      resultsSub.textContent = `${data.row_count} records returned in ${data.duration_ms} ms`;

      thead.innerHTML = `<tr>${data.columns.map(c => `<th>${c}</th>`).join('')}</tr>`;
      tbody.innerHTML = data.rows.map(r => `
        <tr>${r.map(val => `<td>${formatCell(val)}</td>`).join('')}</tr>
      `).join('');

      showIslandToast('SQL Executed', `${data.row_count} rows retrieved (${data.duration_ms} ms)`, 'success');
    } else {
      metaEl.innerHTML = `✓ DML Query executed in <strong>${data.duration_ms} ms</strong> · <strong>${data.rows_affected} rows affected</strong>`;
      resultsSub.textContent = `Statement processed. Last Row ID: ${data.last_row_id || 'N/A'}`;
      thead.innerHTML = `<tr><th>STATEMENT TYPE</th><th>ROWS AFFECTED</th><th>LAST INSERT ID</th><th>EXECUTION TIME</th></tr>`;
      tbody.innerHTML = `
        <tr>
          <td><strong>DML (INSERT/UPDATE/DELETE)</strong></td>
          <td>${data.rows_affected}</td>
          <td>${data.last_row_id || 'N/A'}</td>
          <td>${data.duration_ms} ms</td>
        </tr>
      `;
      showIslandToast('Database Mutated', `${data.rows_affected} rows affected in ${data.duration_ms} ms`, 'success');
      loadDashboardData();
    }
  } catch (err) {
    metaEl.textContent = `Error: ${err.message}`;
    alert(err.message);
  }
}

/* ----------------- RESET DATABASE ----------------- */
async function handleResetDatabase() {
  if (!confirm('Are you sure you want to reset the database?\nThis will recreate all tables and seed the initial 270+ records.')) return;
  try {
    const res = await fetch('/api/reset-database', { method: 'POST', body: '{}' });
    const data = await res.json();
    if (!res.ok) throw new Error(data.error);

    showIslandToast('Database Reset Complete', data.message, 'success');
    loadDashboardData();
    if (currentTab === 'students') loadStudentsData();
    if (currentTab === 'attendance') loadAttendanceSessions();
    if (currentTab === 'sessions') loadSessionsData();
    if (currentTab === 'leaves') loadLeavesData();
    if (currentTab === 'alerts') loadAlertsData();
    if (currentTab === 'tables') loadInspectorTableData(activeInspectorTable);
  } catch (err) {
    alert(err.message);
  }
}

/* ----------------- MODAL HELPERS ----------------- */
function initModals() {
  document.getElementById('btn-close-student-modal').addEventListener('click', () => closeModal('modal-student'));
  document.getElementById('btn-cancel-student').addEventListener('click', () => closeModal('modal-student'));

  document.getElementById('btn-close-session-modal').addEventListener('click', () => closeModal('modal-session'));
  document.getElementById('btn-cancel-session').addEventListener('click', () => closeModal('modal-session'));

  document.getElementById('btn-close-leave-modal').addEventListener('click', () => closeModal('modal-leave'));
  document.getElementById('btn-cancel-leave').addEventListener('click', () => closeModal('modal-leave'));

  document.getElementById('btn-close-insert-modal').addEventListener('click', () => closeModal('modal-table-insert'));
  document.getElementById('btn-cancel-insert').addEventListener('click', () => closeModal('modal-table-insert'));

  // Close on outside click
  document.querySelectorAll('.modal-overlay').forEach(modal => {
    modal.addEventListener('click', (e) => {
      if (e.target === modal) closeModal(modal.id);
    });
  });
}

function openModal(modalId) {
  const modal = document.getElementById(modalId);
  if (modal) modal.classList.add('open');
}

function closeModal(modalId) {
  const modal = document.getElementById(modalId);
  if (modal) modal.classList.remove('open');
}

// Utility: Debounce
function debounce(fn, ms) {
  let timer;
  return function(...args) {
    clearTimeout(timer);
    timer = setTimeout(() => fn.apply(this, args), ms);
  };
}
