"""
REST API and Web Server for Student Attendance and Leave Approval System (Topic #26)
Student: Shaikh Humzah (Roll No: 25WU0102251) - AIML Whales
Zero-dependency Python 3 standard library implementation.
"""

import http.server
import socketserver
import json
import urllib.parse
import os
import sys
import time
import sqlite3
import traceback
from pathlib import Path

# Ensure root directory is on sys.path
BASE_DIR = Path(__file__).resolve().parent
ROOT_DIR = BASE_DIR.parent
if str(ROOT_DIR) not in sys.path:
    sys.path.insert(0, str(ROOT_DIR))
if str(BASE_DIR) not in sys.path:
    sys.path.insert(0, str(BASE_DIR))

try:
    from app.database import get_connection, init_database, seed_database, DB_PATH
except ImportError:
    from database import get_connection, init_database, seed_database, DB_PATH

PORT = 8000
STATIC_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "static")

# Ensure database exists
if not os.path.exists(DB_PATH):
    init_database()
    seed_database()

class AttendanceRequestHandler(http.server.SimpleHTTPRequestHandler):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, directory=STATIC_DIR, **kwargs)

    def log_message(self, format, *args):
        # Clean logging
        print(f"[{time.strftime('%H:%M:%S')}] {self.command} {self.path} - {args[0]}")

    def send_json(self, data, status_code=200):
        body = json.dumps(data, default=str).encode('utf-8')
        self.send_response(status_code)
        self.send_header('Content-Type', 'application/json; charset=utf-8')
        self.send_header('Content-Length', str(len(body)))
        self.send_header('Access-Control-Allow-Origin', '*')
        self.send_header('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS')
        self.send_header('Access-Control-Allow-Headers', 'Content-Type')
        self.end_headers()
        self.wfile.write(body)

    def send_error_json(self, message, status_code=400, details=None):
        self.send_json({
            "error": message,
            "details": details or ""
        }, status_code=status_code)

    def do_OPTIONS(self):
        self.send_response(204)
        self.send_header('Access-Control-Allow-Origin', '*')
        self.send_header('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS')
        self.send_header('Access-Control-Allow-Headers', 'Content-Type')
        self.end_headers()

    def parse_json_body(self):
        try:
            content_length = int(self.headers.get('Content-Length', 0))
            if content_length > 0:
                raw_data = self.rfile.read(content_length).decode('utf-8')
                return json.loads(raw_data) if raw_data else {}
            return {}
        except Exception as e:
            return None

    def do_GET(self):
        parsed = urllib.parse.urlparse(self.path)
        path = parsed.path
        query = urllib.parse.parse_qs(parsed.query)

        # Route API requests
        if path.startswith("/api/"):
            try:
                self.handle_api_get(path, query)
            except Exception as e:
                traceback.print_exc()
                self.send_error_json(str(e), 500, traceback.format_exc())
            return

        # Serve Project Report HTML
        if path in ["/report", "/report/", "/DBMS_Project_Report.html"]:
            report_file = os.path.join(ROOT_DIR, "Project-Report", "DBMS_Project_Report.html")
            if os.path.exists(report_file):
                self.send_response(200)
                self.send_header("Content-Type", "text/html; charset=utf-8")
                self.end_headers()
                with open(report_file, "rb") as rf:
                    self.wfile.write(rf.read())
                return

        # Serve Project Report Screenshots
        if path.startswith("/screenshots/"):
            rel_img = path[len("/screenshots/"):].strip("/")
            img_file = os.path.join(ROOT_DIR, "Project-Report", "screenshots", rel_img)
            if os.path.exists(img_file):
                self.send_response(200)
                mime = "image/png"
                if img_file.endswith(".svg"):
                    mime = "image/svg+xml"
                elif img_file.endswith(".webp"):
                    mime = "image/webp"
                self.send_header("Content-Type", mime)
                self.end_headers()
                with open(img_file, "rb") as imf:
                    self.wfile.write(imf.read())
                return

        # Serve SPA static files
        if path == "/" or not os.path.exists(os.path.join(STATIC_DIR, path.lstrip('/'))):
            self.path = "/index.html"
        super().do_GET()

    def do_POST(self):
        parsed = urllib.parse.urlparse(self.path)
        path = parsed.path
        if path.startswith("/api/"):
            try:
                payload = self.parse_json_body()
                if payload is None:
                    return self.send_error_json("Invalid JSON body in request", 400)
                self.handle_api_post(path, payload)
            except Exception as e:
                traceback.print_exc()
                self.send_error_json(str(e), 500, traceback.format_exc())
            return
        self.send_error_json("Endpoint not found", 404)

    def do_PUT(self):
        parsed = urllib.parse.urlparse(self.path)
        path = parsed.path
        if path.startswith("/api/"):
            try:
                payload = self.parse_json_body()
                if payload is None:
                    return self.send_error_json("Invalid JSON body in request", 400)
                self.handle_api_put(path, payload)
            except Exception as e:
                traceback.print_exc()
                self.send_error_json(str(e), 500, traceback.format_exc())
            return
        self.send_error_json("Endpoint not found", 404)

    def do_DELETE(self):
        parsed = urllib.parse.urlparse(self.path)
        path = parsed.path
        if path.startswith("/api/"):
            try:
                self.handle_api_delete(path)
            except Exception as e:
                traceback.print_exc()
                self.send_error_json(str(e), 500, traceback.format_exc())
            return
        self.send_error_json("Endpoint not found", 404)

    # ------------------ API ROUTERS ------------------ #
    def handle_api_get(self, path, query):
        conn = get_connection()
        cursor = conn.cursor()

        # 1. System Overview Stats
        if path == "/api/stats":
            students_count = cursor.execute("SELECT COUNT(*) FROM students").fetchone()[0]
            faculty_count = cursor.execute("SELECT COUNT(*) FROM faculty").fetchone()[0]
            courses_count = cursor.execute("SELECT COUNT(*) FROM courses").fetchone()[0]
            sessions_count = cursor.execute("SELECT COUNT(*) FROM class_sessions").fetchone()[0]
            attendance_count = cursor.execute("SELECT COUNT(*) FROM attendance").fetchone()[0]
            pending_leaves = cursor.execute("SELECT COUNT(*) FROM leave_applications WHERE status = 'Pending'").fetchone()[0]
            active_alerts = cursor.execute("SELECT COUNT(*) FROM shortage_alerts WHERE is_resolved = 0").fetchone()[0]
            
            # Overall attendance percentage
            overall_row = cursor.execute("""
                SELECT 
                    COUNT(*) as total,
                    SUM(CASE WHEN status IN ('Present', 'Late') THEN 1 ELSE 0 END) as present_count
                FROM attendance
            """).fetchone()
            total_att = overall_row['total'] or 0
            present_att = overall_row['present_count'] or 0
            attendance_rate = round((present_att / total_att * 100), 1) if total_att > 0 else 0.0

            # Count rows across all 12 tables
            all_tables = [
                'departments', 'faculty', 'courses', 'sections', 'students',
                'class_sessions', 'attendance', 'leave_types', 'leave_applications',
                'leave_approvals', 'makeup_sessions', 'shortage_alerts'
            ]
            table_counts = {}
            total_db_records = 0
            for t in all_tables:
                cnt = cursor.execute(f"SELECT COUNT(*) FROM {t}").fetchone()[0]
                table_counts[t] = cnt
                total_db_records += cnt

            conn.close()
            return self.send_json({
                "students_count": students_count,
                "faculty_count": faculty_count,
                "courses_count": courses_count,
                "sessions_count": sessions_count,
                "attendance_count": attendance_count,
                "pending_leaves": pending_leaves,
                "active_alerts": active_alerts,
                "overall_attendance_rate": attendance_rate,
                "total_db_records": total_db_records,
                "table_counts": table_counts
            })

        # 2. Schema / Table Metadata Listing
        if path == "/api/tables":
            table_names = [
                'students', 'attendance', 'class_sessions', 'leave_applications',
                'leave_approvals', 'shortage_alerts', 'makeup_sessions', 'sections',
                'courses', 'faculty', 'departments', 'leave_types'
            ]
            tables_meta = []
            for tbl in table_names:
                count = cursor.execute(f"SELECT COUNT(*) FROM {tbl}").fetchone()[0]
                col_info = cursor.execute(f"PRAGMA table_info({tbl})").fetchall()
                columns = [dict(c) for c in col_info]
                tables_meta.append({
                    "name": tbl,
                    "row_count": count,
                    "columns": columns
                })
            conn.close()
            return self.send_json({"tables": tables_meta})

        # 3. Specific Database Table Inspection with Filtering
        if path.startswith("/api/table/"):
            tbl_name = path[len("/api/table/"):].strip("/")
            # Validate table exists to prevent SQL injection
            valid_tables = [
                'departments', 'faculty', 'courses', 'sections', 'students',
                'class_sessions', 'attendance', 'leave_types', 'leave_applications',
                'leave_approvals', 'makeup_sessions', 'shortage_alerts'
            ]
            if tbl_name not in valid_tables:
                conn.close()
                return self.send_error_json(f"Table '{tbl_name}' does not exist.", 404)

            # Get columns info
            col_info = cursor.execute(f"PRAGMA table_info({tbl_name})").fetchall()
            columns = [dict(c) for c in col_info]
            pk_col = next((c['name'] for c in columns if c['pk'] == 1), columns[0]['name'] if columns else 'id')

            q = query.get('q', [''])[0].strip()
            where_clause = ""
            params = []
            if q:
                # Text search across text columns
                search_parts = [f"{c['name']} LIKE ?" for c in columns]
                where_clause = " WHERE " + " OR ".join(search_parts)
                params = [f"%{q}%"] * len(search_parts)

            count_query = f"SELECT COUNT(*) FROM {tbl_name}" + where_clause
            total_rows = cursor.execute(count_query, params).fetchone()[0]

            select_sql = f"SELECT * FROM {tbl_name}{where_clause} ORDER BY {pk_col} DESC LIMIT 100"
            rows = cursor.execute(select_sql, params).fetchall()
            rows_data = [dict(r) for r in rows]

            conn.close()
            return self.send_json({
                "table": tbl_name,
                "primary_key": pk_col,
                "columns": columns,
                "total_rows": total_rows,
                "rows": rows_data
            })

        # 4. Students Domain List
        if path == "/api/students":
            q = query.get('q', [''])[0].strip()
            section_id = query.get('section_id', [''])[0].strip()
            where_sql = "WHERE 1=1"
            params = []
            if q:
                where_sql += " AND (s.roll_no LIKE ? OR s.full_name LIKE ? OR s.email LIKE ?)"
                params.extend([f"%{q}%", f"%{q}%", f"%{q}%"])
            if section_id:
                where_sql += " AND s.section_id = ?"
                params.append(section_id)

            sql = f"""
                SELECT 
                    s.student_id,
                    s.roll_no,
                    s.full_name,
                    s.email,
                    s.phone,
                    s.section_id,
                    sec.section_name,
                    s.semester,
                    s.admission_year,
                    c.course_code,
                    c.course_name,
                    (SELECT COUNT(*) FROM attendance a JOIN class_sessions cs ON a.session_id = cs.session_id 
                     WHERE a.student_id = s.student_id AND cs.section_id = s.section_id) as total_marked,
                    (SELECT COUNT(*) FROM attendance a JOIN class_sessions cs ON a.session_id = cs.session_id 
                     WHERE a.student_id = s.student_id AND cs.section_id = s.section_id AND a.status IN ('Present', 'Late')) as total_attended
                FROM students s
                JOIN sections sec ON s.section_id = sec.section_id
                JOIN courses c ON sec.course_id = c.course_id
                {where_sql}
                ORDER BY s.student_id ASC
            """
            rows = cursor.execute(sql, params).fetchall()
            res = []
            for r in rows:
                item = dict(r)
                tot = item['total_marked']
                att = item['total_attended']
                item['attendance_percentage'] = round((att / tot * 100), 1) if tot > 0 else 100.0
                if item['attendance_percentage'] >= 75:
                    item['status_badge'] = 'Safe'
                elif item['attendance_percentage'] >= 65:
                    item['status_badge'] = 'Warning'
                else:
                    item['status_badge'] = 'Critical'
                res.append(item)
            conn.close()
            return self.send_json({"students": res})

        # 5. Sessions Domain List
        if path == "/api/sessions":
            sql = """
                SELECT 
                    cs.session_id,
                    cs.session_date,
                    cs.time_slot,
                    cs.room_no,
                    cs.topic_covered,
                    cs.status,
                    cs.section_id,
                    sec.section_name,
                    c.course_code,
                    c.course_name,
                    f.faculty_id,
                    f.full_name AS faculty_name,
                    (SELECT COUNT(*) FROM attendance a WHERE a.session_id = cs.session_id) AS marked_students,
                    (SELECT COUNT(*) FROM students s WHERE s.section_id = cs.section_id) AS total_enrolled
                FROM class_sessions cs
                JOIN sections sec ON cs.section_id = sec.section_id
                JOIN courses c ON sec.course_id = c.course_id
                JOIN faculty f ON cs.faculty_id = f.faculty_id
                ORDER BY cs.session_date DESC, cs.session_id DESC
            """
            rows = cursor.execute(sql).fetchall()
            conn.close()
            return self.send_json({"sessions": [dict(r) for r in rows]})

        # 6. Session Attendance Details (for Live Attendance Sheet)
        if path == "/api/session-attendance":
            session_id = query.get('session_id', [''])[0].strip()
            if not session_id:
                conn.close()
                return self.send_error_json("session_id is required", 400)
            
            # Session details
            sess = cursor.execute("""
                SELECT cs.*, sec.section_name, c.course_name, c.course_code, f.full_name AS faculty_name
                FROM class_sessions cs
                JOIN sections sec ON cs.section_id = sec.section_id
                JOIN courses c ON sec.course_id = c.course_id
                JOIN faculty f ON cs.faculty_id = f.faculty_id
                WHERE cs.session_id = ?
            """, (session_id,)).fetchone()
            if not sess:
                conn.close()
                return self.send_error_json("Session not found", 404)

            # Enrolled students with attendance status if marked
            students_att = cursor.execute("""
                SELECT 
                    s.student_id,
                    s.roll_no,
                    s.full_name,
                    s.email,
                    a.attendance_id,
                    COALESCE(a.status, 'Unmarked') AS status,
                    a.remarks,
                    a.marked_at
                FROM students s
                LEFT JOIN attendance a ON a.student_id = s.student_id AND a.session_id = ?
                WHERE s.section_id = ?
                ORDER BY s.roll_no ASC
            """, (session_id, sess['section_id'])).fetchall()

            conn.close()
            return self.send_json({
                "session": dict(sess),
                "attendance": [dict(r) for r in students_att]
            })

        # 7. Leave Applications List
        if path == "/api/leaves":
            sql = """
                SELECT 
                    la.application_id,
                    la.student_id,
                    s.roll_no,
                    s.full_name AS student_name,
                    sec.section_name,
                    lt.leave_type_id,
                    lt.type_name AS leave_type,
                    la.start_date,
                    la.end_date,
                    CAST((julianday(la.end_date) - julianday(la.start_date) + 1) AS INTEGER) AS total_days,
                    la.reason,
                    la.applied_date,
                    la.status,
                    appr.approval_id,
                    f.full_name AS reviewed_by,
                    appr.decision_date,
                    appr.comments
                FROM leave_applications la
                JOIN students s ON la.student_id = s.student_id
                JOIN sections sec ON s.section_id = sec.section_id
                JOIN leave_types lt ON la.leave_type_id = lt.leave_type_id
                LEFT JOIN leave_approvals appr ON la.application_id = appr.application_id
                LEFT JOIN faculty f ON appr.reviewed_by_faculty_id = f.faculty_id
                ORDER BY la.application_id DESC
            """
            rows = cursor.execute(sql).fetchall()
            conn.close()
            return self.send_json({"leaves": [dict(r) for r in rows]})

        # 8. Shortage Alerts List
        if path == "/api/alerts":
            sql = """
                SELECT 
                    sa.alert_id,
                    sa.student_id,
                    s.roll_no,
                    s.full_name AS student_name,
                    s.email,
                    c.course_id,
                    c.course_code,
                    c.course_name,
                    sa.attendance_percentage,
                    sa.alert_level,
                    sa.generated_date,
                    sa.is_resolved
                FROM shortage_alerts sa
                JOIN students s ON sa.student_id = s.student_id
                JOIN courses c ON sa.course_id = c.course_id
                ORDER BY sa.is_resolved ASC, sa.attendance_percentage ASC, sa.alert_id DESC
            """
            rows = cursor.execute(sql).fetchall()
            conn.close()
            return self.send_json({"alerts": [dict(r) for r in rows]})

        # 9. Form Dropdowns Helpers
        if path == "/api/options":
            deps = cursor.execute("SELECT department_id, dept_name, dept_code FROM departments").fetchall()
            fac = cursor.execute("SELECT faculty_id, full_name, designation FROM faculty").fetchall()
            courses = cursor.execute("SELECT course_id, course_code, course_name FROM courses").fetchall()
            sections = cursor.execute("""
                SELECT s.section_id, s.section_name, c.course_code, c.course_name 
                FROM sections s JOIN courses c ON s.course_id = c.course_id
            """).fetchall()
            leave_types = cursor.execute("SELECT leave_type_id, type_name, max_days_allowed FROM leave_types").fetchall()
            conn.close()
            return self.send_json({
                "departments": [dict(d) for d in deps],
                "faculty": [dict(f) for f in fac],
                "courses": [dict(c) for c in courses],
                "sections": [dict(s) for s in sections],
                "leave_types": [dict(lt) for lt in leave_types]
            })

        # 10. Reports
        if path == "/api/reports/shortage":
            sql = """
                SELECT 
                    s.student_id,
                    s.roll_no,
                    s.full_name,
                    sec.section_name,
                    c.course_code,
                    c.course_name,
                    COUNT(a.attendance_id) AS total_sessions,
                    SUM(CASE WHEN a.status IN ('Present', 'Late') THEN 1 ELSE 0 END) AS attended_sessions,
                    ROUND((SUM(CASE WHEN a.status IN ('Present', 'Late') THEN 1.0 ELSE 0.0 END) * 100.0) / COUNT(a.attendance_id), 2) AS attendance_percentage,
                    (CAST((0.75 * COUNT(a.attendance_id) - SUM(CASE WHEN a.status IN ('Present', 'Late') THEN 1 ELSE 0 END)) / (1 - 0.75) AS INTEGER) + 1) AS classes_needed_for_75
                FROM students s
                JOIN sections sec ON s.section_id = sec.section_id
                JOIN courses c ON sec.course_id = c.course_id
                JOIN class_sessions cs ON cs.section_id = sec.section_id
                LEFT JOIN attendance a ON a.session_id = cs.session_id AND a.student_id = s.student_id
                GROUP BY s.student_id, c.course_id
                HAVING attendance_percentage < 75.0
                ORDER BY attendance_percentage ASC
            """
            rows = cursor.execute(sql).fetchall()
            conn.close()
            return self.send_json({"shortage_students": [dict(r) for r in rows]})

        conn.close()
        return self.send_error_json(f"GET endpoint '{path}' not found", 404)

    # ------------------ POST HANDLERS ------------------ #
    def handle_api_post(self, path, payload):
        conn = get_connection()
        cursor = conn.cursor()

        # 1. Raw SQL Query Console Runner
        if path == "/api/query":
            sql = payload.get("sql", "").strip()
            if not sql:
                conn.close()
                return self.send_error_json("SQL query cannot be empty", 400)

            start_t = time.perf_counter()
            try:
                # Disallow multiple chained scripts for safety
                cursor.execute(sql)
                duration_ms = round((time.perf_counter() - start_t) * 1000, 2)

                if cursor.description:
                    columns = [d[0] for d in cursor.description]
                    rows = cursor.fetchall()
                    rows_data = [list(r) for r in rows]
                    conn.close()
                    return self.send_json({
                        "type": "SELECT",
                        "columns": columns,
                        "rows": rows_data,
                        "row_count": len(rows_data),
                        "duration_ms": duration_ms
                    })
                else:
                    conn.commit()
                    rows_affected = cursor.rowcount
                    last_id = cursor.lastrowid
                    conn.close()
                    return self.send_json({
                        "type": "DML",
                        "rows_affected": rows_affected,
                        "last_row_id": last_id,
                        "duration_ms": duration_ms
                    })
            except Exception as e:
                conn.close()
                return self.send_error_json(f"SQL Execution Error: {str(e)}", 400)

        # 2. Reset Database to Seed State
        if path == "/api/reset-database":
            counts = seed_database()
            conn.close()
            return self.send_json({
                "message": "Database reset and seeded with initial 270+ records successfully!",
                "counts": counts
            })

        # 3. Insert Record directly into any Table (Generic CRUD)
        if path.startswith("/api/table/"):
            tbl_name = path[len("/api/table/"):].strip("/")
            valid_tables = [
                'departments', 'faculty', 'courses', 'sections', 'students',
                'class_sessions', 'attendance', 'leave_types', 'leave_applications',
                'leave_approvals', 'makeup_sessions', 'shortage_alerts'
            ]
            if tbl_name not in valid_tables:
                conn.close()
                return self.send_error_json(f"Table '{tbl_name}' is invalid.", 404)

            data = payload.get("data", {})
            if not data:
                conn.close()
                return self.send_error_json("No column data provided", 400)

            cols = list(data.keys())
            placeholders = ["?"] * len(cols)
            vals = list(data.values())

            insert_sql = f"INSERT INTO {tbl_name} ({', '.join(cols)}) VALUES ({', '.join(placeholders)})"
            cursor.execute(insert_sql, vals)
            new_id = cursor.lastrowid
            conn.commit()

            # Fetch updated count and new row
            total_count = cursor.execute(f"SELECT COUNT(*) FROM {tbl_name}").fetchone()[0]
            conn.close()
            return self.send_json({
                "message": f"Successfully inserted row into {tbl_name} with ID {new_id}!",
                "table": tbl_name,
                "inserted_id": new_id,
                "total_rows": total_count
            })

        # 4. Create Student
        if path == "/api/students":
            roll_no = payload.get("roll_no", "").strip().upper()
            full_name = payload.get("full_name", "").strip()
            email = payload.get("email", "").strip()
            phone = payload.get("phone", "").strip()
            section_id = payload.get("section_id")
            semester = payload.get("semester", 4)
            admission_year = payload.get("admission_year", 2024)

            if not roll_no or not full_name or not email or not section_id:
                conn.close()
                return self.send_error_json("Roll No, Full Name, Email, and Section are required", 400)

            cursor.execute("""
                INSERT INTO students (roll_no, full_name, email, phone, section_id, semester, admission_year)
                VALUES (?, ?, ?, ?, ?, ?, ?)
            """, (roll_no, full_name, email, phone, section_id, semester, admission_year))
            new_id = cursor.lastrowid
            conn.commit()

            # Also return new row
            new_student = cursor.execute("SELECT * FROM students WHERE student_id = ?", (new_id,)).fetchone()
            total_students = cursor.execute("SELECT COUNT(*) FROM students").fetchone()[0]
            conn.close()
            return self.send_json({
                "message": f"Student '{full_name}' ({roll_no}) added successfully!",
                "student": dict(new_student),
                "total_students": total_students
            })

        # 5. Mark Attendance (Live CRUD)
        if path == "/api/attendance/mark":
            session_id = payload.get("session_id")
            student_id = payload.get("student_id")
            status = payload.get("status", "Present")
            remarks = payload.get("remarks", "")

            if not session_id or not student_id:
                conn.close()
                return self.send_error_json("session_id and student_id are required", 400)

            # Insert or replace attendance
            cursor.execute("""
                INSERT INTO attendance (session_id, student_id, status, remarks, marked_at)
                VALUES (?, ?, ?, ?, CURRENT_TIMESTAMP)
                ON CONFLICT(session_id, student_id) DO UPDATE SET
                    status = excluded.status,
                    remarks = excluded.remarks,
                    marked_at = CURRENT_TIMESTAMP
            """, (session_id, student_id, status, remarks))
            conn.commit()

            # Fetch updated record
            rec = cursor.execute("""
                SELECT a.*, s.roll_no, s.full_name
                FROM attendance a
                JOIN students s ON a.student_id = s.student_id
                WHERE a.session_id = ? AND a.student_id = ?
            """, (session_id, student_id)).fetchone()
            total_att = cursor.execute("SELECT COUNT(*) FROM attendance").fetchone()[0]

            conn.close()
            return self.send_json({
                "message": f"Attendance for {rec['full_name']} marked as '{status}'",
                "record": dict(rec),
                "total_attendance_records": total_att
            })

        # 6. Bulk Mark Session Attendance
        if path == "/api/attendance/bulk":
            session_id = payload.get("session_id")
            status = payload.get("status", "Present")
            remarks = payload.get("remarks", "Bulk marked")

            if not session_id:
                conn.close()
                return self.send_error_json("session_id is required", 400)

            # Get section of session
            sess = cursor.execute("SELECT section_id FROM class_sessions WHERE session_id = ?", (session_id,)).fetchone()
            if not sess:
                conn.close()
                return self.send_error_json("Session not found", 404)

            # Get students in that section
            students = cursor.execute("SELECT student_id FROM students WHERE section_id = ?", (sess['section_id'],)).fetchall()
            for s in students:
                cursor.execute("""
                    INSERT INTO attendance (session_id, student_id, status, remarks, marked_at)
                    VALUES (?, ?, ?, ?, CURRENT_TIMESTAMP)
                    ON CONFLICT(session_id, student_id) DO UPDATE SET
                        status = excluded.status,
                        remarks = excluded.remarks,
                        marked_at = CURRENT_TIMESTAMP
                """, (session_id, s['student_id'], status, remarks))

            conn.commit()
            total_att = cursor.execute("SELECT COUNT(*) FROM attendance").fetchone()[0]
            conn.close()
            return self.send_json({
                "message": f"Bulk marked {len(students)} students as '{status}' for Session #{session_id}!",
                "count": len(students),
                "total_attendance_records": total_att
            })

        # 7. Create Class Session
        if path == "/api/sessions":
            section_id = payload.get("section_id")
            faculty_id = payload.get("faculty_id")
            session_date = payload.get("session_date")
            time_slot = payload.get("time_slot")
            room_no = payload.get("room_no")
            topic_covered = payload.get("topic_covered")
            status = payload.get("status", "Conducted")

            if not all([section_id, faculty_id, session_date, time_slot, room_no, topic_covered]):
                conn.close()
                return self.send_error_json("All session fields are required", 400)

            cursor.execute("""
                INSERT INTO class_sessions (section_id, faculty_id, session_date, time_slot, room_no, topic_covered, status)
                VALUES (?, ?, ?, ?, ?, ?, ?)
            """, (section_id, faculty_id, session_date, time_slot, room_no, topic_covered, status))
            new_id = cursor.lastrowid
            conn.commit()

            total_sessions = cursor.execute("SELECT COUNT(*) FROM class_sessions").fetchone()[0]
            conn.close()
            return self.send_json({
                "message": f"Class session #{new_id} on '{topic_covered}' created successfully!",
                "session_id": new_id,
                "total_sessions": total_sessions
            })

        # 8. Submit Leave Application
        if path == "/api/leaves":
            student_id = payload.get("student_id")
            leave_type_id = payload.get("leave_type_id")
            start_date = payload.get("start_date")
            end_date = payload.get("end_date")
            reason = payload.get("reason", "").strip()

            if not all([student_id, leave_type_id, start_date, end_date, reason]):
                conn.close()
                return self.send_error_json("All leave application fields are required", 400)

            applied_date = time.strftime('%Y-%m-%d')
            cursor.execute("""
                INSERT INTO leave_applications (student_id, leave_type_id, start_date, end_date, reason, applied_date, status)
                VALUES (?, ?, ?, ?, ?, ?, 'Pending')
            """, (student_id, leave_type_id, start_date, end_date, reason, applied_date))
            new_id = cursor.lastrowid
            conn.commit()

            total_leaves = cursor.execute("SELECT COUNT(*) FROM leave_applications").fetchone()[0]
            conn.close()
            return self.send_json({
                "message": f"Leave application #{new_id} submitted for approval!",
                "application_id": new_id,
                "total_leaves": total_leaves
            })

        # 9. Approve or Reject Leave Application (Transaction)
        if path.startswith("/api/leaves/") and path.endswith("/action"):
            app_id = path.split("/")[3]
            decision = payload.get("decision") # 'Approved' or 'Rejected'
            faculty_id = payload.get("faculty_id", 2) # default to HOD/Prof
            comments = payload.get("comments", "Decision processed via DBMS portal")

            if decision not in ['Approved', 'Rejected']:
                conn.close()
                return self.send_error_json("Decision must be 'Approved' or 'Rejected'", 400)

            decision_date = time.strftime('%Y-%m-%d')
            # Update leave application status
            cursor.execute("UPDATE leave_applications SET status = ? WHERE application_id = ?", (decision, app_id))
            
            # Insert approval audit record
            cursor.execute("""
                INSERT INTO leave_approvals (application_id, reviewed_by_faculty_id, decision_date, status, comments)
                VALUES (?, ?, ?, ?, ?)
                ON CONFLICT(application_id) DO UPDATE SET
                    reviewed_by_faculty_id = excluded.reviewed_by_faculty_id,
                    decision_date = excluded.decision_date,
                    status = excluded.status,
                    comments = excluded.comments
            """, (app_id, faculty_id, decision_date, decision, comments))

            conn.commit()
            conn.close()
            return self.send_json({
                "message": f"Leave application #{app_id} was successfully {decision}!",
                "application_id": app_id,
                "status": decision
            })

        # 10. Automatically Recalculate & Generate Shortage Alerts
        if path == "/api/alerts/generate":
            # Run calculation across all students
            sql = """
                SELECT 
                    s.student_id,
                    sec.course_id,
                    COUNT(a.attendance_id) AS total_sessions,
                    SUM(CASE WHEN a.status IN ('Present', 'Late') THEN 1 ELSE 0 END) AS attended_sessions,
                    ROUND((SUM(CASE WHEN a.status IN ('Present', 'Late') THEN 1.0 ELSE 0.0 END) * 100.0) / COUNT(a.attendance_id), 1) AS attendance_percentage
                FROM students s
                JOIN sections sec ON s.section_id = sec.section_id
                JOIN class_sessions cs ON cs.section_id = sec.section_id
                LEFT JOIN attendance a ON a.session_id = cs.session_id AND a.student_id = s.student_id
                GROUP BY s.student_id, sec.course_id
                HAVING total_sessions > 0 AND attendance_percentage < 75.0
            """
            shortage_rows = cursor.execute(sql).fetchall()
            gen_date = time.strftime('%Y-%m-%d')
            generated_count = 0

            for row in shortage_rows:
                pct = row['attendance_percentage']
                level = 'Debarred' if pct < 50.0 else ('Critical' if pct < 65.0 else 'Warning')
                
                # Check if alert already exists unresolved
                existing = cursor.execute("""
                    SELECT alert_id FROM shortage_alerts 
                    WHERE student_id = ? AND course_id = ? AND is_resolved = 0
                """, (row['student_id'], row['course_id'])).fetchone()

                if not existing:
                    cursor.execute("""
                        INSERT INTO shortage_alerts (student_id, course_id, attendance_percentage, alert_level, generated_date, is_resolved)
                        VALUES (?, ?, ?, ?, ?, 0)
                    """, (row['student_id'], row['course_id'], pct, level, gen_date))
                    generated_count += 1
                else:
                    cursor.execute("""
                        UPDATE shortage_alerts SET attendance_percentage = ?, alert_level = ?
                        WHERE alert_id = ?
                    """, (pct, level, existing['alert_id']))

            conn.commit()
            total_alerts = cursor.execute("SELECT COUNT(*) FROM shortage_alerts WHERE is_resolved = 0").fetchone()[0]
            conn.close()
            return self.send_json({
                "message": f"Processed shortage audit: {generated_count} new alerts generated!",
                "new_alerts": generated_count,
                "active_unresolved_alerts": total_alerts
            })

        conn.close()
        return self.send_error_json(f"POST endpoint '{path}' not found", 404)

    # ------------------ PUT HANDLERS ------------------ #
    def handle_api_put(self, path, payload):
        conn = get_connection()
        cursor = conn.cursor()

        # Update row in specific table
        if path.startswith("/api/table/"):
            parts = path[len("/api/table/"):].strip("/").split("/")
            if len(parts) != 2:
                conn.close()
                return self.send_error_json("Expected format /api/table/<name>/<id>", 400)
            tbl_name, row_id = parts[0], parts[1]

            valid_tables = [
                'departments', 'faculty', 'courses', 'sections', 'students',
                'class_sessions', 'attendance', 'leave_types', 'leave_applications',
                'leave_approvals', 'makeup_sessions', 'shortage_alerts'
            ]
            if tbl_name not in valid_tables:
                conn.close()
                return self.send_error_json(f"Table '{tbl_name}' is invalid.", 404)

            # Get primary key
            col_info = cursor.execute(f"PRAGMA table_info({tbl_name})").fetchall()
            pk_col = next((c['name'] for c in col_info if c['pk'] == 1), col_info[0]['name'])

            data = payload.get("data", {})
            if not data:
                conn.close()
                return self.send_error_json("No update fields provided", 400)

            set_clause = ", ".join([f"{k} = ?" for k in data.keys()])
            vals = list(data.values()) + [row_id]

            sql = f"UPDATE {tbl_name} SET {set_clause} WHERE {pk_col} = ?"
            cursor.execute(sql, vals)
            conn.commit()

            updated_row = cursor.execute(f"SELECT * FROM {tbl_name} WHERE {pk_col} = ?", (row_id,)).fetchone()
            conn.close()
            return self.send_json({
                "message": f"Row #{row_id} in {tbl_name} updated successfully!",
                "row": dict(updated_row) if updated_row else {}
            })

        # Update student directly
        if path.startswith("/api/students/"):
            student_id = path[len("/api/students/"):].strip("/")
            full_name = payload.get("full_name")
            email = payload.get("email")
            phone = payload.get("phone")
            section_id = payload.get("section_id")

            cursor.execute("""
                UPDATE students SET full_name = ?, email = ?, phone = ?, section_id = ?
                WHERE student_id = ?
            """, (full_name, email, phone, section_id, student_id))
            conn.commit()

            student = cursor.execute("SELECT * FROM students WHERE student_id = ?", (student_id,)).fetchone()
            conn.close()
            return self.send_json({
                "message": f"Student #{student_id} updated successfully!",
                "student": dict(student) if student else {}
            })

        # Resolve shortage alert
        if path.startswith("/api/alerts/") and path.endswith("/resolve"):
            alert_id = path.split("/")[3]
            cursor.execute("UPDATE shortage_alerts SET is_resolved = 1 WHERE alert_id = ?", (alert_id,))
            conn.commit()
            conn.close()
            return self.send_json({
                "message": f"Shortage alert #{alert_id} marked as Resolved!",
                "alert_id": alert_id
            })

        conn.close()
        return self.send_error_json(f"PUT endpoint '{path}' not found", 404)

    # ------------------ DELETE HANDLERS ------------------ #
    def handle_api_delete(self, path):
        conn = get_connection()
        cursor = conn.cursor()

        # Delete row from specific table
        if path.startswith("/api/table/"):
            parts = path[len("/api/table/"):].strip("/").split("/")
            if len(parts) != 2:
                conn.close()
                return self.send_error_json("Expected format /api/table/<name>/<id>", 400)
            tbl_name, row_id = parts[0], parts[1]

            valid_tables = [
                'departments', 'faculty', 'courses', 'sections', 'students',
                'class_sessions', 'attendance', 'leave_types', 'leave_applications',
                'leave_approvals', 'makeup_sessions', 'shortage_alerts'
            ]
            if tbl_name not in valid_tables:
                conn.close()
                return self.send_error_json(f"Table '{tbl_name}' is invalid.", 404)

            # Get primary key
            col_info = cursor.execute(f"PRAGMA table_info({tbl_name})").fetchall()
            pk_col = next((c['name'] for c in col_info if c['pk'] == 1), col_info[0]['name'])

            cursor.execute(f"DELETE FROM {tbl_name} WHERE {pk_col} = ?", (row_id,))
            conn.commit()

            total_count = cursor.execute(f"SELECT COUNT(*) FROM {tbl_name}").fetchone()[0]
            conn.close()
            return self.send_json({
                "message": f"Row #{row_id} deleted from {tbl_name} successfully!",
                "table": tbl_name,
                "deleted_id": row_id,
                "remaining_rows": total_count
            })

        # Delete student directly
        if path.startswith("/api/students/"):
            student_id = path[len("/api/students/"):].strip("/")
            student = cursor.execute("SELECT roll_no, full_name FROM students WHERE student_id = ?", (student_id,)).fetchone()
            if not student:
                conn.close()
                return self.send_error_json("Student not found", 404)

            name = student['full_name']
            roll = student['roll_no']
            cursor.execute("DELETE FROM students WHERE student_id = ?", (student_id,))
            conn.commit()

            total_students = cursor.execute("SELECT COUNT(*) FROM students").fetchone()[0]
            conn.close()
            return self.send_json({
                "message": f"Student '{name}' ({roll}) deleted from database!",
                "deleted_id": student_id,
                "remaining_students": total_students
            })

        # Delete attendance record
        if path.startswith("/api/attendance/"):
            att_id = path[len("/api/attendance/"):].strip("/")
            cursor.execute("DELETE FROM attendance WHERE attendance_id = ?", (att_id,))
            conn.commit()
            total_att = cursor.execute("SELECT COUNT(*) FROM attendance").fetchone()[0]
            conn.close()
            return self.send_json({
                "message": f"Attendance record #{att_id} deleted successfully!",
                "deleted_id": att_id,
                "remaining_records": total_att
            })

        # Delete session
        if path.startswith("/api/sessions/"):
            session_id = path[len("/api/sessions/"):].strip("/")
            cursor.execute("DELETE FROM class_sessions WHERE session_id = ?", (session_id,))
            conn.commit()
            total_sess = cursor.execute("SELECT COUNT(*) FROM class_sessions").fetchone()[0]
            conn.close()
            return self.send_json({
                "message": f"Class session #{session_id} deleted successfully!",
                "deleted_id": session_id,
                "remaining_sessions": total_sess
            })

        # Delete leave application
        if path.startswith("/api/leaves/"):
            app_id = path[len("/api/leaves/"):].strip("/")
            cursor.execute("DELETE FROM leave_applications WHERE application_id = ?", (app_id,))
            conn.commit()
            total_leaves = cursor.execute("SELECT COUNT(*) FROM leave_applications").fetchone()[0]
            conn.close()
            return self.send_json({
                "message": f"Leave application #{app_id} deleted successfully!",
                "deleted_id": app_id,
                "remaining_leaves": total_leaves
            })

        conn.close()
        return self.send_error_json(f"DELETE endpoint '{path}' not found", 404)

def run_server(port=PORT):
    # Enable address reuse for smooth restarts
    socketserver.TCPServer.allow_reuse_address = True
    with socketserver.TCPServer(("", port), AttendanceRequestHandler) as httpd:
        print("=" * 70)
        print("  STUDENT ATTENDANCE & LEAVE APPROVAL SYSTEM (TOPIC #26)")
        print("  Shaikh Humzah (25WU0102251) - AIML Whales")
        print("=" * 70)
        print(f"  ● Web UI & REST API Running at: http://localhost:{port}")
        print(f"  ● Serving Static Folder: {STATIC_DIR}")
        print(f"  ● Database: {DB_PATH}")
        print("  ● Press Ctrl+C to stop the server")
        print("=" * 70)
        try:
            httpd.serve_forever()
        except KeyboardInterrupt:
            print("\nShutting down server gracefully...")
            httpd.shutdown()

if __name__ == "__main__":
    run_server()
