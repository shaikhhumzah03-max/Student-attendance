"""
Zero-dependency PDF synthesizer in pure Python standard library.
Generates compliant, valid PDF 1.4 documents for Presentation-II, Presentation-III, and Project Report.
"""

import os

class CanvasPDF:
    def __init__(self, width=792, height=612):
        self.width = width
        self.height = height
        self.pages = []

    def new_page(self):
        page = Page(self.width, self.height)
        self.pages.append(page)
        return page

    def compile(self, output_path):
        objects = []
        
        # 1: Catalog
        # 2: Pages
        # 3: Font Regular (Helvetica)
        # 4: Font Bold (Helvetica-Bold)
        # 5: Font Mono (Courier)
        
        page_obj_ids = []
        content_obj_ids = []
        
        # We will assign IDs:
        # 1: Catalog
        # 2: Pages
        # 3: F1 (Helvetica)
        # 4: F2 (Helvetica-Bold)
        # 5: F3 (Courier)
        # Page 1: 6, Content 1: 7
        # Page 2: 8, Content 2: 9, etc.
        
        next_id = 6
        for p in self.pages:
            page_obj_ids.append(next_id)
            content_obj_ids.append(next_id + 1)
            next_id += 2

        # Obj 1: Catalog
        catalog = "<< /Type /Catalog /Pages 2 0 R >>"
        
        # Obj 2: Pages
        kids_str = " ".join([f"{pid} 0 R" for pid in page_obj_ids])
        pages_dict = f"<< /Type /Pages /Kids [ {kids_str} ] /Count {len(self.pages)} >>"
        
        # Fonts
        f1 = "<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>"
        f2 = "<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica-Bold >>"
        f3 = "<< /Type /Font /Subtype /Type1 /BaseFont /Courier >>"
        
        obj_list = [
            (1, catalog),
            (2, pages_dict),
            (3, f1),
            (4, f2),
            (5, f3)
        ]
        
        for i, p in enumerate(self.pages):
            pid = page_obj_ids[i]
            cid = content_obj_ids[i]
            stream_data = p.get_stream()
            p_dict = f"<< /Type /Page /Parent 2 0 R /MediaBox [ 0 0 {p.width} {p.height} ] /Contents {cid} 0 R /Resources << /Font << /F1 3 0 R /F2 4 0 R /F3 5 0 R >> >> >>"
            c_dict = f"<< /Length {len(stream_data)} >>\nstream\n{stream_data}\nendstream"
            obj_list.append((pid, p_dict))
            obj_list.append((cid, c_dict))

        # Sort by object ID
        obj_list.sort(key=lambda x: x[0])
        
        # Write PDF binary structure
        with open(output_path, "wb") as f:
            f.write(b"%PDF-1.4\n")
            offsets = {}
            for oid, ocontent in obj_list:
                offsets[oid] = f.tell()
                clean_content = ocontent.encode("latin-1", "replace")
                f.write(f"{oid} 0 obj\n".encode("latin-1"))
                f.write(clean_content)
                f.write(b"\nendobj\n")
            
            xref_pos = f.tell()
            f.write(b"xref\n")
            f.write(f"0 {len(obj_list) + 1}\n".encode("latin-1"))
            f.write(b"0000000000 65535 f \n")
            for oid in range(1, len(obj_list) + 1):
                off = offsets[oid]
                f.write(f"{off:010d} 00000 n \n".encode("latin-1"))
            
            trailer = f"trailer\n<< /Size {len(obj_list) + 1} /Root 1 0 R >>\nstartxref\n{xref_pos}\n%%EOF\n"
            f.write(trailer.encode("latin-1"))
            
        print(f"Generated PDF successfully: {output_path} ({len(self.pages)} pages)")

class Page:
    def __init__(self, width, height):
        self.width = width
        self.height = height
        self.commands = []

    def rect(self, x, y, w, h, fill_rgb=None, stroke_rgb=None, stroke_width=1):
        cmds = []
        if fill_rgb:
            r, g, b = fill_rgb
            cmds.append(f"{r:.3f} {g:.3f} {b:.3f} rg")
        if stroke_rgb:
            r, g, b = stroke_rgb
            cmds.append(f"{r:.3f} {g:.3f} {b:.3f} RG")
            cmds.append(f"{stroke_width} w")
        
        cmds.append(f"{x} {y} {w} {h} re")
        if fill_rgb and stroke_rgb:
            cmds.append("B")
        elif fill_rgb:
            cmds.append("f")
        elif stroke_rgb:
            cmds.append("S")
        self.commands.append(" ".join(cmds))

    def line(self, x1, y1, x2, y2, stroke_rgb=(0,0,0), stroke_width=1):
        r, g, b = stroke_rgb
        cmd = f"{r:.3f} {g:.3f} {b:.3f} RG {stroke_width} w {x1} {y1} m {x2} {y2} l S"
        self.commands.append(cmd)

    def text(self, x, y, text_str, font="F1", size=12, rgb=(0,0,0)):
        # Normalize special unicode characters to ASCII/Latin-1
        replacements = {
            "\u2013": "-", "\u2014": "-", "\u2018": "'", "\u2019": "'",
            "\u201c": '"', "\u201d": '"', "\u2022": "*", "\u2265": ">=",
            "\u2264": "<=", "\u22c8": "JOIN", "\u03c3": "SELECT",
            "\u03b3": "GROUPBY", "\u2192": "->"
        }
        for k, v in replacements.items():
            text_str = text_str.replace(k, v)
        # Escape parenthesis
        clean_str = text_str.replace("\\", "\\\\").replace("(", "\\(").replace(")", "\\)")
        r, g, b = rgb
        cmd = f"BT {r:.3f} {g:.3f} {b:.3f} rg /{font} {size} Tf {x} {y} Td ({clean_str}) Tj ET"
        self.commands.append(cmd)

    def get_stream(self):
        return "\n".join(self.commands)
