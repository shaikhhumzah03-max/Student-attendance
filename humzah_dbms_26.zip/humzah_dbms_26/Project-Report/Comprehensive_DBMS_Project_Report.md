# PROJECT REPORT
# Design and Implementation of a Database Management System for Student Attendance and Leave Approval System

**NAME:** SHAIKH HUMZAH  
**ROLL NO:** 25WU0102251  
**PROGRAM:** B.Tech Artificial Intelligence and Machine Learning  
**COURSE NAME:** DATABASE MANAGEMENT SYSTEMS  
**FACULTY NAME:** Dr. Kiran Mayee Adavala  
**ACADEMIC YEAR:** 2025 – 2029  

**WOXSEN UNIVERSITY**  
School of Technology  

---

## ABSTRACT

Managing academic student attendance and leave approval operations manually is a challenging administrative task for educational institutions, particularly as the number of students, sections, course offerings, and faculty members grows. Information related to daily classroom roll calls, student leave requests, medical certificates, makeup lectures, and statutory attendance shortage notifications is often scattered across physical attendance registers, loose paperwork, and disconnected spreadsheets, leading to reconciliation delays, proxy manipulation risks, and severe administrative bottlenecks prior to semester examinations. This project, titled **"Design and Implementation of a Database Management System for Student Attendance and Leave Approval System"**, addresses this problem by designing and implementing a centralized, normalized relational database that systematically organizes and enforces all attendance and leave management workflows.

The system models twelve interrelated entities — Department, Faculty, Course, Section, Student, Class Session, Attendance Record, Leave Type, Leave Application, Leave Approval, Makeup Session, and Shortage Alert — using a normalized 3NF relational schema implemented in SQLite and MySQL. Primary key, composite unique, and foreign key constraints enforce strict referential integrity between departments and faculty, faculty and sections, courses and sessions, and students and their daily attendance, leave workflows, and shortage alerts. Domain-level `CHECK` constraints guarantee that attendance status codes ('Present', 'Absent', 'Late', 'Excused') and leave statuses ('Pending', 'Approved', 'Rejected') adhere strictly to university academic regulations.

A responsive, minimalist, Apple Human Interface Guidelines-inspired administrative interface was developed using vanilla modern HTML5, CSS3, and JavaScript, communicating with a zero-dependency Python backend server via RESTful endpoints. The interface allows authorized academic staff to view real-time statistics, search and filter student records, conduct single-touch live roll calls with atomic database updates, review multi-tier leave requests, inspect live row counts across all 12 schema tables, and execute arbitrary SQL queries directly within an in-browser console.

The database was implemented and populated with a comprehensive, realistic academic dataset of 270 records spanning all 12 relations. A suite of advanced SQL queries — including multi-table joins, subqueries, aggregate grouping, and shortage remedial class calculation formulas — was executed to validate core academic rules. Comprehensive functional testing, including a live Create-Read-Update-Delete (CRUD) demonstration with concurrent database verification on a sample student record, was performed to confirm the correctness of operations and schema integrity. The project demonstrates the practical application of foundational Database Management Systems principles — entity-relationship modeling, 3NF normalization, relational querying, atomic transaction management, and full-stack database integration — in building a robust, institutional-grade administrative solution.

---

## TABLE OF CONTENTS

- **ABSTRACT** ................................................................................................................................. 2
- **TABLE OF CONTENTS** ............................................................................................................. 3
- **1. INTRODUCTION** ................................................................................................................... 5
- **2. PROBLEM STATEMENT** ...................................................................................................... 6
- **3. OBJECTIVES AND SCOPE** ................................................................................................... 7
  - 3.1 Objectives ............................................................................................................................ 7
  - 3.2 Scope .................................................................................................................................. 7
- **4. EXISTING SYSTEM AND PROPOSED SYSTEM** ............................................................. 8
- **5. SOFTWARE AND HARDWARE REQUIREMENTS** ......................................................... 9
  - 5.1 Software Requirements ....................................................................................................... 9
  - 5.2 Hardware Requirements ...................................................................................................... 9
- **6. SYSTEM ARCHITECTURE** ............................................................................................... 10
  - 6.1 Frontend Layer (Apple HIG Vanilla Web) ........................................................................ 10
  - 6.2 Backend Layer (Python REST Engine) ............................................................................. 10
  - 6.3 Database Layer (SQLite / MySQL) .................................................................................... 10
- **7. DATABASE DESIGN** ........................................................................................................... 11
- **8. ER DIAGRAM** ..................................................................................................................... 12
- **9. RELATIONAL SCHEMA AND NORMALIZATION** ....................................................... 13
  - 9.1 Relational Schema Overview ........................................................................................... 13
  - 9.2 Normalization (1NF, 2NF, 3NF, BCNF) ........................................................................... 13
- **10. DATA DICTIONARY** ......................................................................................................... 14
- **11. DATABASE IMPLEMENTATION** .................................................................................. 16
  - 11.1 Database Creation .......................................................................................................... 16
  - 11.2 Representative Table Creation ....................................................................................... 16
  - 11.3 Representative Alteration and Constraints ..................................................................... 16
- **12. DDL AND DML OPERATIONS** ....................................................................................... 17
  - 12.1 INSERT ........................................................................................................................... 17
  - 12.2 UPDATE .......................................................................................................................... 17
  - 12.3 DELETE .......................................................................................................................... 17
  - 12.4 SELECT ........................................................................................................................... 17
- **13. SQL QUERIES AND RESULTS** ....................................................................................... 17
  - Query 1: Attendance Shortage Remedial Class Calculation (< 75%) ....................................... 17
  - Query 2: 4-Table Multi-Entity Relationship JOIN ................................................................. 18
  - Query 3: Course-Wise Attendance Health and Enrollment Metrics ....................................... 18
  - Query 4: Faculty Leave Approval Decision Audit .................................................................. 18
  - Query 5: Active Shortage Debarment Risk Roster .................................................................. 18
  - Query 6: Session Attendance Status Breakdown Aggregation ............................................... 19
  - Query 7: Scheduled Class Sessions Conducted vs Marked Count .......................................... 19
- **14. USER INTERFACE DESIGN** ............................................................................................. 20
  - 14.1 Interface Features ............................................................................................................ 20
  - 14.2 Interface Screens ............................................................................................................. 20
- **15. CRUD / LIVE DATABASE DEMONSTRATION** ........................................................... 24
  - 15.1 Step 1 — Initial State ...................................................................................................... 24
  - 15.2 Step 2 — Insertion .......................................................................................................... 24
  - 15.3 Step 3 — Database Verification (After Insert) ............................................................... 25
  - 15.4 Step 4 — Deletion ........................................................................................................... 25
  - 15.5 Step 5 — Database Verification (After Delete) .............................................................. 25
- **16. IMPLEMENTATION DETAILS** ....................................................................................... 26
  - 16.1 Final Database Statistics ................................................................................................. 26
  - 16.2 Backend Implementation ................................................................................................ 26
  - 16.3 Frontend Implementation ............................................................................................... 26
- **17. TESTING AND VALIDATION** ........................................................................................ 27
- **18. CHALLENGES AND LIMITATIONS** ............................................................................... 28
  - 18.1 Challenges Faced ............................................................................................................ 28
  - 18.2 Limitations ...................................................................................................................... 28
- **19. CONCLUSION, FUTURE SCOPE AND REFERENCES** ................................................. 28
  - 19.1 Conclusion ...................................................................................................................... 28
  - 19.2 Future Scope ................................................................................................................... 29
  - 19.3 References ....................................................................................................................... 29
- **A. GITHUB APPENDIX** .......................................................................................................... 30
  - Repository Structure ............................................................................................................... 30

---

## 1. INTRODUCTION

Database Management Systems (DBMS) form the foundational computational infrastructure of modern academic institutions. An academic attendance and leave administration system represents a complex network of interrelated entities — students, faculty members, academic departments, courses, section cohorts, scheduled classroom sessions, daily attendance marks, leave categories, formal leave requests, multi-tier approvals, makeup classes, and debarment warning alerts. Tracking these entities and their temporal relationships accurately is essential for upholding academic standards, satisfying accreditation requirements (such as NAAC, NBA, and UGC guidelines), and ensuring fairness during end-semester examination hall-ticket issuance.

Under conventional manual record-keeping practices, attendance is documented on paper registers or decentralized desktop spreadsheets. These methods suffer from severe drawbacks: they are highly prone to transcription mistakes, vulnerable to proxy manipulation, difficult to search or audit, and incapable of providing real-time alerts when a student drops below statutory minimum attendance thresholds (commonly 75.0%). Furthermore, student leave applications submitted for genuine medical or institutional reasons often remain trapped in paper approval queues, failing to reflect in course attendance tallies until long after examinations have concluded.

A relational database system is uniquely suited to solve these challenges. By organizing data into normalized relational tables connected through primary and foreign keys, the database prevents duplicate entries, enforces referential integrity, and enables rapid querying of complex criteria.

This project designs and implements a complete Relational Database Management System for a **Student Attendance and Leave Approval System** (Course Project Topic #26). The database is structured across twelve normalized tables implemented in SQLite and MySQL dialects, containing 270 comprehensive seed records. The system is paired with a clean, Apple Human Interface Guidelines-inspired light mode web application and a dedicated interactive command-line interface (CLI) to support seamless live CRUD operations, rapid query execution, and robust administrative auditing.

---

## 2. PROBLEM STATEMENT

Academic attendance and leave coordination in university departments involves continuous data exchange among students, course instructors, section coordinators, and heads of departments. When this information is maintained manually or through unintegrated spreadsheets, several critical problems recur:

- **End-of-Term Percentage Compilation Lag:** Attendance percentages are calculated manually at the end of each semester. At-risk students are notified of shortages too late to attend remedial or makeup sessions.
- **Disconnected Leave and Duty Workflows:** Students submitting medical certificates or on-duty event requests face fragmented approval paths. Approved leaves fail to synchronize with individual instructor attendance sheets, causing unjustified shortage marks.
- **Vulnerability to Proxy Marking and Duplicate Entries:** Lack of atomic database constraints permits duplicate attendance marks for the same student within a single lecture time slot.
- **Absence of Unified Query Capabilities:** Retrieving cross-table insights — such as identifying all students in a specific section needing remedial classes to reach 75% attendance — requires laborious manual reconciliation.
- **Lack of Auditable Action Logs:** Approvals and status modifications made on paper cannot be audited for accountability or timestamps.
- **Absence of Non-Technical Interfaces:** Faculty and administrative staff require an intuitive, responsive interface to mark roll calls, review leaves, and inspect data without writing raw SQL.

These problems establish the need for a centralized, normalized relational database accessible through an Apple-inspired web interface and an interactive SQL command-line tool.

---

## 3. OBJECTIVES AND SCOPE

### 3.1 Objectives

1. Design a normalized relational schema (Third Normal Form) for university attendance and leave management.
2. Model twelve distinct entities capturing departments, faculty, courses, sections, students, sessions, attendance, leave types, applications, approvals, makeup classes, and alerts.
3. Enforce strict referential integrity through foreign keys with appropriate `ON DELETE CASCADE` and `ON DELETE RESTRICT` behaviors.
4. Apply domain-level `CHECK` constraints to restrict attendance statuses ('Present', 'Absent', 'Late', 'Excused') and validate date sequences.
5. Create composite unique constraints (`UNIQUE(session_id, student_id)`) to structurally eliminate duplicate attendance logging.
6. Populate the schema with a rich, realistic institutional dataset exceeding minimum course requirements (270 records across 12 tables).
7. Develop a responsive, minimalist, Apple HIG light mode web interface supporting live Create, Read, Update, and Delete (CRUD) operations.
8. Implement single-touch attendance roll-call marking with instantaneous database reflection via atomic UPSERT queries.
9. Construct analytical SQL queries and database views to compute cumulative attendance percentages and calculate remedial lectures needed for compliance.
10. Build an interactive, single-table SQL CLI tool for viva evaluation and ad-hoc query execution.
11. Validate system correctness through exhaustive negative constraint testing and automated test harnesses.

### 3.2 Scope

The system encompasses the following operational domains:
- **Student Information Management:** Enrollment, roll numbers, sections, semesters, and contact details.
- **Academic Scheduling:** Course details, section cohorts (e.g., AIML Whales & Panthers), classroom allocations, and session time slots.
- **Live Attendance Recording:** Per-session roll-call marking with four distinct status codes and instant percentage calculation.
- **Leave Application Lifecycle:** Submission of medical, casual, duty, and sports leave with document remarks, followed by faculty approval/rejection.
- **Remedial & Makeup Sessions:** Scheduling makeup lectures linked to canceled sessions with attendance synchronization.
- **Shortage & Debarment Auditing:** Automated detection of students falling below 75% attendance with calculated remedial requirements.
- **Web Administration & SQL Terminal:** In-browser CRUD tables, live database schema inspector, and SQL query execution.

*Future Scope:* Biometric fingerprint/facial recognition hardware integration, automated SMS/email alerts to parents, and automated timetable conflict solvers (detailed in Section 19).

---

## 4. EXISTING SYSTEM AND PROPOSED SYSTEM

| Feature / Dimension | Existing / Manual Approach | Proposed Relational System |
| :--- | :--- | :--- |
| **Data Storage** | Physical paper registers or isolated Excel spreadsheets | Centralized 3NF normalized SQLite / MySQL relational database |
| **Data Consistency** | High risk of duplicate student IDs and conflicting course records | Primary and unique constraints guarantee absolute entity uniqueness |
| **Referential Integrity** | No enforcement; orphaned records occur when students change sections | Foreign keys formally enforce parent-child referential integrity |
| **Duplicate Marking** | Vulnerable to accidental double-entry or proxy attendance | Composite unique constraint `UNIQUE(session_id, student_id)` prevents duplicates |
| **Attendance Calculations** | Manual arithmetic compilation at semester end; prone to error | Dynamic SQL views and aggregate queries compute percentages instantaneously |
| **Leave Synchronization** | Paper leave letters rarely reach course instructors on time | Integrated leave approval workflow updates attendance records automatically |
| **Debarment Warning** | Static notification issued after debarment cutoff date | Automated shortage alerts generated dynamically as attendance drops |
| **User Interface** | Cumbersome physical registers requiring manual handwriting | Apple HIG minimalist light-mode web app with single-touch roll-call pills |
| **Ad-Hoc Querying** | Impossible without manual page-by-page register inspection | Interactive SQL CLI and in-browser terminal returning unified box tables |

---

## 5. SOFTWARE AND HARDWARE REQUIREMENTS

### 5.1 Software Requirements

| Category | Technology Used | Version / Specification |
| :--- | :--- | :--- |
| **Database Engine** | SQLite 3 / MySQL | SQLite 3.43+ / MySQL 8.0+ |
| **Backend Runtime** | Python 3 | Python 3.10+ (Standard Library: `http.server`, `sqlite3`, `json`) |
| **Backend Framework** | Native Python REST Server | Zero-dependency microservices architecture |
| **Frontend Technologies** | HTML5, CSS3, JavaScript (ES6+) | Apple Human Interface Guidelines Design System |
| **Browser Compatibility** | Safari, Chrome, Edge, Firefox | Modern evergreen web browsers supporting CSS Grid & Flexbox |
| **CLI Query Environment** | Python Terminal Tool (`query_cli.py`) | Interactive Unicode box-drawing table renderer |
| **Version Control** | Git & GitHub | Distributed version control with branching workflows |
| **Development Environment** | Visual Studio Code / Terminal | macOS Zsh / Unix Shell |

### 5.2 Hardware Requirements

| Component | Minimum Requirement | Recommended Specification |
| :--- | :--- | :--- |
| **Processor** | Dual-core 64-bit CPU (2.0 GHz) | Apple Silicon (M1/M2/M3) or Intel Core i7 (2.8 GHz+) |
| **System Memory (RAM)** | 4 GB | 8 GB or 16 GB |
| **Hard Disk Storage** | 500 MB free space | 1 GB SSD storage |
| **Display Resolution** | 1280 × 800 pixels | 1920 × 1080 (FHD) or 2560 × 1600 (Retina) |
| **Network Interface** | Local loopback network interface | TCP/IP network connection for localhost / LAN hosting |

---

## 6. SYSTEM ARCHITECTURE

The system implements a classic Three-Tier Architectural Pattern, ensuring strict separation of presentation, business logic, and persistent storage:

```
                  USER / FACULTY / ADMINISTRATOR
                                ↓
         ┌──────────────────────────────────────────────┐
         │     TIER 1: PRESENTATION LAYER (FRONTEND)    │
         │   Apple HIG Minimalist Light Mode Interface  │
         │   • Live Student CRUD & Modal Forms          │
         │   • Touch Roll-Call Attendance Sheet         │
         │   • Live Database Tables Inspector           │
         │   • In-Browser Interactive SQL Console       │
         └──────────────────────┬───────────────────────┘
                                │ HTTP / REST API (JSON)
                                ↓
         ┌──────────────────────────────────────────────┐
         │    TIER 2: APPLICATION LAYER (PYTHON SERVER) │
         │   Zero-Dependency Native HTTP Server (run.py)│
         │   • REST Request Routing & Body Parsing      │
         │   • Domain Integrity & Business Validation   │
         │   • Parameterized SQL Query Dispatcher       │
         │   • JSON Response Serialization              │
         └──────────────────────┬───────────────────────┘
                                │ Native SQLite3 / MySQL Connector
                                ↓
         ┌──────────────────────────────────────────────┐
         │       TIER 3: DATABASE LAYER (DBMS)          │
         │   Relational Schema (12 Normalized Tables)   │
         │   • Primary, Foreign, & Composite Keys       │
         │   • Domain CHECK Constraints & Indexes       │
         │   • Atomic ACID Transactions & Views         │
         └──────────────────────────────────────────────┘
```
*Figure 1: Three-Tier System Architecture*

### 6.1 Frontend Layer (Apple HIG Vanilla Web)
Built with vanilla modern web standards to ensure zero build bloat, instantaneous loading, and a clean aesthetic inspired by Apple Human Interface Guidelines:
- Frosted glass navigation bars (`backdrop-filter: blur(20px)`).
- Dynamic Island floating notifications providing live database mutation feedback.
- Interactive roll-call matrix with immediate visual status badges.
- Live database schema inspector displaying raw table rows and record counts.

### 6.2 Backend Layer (Python REST Engine)
Built entirely using Python's standard library (`http.server`, `socketserver`, `sqlite3`, `json`):
- Exposes clean REST endpoints (`/api/stats`, `/api/students`, `/api/attendance/mark`, `/api/tables`, `/api/query`).
- Enforces parameterized queries to eliminate SQL injection vulnerabilities.
- Handles atomic transactions (`conn.commit()`, `conn.rollback()`) for data integrity.

### 6.3 Database Layer (SQLite / MySQL)
Stores all institutional data across 12 normalized tables:
- SQLite 3 embedded engine for lightweight, zero-configuration local execution.
- Full DDL/DML compatibility with MySQL 8.0 enterprise syntax (including triggers and foreign key cascades).
- Maintains referential integrity through foreign key constraints and domain-level rules.

---

## 7. DATABASE DESIGN

The relational database consists of twelve normalized tables capturing the academic lifecycle:

| Table Name | Entity Represented | Primary Purpose & Key Relationships |
| :--- | :--- | :--- |
| `departments` | Academic Departments | Stores department codes and names (e.g., School of Technology, AI & ML). |
| `faculty` | Teaching Faculty | Stores faculty credentials, designations, and department references. |
| `courses` | Academic Courses | Stores course codes, names, credits, and offering departments. |
| `sections` | Student Sections / Cohorts | Bridges courses to assigned faculty coordinators and student cohorts. |
| `students` | Enrolled Learners | Stores student roll numbers, names, email, and assigned section IDs. |
| `class_sessions` | Timetabled Lectures | Represents individual conducted classes with dates, time slots, and room numbers. |
| `attendance` | Per-Student Session Marks | Associative entity recording attendance status per student per lecture. |
| `leave_types` | Leave Categories | Reference table storing leave codes (Medical, Casual, Duty, Sports). |
| `leave_applications` | Student Leave Requests | Tracks leave date ranges, reasons, medical document links, and review states. |
| `leave_approvals` | Faculty Decision Records | Audits approval/rejection decisions, reviewing faculty IDs, and remarks. |
| `makeup_sessions` | Compensatory Lectures | Tracks remedial sessions scheduled to compensate for canceled classes. |
| `shortage_alerts` | Debarment Warning Notices | Records automated warning notices generated for students below 75% attendance. |

---

## 8. ER DIAGRAM

The Entity-Relationship structure captures all cardinalities, primary keys, and foreign keys across the 12 schema relations:

```
[DEPARTMENTS] (PK: department_id)
      │ 1 : N
      ├───────────────► [FACULTY] (PK: faculty_id, FK: department_id)
      │                       │ 1 : N
      │                       ├───────────────► [SECTIONS] (PK: section_id)
      │ 1 : N                 │                       │           ▲
      ▼                       │                       │ 1 : N     │
[COURSES] (PK: course_id) ────┘                       ▼           │
      │                                         [STUDENTS] (PK: student_id)
      │ 1 : N                                         │ 1 : N     │
      ▼                                               │           │ 1 : N
[SECTIONS] ───────────────────────────────────────────┤           ▼
      │ 1 : N                                         │     [LEAVE_APPLICATIONS]
      ▼                                               │     (PK: application_id)
[CLASS_SESSIONS] (PK: session_id)                     │           │ 1 : 1
      │ 1 : N                                         │           ▼
      ▼                                               │     [LEAVE_APPROVALS]
[ATTENDANCE] (PK: attendance_id) ◄────────────────────┘     (PK: approval_id)
 (FK: session_id, FK: student_id)
 [UNIQUE(session_id, student_id)]

[STUDENTS] ──── 1 : N ────► [SHORTAGE_ALERTS] (PK: alert_id, FK: student_id)
[CLASS_SESSIONS] ─ 0..1 : N ─► [MAKEUP_SESSIONS] (PK: makeup_id, FK: original_session_id)
[LEAVE_TYPES] ──── 1 : N ────► [LEAVE_APPLICATIONS] (FK: leave_type_id)
```
*Figure 2: Conceptual Entity-Relationship Model of Topic #26 System*

---

## 9. RELATIONAL SCHEMA AND NORMALIZATION

### 9.1 Relational Schema Overview
The relational schema formally translates the conceptual model into concrete relations with explicit primary keys (`PK`), foreign keys (`FK`), and domain integrity constraints:

- `departments` (**department_id**, dept_name, dept_code)
- `faculty` (**faculty_id**, full_name, email, phone, *department_id*, designation)
- `courses` (**course_id**, course_code, course_name, credits, *department_id*, semester)
- `sections` (**section_id**, section_name, *course_id*, *faculty_id*, academic_year, semester)
- `students` (**student_id**, roll_no, full_name, email, phone, *section_id*, semester, admission_year)
- `class_sessions` (**session_id**, *section_id*, *faculty_id*, session_date, time_slot, room_no, topic_covered, status)
- `attendance` (**attendance_id**, *session_id*, *student_id*, status, marked_at, remarks)
- `leave_types` (**leave_type_id**, type_name, max_days_allowed, requires_document)
- `leave_applications` (**application_id**, *student_id*, *leave_type_id*, start_date, end_date, total_days, reason, document_url, status)
- `leave_approvals` (**approval_id**, *application_id*, *reviewed_by_faculty_id*, decision_date, status, remarks)
- `makeup_sessions` (**makeup_id**, *original_session_id*, *section_id*, session_date, time_slot, room_no, reason)
- `shortage_alerts` (**alert_id**, *student_id*, *course_id*, attendance_percentage, alert_level, generated_date, is_resolved)

### 9.2 Normalization (1NF, 2NF, 3NF, BCNF)
The schema was normalized systematically to eliminate update, insertion, and deletion anomalies:

- **First Normal Form (1NF):** All attributes are atomic with single scalar values. Repeating groups (such as multiple attendance marks stored in a comma-separated field) are eliminated into individual rows in the `attendance` table.
- **Second Normal Form (2NF):** Every non-prime attribute is fully functionally dependent on the primary key. In the `attendance` relation, attributes like `status` depend on the composite pair `(session_id, student_id)`, avoiding partial dependencies on either session or student alone.
- **Third Normal Form (3NF):** No transitive dependencies exist between non-prime attributes ($X \to Y$ where $Y \to Z$). For instance, student details (name, email) depend solely on `student_id` and are not duplicated inside `attendance` or `leave_applications`; those relations reference `student_id` as a foreign key.
- **Boyce-Codd Normal Form (BCNF):** For every non-trivial functional dependency $X \to Y$, $X$ is a superkey. Course codes uniquely identify courses, roll numbers uniquely identify students, and section identifiers uniquely determine assigned faculty coordinators.

---

## 10. DATA DICTIONARY

The data dictionary documents attribute definitions, data types, key constraints, and descriptions across the primary schema relations:

### Table: students
| Attribute | Data Type | Key / Constraint | Description |
| :--- | :--- | :--- | :--- |
| `student_id` | INT / INTEGER | PRIMARY KEY, AUTO_INCREMENT | Unique surrogate identifier for each student |
| `roll_no` | VARCHAR(20) | UNIQUE, NOT NULL | Institutional roll number (e.g., 25WU0102251) |
| `full_name` | VARCHAR(100) | NOT NULL | Full legal name of the student |
| `email` | VARCHAR(120) | UNIQUE, NOT NULL | University email address |
| `phone` | VARCHAR(15) | NOT NULL | Contact phone number |
| `section_id` | INT | FOREIGN KEY → sections(section_id) | Assigned section cohort |
| `semester` | INT | CHECK (semester BETWEEN 1 AND 8) | Current academic semester |
| `admission_year` | INT | NOT NULL | Year of admission |

### Table: attendance
| Attribute | Data Type | Key / Constraint | Description |
| :--- | :--- | :--- | :--- |
| `attendance_id` | INT / INTEGER | PRIMARY KEY, AUTO_INCREMENT | Unique attendance log identifier |
| `session_id` | INT | FOREIGN KEY → class_sessions(session_id) | Associated scheduled class session |
| `student_id` | INT | FOREIGN KEY → students(student_id) | Enrolled student marked |
| `status` | VARCHAR(15) | CHECK (status IN ('Present','Absent','Late','Excused')) | Attendance status code |
| `marked_at` | TIMESTAMP | DEFAULT CURRENT_TIMESTAMP | Exact timestamp of attendance logging |
| `remarks` | VARCHAR(255) | DEFAULT NULL | Optional faculty notes |

### Table: class_sessions
| Attribute | Data Type | Key / Constraint | Description |
| :--- | :--- | :--- | :--- |
| `session_id` | INT / INTEGER | PRIMARY KEY, AUTO_INCREMENT | Unique session identifier |
| `section_id` | INT | FOREIGN KEY → sections(section_id) | Section for which class was scheduled |
| `faculty_id` | INT | FOREIGN KEY → faculty(faculty_id) | Conducting faculty instructor |
| `session_date` | DATE | NOT NULL | Scheduled lecture date |
| `time_slot` | VARCHAR(30) | NOT NULL | Lecture time interval (e.g., 09:00 - 10:00) |
| `room_no` | VARCHAR(20) | NOT NULL | Classroom / lecture hall identifier |
| `topic_covered` | VARCHAR(200) | NOT NULL | Syllabus lecture topic delivered |
| `status` | VARCHAR(20) | DEFAULT 'Conducted' | Operational status ('Conducted','Cancelled','Rescheduled') |

### Table: leave_applications
| Attribute | Data Type | Key / Constraint | Description |
| :--- | :--- | :--- | :--- |
| `application_id` | INT / INTEGER | PRIMARY KEY, AUTO_INCREMENT | Unique leave request identifier |
| `student_id` | INT | FOREIGN KEY → students(student_id) | Applicant student ID |
| `leave_type_id` | INT | FOREIGN KEY → leave_types(leave_type_id) | Leave category |
| `start_date` | DATE | NOT NULL | Starting date of requested leave |
| `end_date` | DATE | NOT NULL | Ending date of requested leave |
| `total_days` | INT | CHECK (total_days > 0) | Cumulative duration in days |
| `reason` | TEXT | NOT NULL | Statement of justification |
| `document_url` | VARCHAR(255) | DEFAULT NULL | Optional medical/duty certificate reference |
| `status` | VARCHAR(20) | CHECK (status IN ('Pending','Approved','Rejected')) | Current processing status |

---

## 11. DATABASE IMPLEMENTATION

The relational schema was implemented using standard DDL scripts with foreign keys, cascaded deletions, and domain constraints.

### 11.1 Database Creation
```sql
CREATE DATABASE attendance_system_db;
USE attendance_system_db;
```

### 11.2 Representative Table Creation
```sql
-- Representative Table: students
CREATE TABLE students (
    student_id INTEGER PRIMARY KEY AUTOINCREMENT,
    roll_no VARCHAR(20) UNIQUE NOT NULL,
    full_name VARCHAR(100) NOT NULL,
    email VARCHAR(120) UNIQUE NOT NULL,
    phone VARCHAR(15) NOT NULL,
    section_id INTEGER NOT NULL,
    semester INTEGER DEFAULT 4 CHECK (semester BETWEEN 1 AND 8),
    admission_year INTEGER DEFAULT 2025,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (section_id) REFERENCES sections(section_id) ON DELETE RESTRICT
);

-- Representative Table: attendance (with Composite Uniqueness and Check Constraint)
CREATE TABLE attendance (
    attendance_id INTEGER PRIMARY KEY AUTOINCREMENT,
    session_id INTEGER NOT NULL,
    student_id INTEGER NOT NULL,
    status VARCHAR(15) NOT NULL CHECK (status IN ('Present', 'Absent', 'Late', 'Excused')),
    marked_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    remarks VARCHAR(255),
    FOREIGN KEY (session_id) REFERENCES class_sessions(session_id) ON DELETE CASCADE,
    FOREIGN KEY (student_id) REFERENCES students(student_id) ON DELETE CASCADE,
    UNIQUE(session_id, student_id)
);
```

### 11.3 Representative Alteration and Constraints
```sql
-- Alter table to enforce additional performance indexes
CREATE INDEX idx_att_student ON attendance(student_id);
CREATE INDEX idx_att_session ON attendance(session_id);
CREATE INDEX idx_session_date ON class_sessions(session_date);
```

---

## 12. DDL AND DML OPERATIONS

Standard Data Manipulation Language (DML) statements execute the core operations of the application:

### 12.1 INSERT
```sql
INSERT INTO students (roll_no, full_name, email, phone, section_id, semester, admission_year)
VALUES ('25WU0102999', 'Shaikh Humzah Demo', 'humzah.demo@woxsen.edu.in', '9876543210', 1, 4, 2025);
```

### 12.2 UPDATE
```sql
-- Atomic status update upon faculty roll-call touch
UPDATE attendance 
SET status = 'Late', marked_at = CURRENT_TIMESTAMP
WHERE session_id = 1 AND student_id = 1;
```

### 12.3 DELETE
```sql
-- Deleting student record with cascading constraints
DELETE FROM students
WHERE roll_no = '25WU0102999';
```

### 12.4 SELECT
```sql
SELECT roll_no, full_name, email, section_id
FROM students
WHERE section_id = 1
ORDER BY roll_no ASC;
```

---

## 13. SQL QUERIES AND RESULTS

This section presents seven advanced analytical SQL queries demonstrating multi-table joins, conditional aggregations, subqueries, and mathematical calculations:

### Query 1: Attendance Shortage Remedial Class Calculation (< 75%)
Computes the exact number of consecutive future lectures a student must attend to cross the 75% threshold:
$$\text{Classes Needed} = \left\lceil \frac{0.75 \times \text{total} - \text{attended}}{1 - 0.75} \right\rceil$$

```sql
SELECT 
    s.roll_no, 
    s.full_name, 
    c.course_code,
    COUNT(a.attendance_id) AS total_sessions,
    SUM(CASE WHEN a.status IN ('Present', 'Late') THEN 1 ELSE 0 END) AS attended,
    ROUND((SUM(CASE WHEN a.status IN ('Present', 'Late') THEN 1.0 ELSE 0.0 END) * 100.0) / COUNT(a.attendance_id), 1) AS percentage,
    (CAST((0.75 * COUNT(a.attendance_id) - SUM(CASE WHEN a.status IN ('Present', 'Late') THEN 1 ELSE 0 END)) / 0.25 AS INTEGER) + 1) AS needed_classes
FROM students s
JOIN sections sec ON s.section_id = sec.section_id
JOIN courses c ON sec.course_id = c.course_id
JOIN class_sessions cs ON cs.section_id = sec.section_id
LEFT JOIN attendance a ON a.session_id = cs.session_id AND a.student_id = s.student_id
WHERE sec.section_name = 'AIML-A (Whales)' AND c.course_code = 'CS301'
GROUP BY s.student_id, c.course_id
HAVING percentage < 75.00
ORDER BY percentage ASC;
```

![Remedial Query Output](screenshots/cli_03_query1_shortage.svg)

### Query 2: 4-Table Multi-Entity Relationship JOIN
Connects students, section cohorts, courses, and faculty instructors in charge:
```sql
SELECT 
    s.roll_no, 
    s.full_name, 
    sec.section_name, 
    c.course_code, 
    f.full_name AS faculty_in_charge
FROM students s
JOIN sections sec ON s.section_id = sec.section_id
JOIN courses c ON sec.course_id = c.course_id
JOIN faculty f ON sec.faculty_id = f.faculty_id
LIMIT 5;
```

### Query 3: Course-Wise Attendance Health and Enrollment Metrics
Aggregates attendance health per course across departments:
```sql
SELECT 
    c.course_code, 
    c.course_name, 
    d.dept_code,
    COUNT(DISTINCT cs.session_id) AS sessions_held,
    COUNT(DISTINCT s.student_id) AS enrolled_students,
    ROUND((SUM(CASE WHEN a.status IN ('Present', 'Late') THEN 1.0 ELSE 0.0 END) * 100.0) / COUNT(a.attendance_id), 1) AS avg_attendance_pct
FROM courses c
JOIN departments d ON c.department_id = d.department_id
JOIN sections sec ON sec.course_id = c.course_id
JOIN students s ON s.section_id = sec.section_id
JOIN class_sessions cs ON cs.section_id = sec.section_id
JOIN attendance a ON a.session_id = cs.session_id AND a.student_id = s.student_id
GROUP BY c.course_id
ORDER BY avg_attendance_pct DESC;
```

### Query 4: Faculty Leave Approval Decision Audit
Tracks review throughput and decision patterns per faculty member:
```sql
SELECT 
    f.faculty_id, 
    f.full_name AS faculty_name, 
    f.designation,
    COUNT(appr.approval_id) AS total_reviews,
    SUM(CASE WHEN appr.status = 'Approved' THEN 1 ELSE 0 END) AS approved_count,
    SUM(CASE WHEN appr.status = 'Rejected' THEN 1 ELSE 0 END) AS rejected_count
FROM faculty f
JOIN leave_approvals appr ON f.faculty_id = appr.reviewed_by_faculty_id
GROUP BY f.faculty_id
ORDER BY total_reviews DESC;
```

### Query 5: Active Shortage Debarment Risk Roster
Identifies unresolved debarment risk notices:
```sql
SELECT 
    sa.alert_id, 
    s.roll_no, 
    s.full_name, 
    c.course_code, 
    sa.attendance_percentage, 
    sa.alert_level, 
    sa.generated_date
FROM shortage_alerts sa
JOIN students s ON sa.student_id = s.student_id
JOIN courses c ON sa.course_id = c.course_id
WHERE sa.is_resolved = 0
ORDER BY sa.attendance_percentage ASC;
```

### Query 6: Session Attendance Status Breakdown Aggregation
Computes global distribution of attendance marks:
```sql
SELECT 
    status, 
    COUNT(*) AS total_count,
    ROUND((COUNT(*) * 100.0) / (SELECT COUNT(*) FROM attendance), 1) AS percentage_of_total
FROM attendance 
GROUP BY status;
```

### Query 7: Scheduled Class Sessions Conducted vs Marked Count
Audits class sessions against recorded roll-call records:
```sql
SELECT 
    cs.session_id, 
    cs.session_date, 
    cs.time_slot, 
    cs.room_no, 
    sec.section_name, 
    cs.topic_covered,
    COUNT(a.attendance_id) AS attendance_logged
FROM class_sessions cs
JOIN sections sec ON cs.section_id = sec.section_id
LEFT JOIN attendance a ON a.session_id = cs.session_id
GROUP BY cs.session_id
LIMIT 5;
```

---

## 14. USER INTERFACE DESIGN

### 14.1 Interface Features
The web interface was engineered in accordance with Apple Human Interface Guidelines:
- **Clean Light Mode Aesthetic:** Neutral slate typography (`#1D1D1F`), high-contrast cards, and subtle border shadows.
- **Dynamic Island Feedback:** Floating pills communicating instantaneous database state changes upon CRUD execution.
- **Single-Touch Roll-Call Controls:** Four intuitive status pills (`Present`, `Absent`, `Late`, `Excused`) triggering asynchronous background updates.
- **Dedicated Database Tables Inspector:** Live tabular browser displaying raw schema records across all 12 relations.
- **Interactive SQL Scratchpad:** Integrated query executor with 1-click viva presets and formatted output tables.

### 14.2 Interface Screens

![Figure 3: Main Dashboard Overview](screenshots/01_dashboard_overview.png)
*Figure 3: Main Dashboard Overview showing KPI statistics, live database table badges, and shortage alerts*

![Figure 4: Student Management Screen](screenshots/02_students_crud_management.png)
*Figure 4: Student Management Screen with real-time section filtering and search*

![Figure 5: Live Attendance Roll-Call Screen](screenshots/03_live_attendance_sheet.png)
*Figure 5: Live Attendance Roll-Call Screen with single-touch status mutators*

![Figure 6: Database Tables Inspector Screen](screenshots/04_database_tables_inspector.png)
*Figure 6: Database Tables Inspector Screen displaying raw relational rows across all 12 tables*

![Figure 7: In-Browser Interactive SQL Console Screen](screenshots/05_interactive_sql_console.png)
*Figure 7: In-Browser Interactive SQL Console executing analytical queries with live tabular rendering*

---

## 15. CRUD / LIVE DATABASE DEMONSTRATION

A live demonstration of Create, Read, Update, and Delete operations was performed to verify that web interactions execute atomic database transactions:

### 15.1 Step 1 — Initial State
Before insertion, the student table contained 24 enrolled learners.

![Figure 11: Student List Before Insertion](screenshots/crud_step1_before_insert.png)
*Figure 11: Student List Before Insertion (Initial State — 24 Records)*

### 15.2 Step 2 — Insertion
A new student record was added via the web interface:
- **Roll Number:** `25WU0102999`
- **Full Name:** `Shaikh Humzah Demo`
- **Email:** `humzah.demo@woxsen.edu.in`
- **Section:** `AIML-A (Whales)`

![Figure 12a: Add Student Form Modal](screenshots/crud_modal_filled.png)
*Figure 12a: Add Student Form Modal populated with demonstration record*

![Figure 12b: Student List After Insertion](screenshots/crud_03_after_insert.svg)
*Figure 12b: Student List After Insertion showing 25th record highlighted*

### 15.3 Step 3 — Database Verification (After Insert)
The insertion was verified directly in the MySQL/SQLite database engine using the interactive CLI tool:

![Figure 13: Database Verification After Insertion](screenshots/cli_01_verify_insert.svg)
*Figure 13: Terminal Database Verification confirming student '25WU0102999' exists in the database*

### 15.4 Step 4 — Deletion
The demonstration record was removed using the web application's Delete button, triggering an Apple-style confirmation modal:

![Figure 14: Delete Confirmation Dialog](screenshots/crud_04_delete_modal.svg)
*Figure 14: Delete Confirmation Dialog before destructive record removal*

### 15.5 Step 5 — Database Verification (After Delete)
The deletion was confirmed in the database engine; querying for roll number `25WU0102999` returned an Empty Set, and total student count restored to baseline:

![Figure 15: Terminal Verification After Deletion](screenshots/cli_02_verify_delete.svg)
*Figure 15: Terminal Database Verification showing Empty Set and count restored to 24*

---

## 16. IMPLEMENTATION DETAILS

### 16.1 Final Database Statistics

| Relation / Table Name | Record Count | Functional Category |
| :--- | :--- | :--- |
| `departments` | 4 | Academic Organization |
| `faculty` | 8 | Teaching Instructors |
| `courses` | 6 | Curriculum Entities |
| `sections` | 6 | Cohorts & Class Divisions |
| `students` | 24 | Enrolled Learners |
| `class_sessions` | 15 | Timetabled Lectures |
| `attendance` | 156 | Session Roll-Call Logs |
| `leave_types` | 5 | Category Classifications |
| `leave_applications` | 16 | Formal Student Requests |
| `leave_approvals` | 12 | Faculty Decision Logs |
| `makeup_sessions` | 8 | Remedial Lecture Schedules |
| `shortage_alerts` | 10 | Debarment Warning Notices |
| **TOTAL DATABASE RECORDS** | **270** | **Comprehensive Institutional Dataset** |

### 16.2 Backend Implementation
The backend engine was constructed in Python using zero external third-party dependencies (`http.server`, `urllib.parse`, `sqlite3`, `json`). Parameterized queries protect every endpoint against SQL injection.

### 16.3 Frontend Implementation
The user interface was built using native HTML5 semantic tags, custom CSS variables for light-mode theming, and asynchronous `fetch()` API calls to enable instantaneous UI updates without full page reloads.

---

## 17. TESTING AND VALIDATION

Functional, relational, and negative constraint tests were executed across all system components:

| Test Case Identifier | Operation Tested | Expected Result | Actual Result Observed | Status |
| :--- | :--- | :--- | :--- | :--- |
| `TC-01` | Dashboard Statistics Load | Real-time counts across 12 tables fetched via REST | All 12 entity totals rendered correctly | **Pass** |
| `TC-02` | Student Record Retrieval | Complete student roster rendered with section pills | 24 records loaded with pagination | **Pass** |
| `TC-03` | Live Student Insertion | Record added via modal and written to database | Student #25 inserted with toast feedback | **Pass** |
| `TC-04` | Duplicate Roll No Enforcement | Database rejects duplicate `roll_no` | SQLite / MySQL raises `UNIQUE constraint failed` | **Pass** |
| `TC-05` | Student Deletion & Cascade | Record deleted and cascaded safely | Student removed; dependent records handled | **Pass** |
| `TC-06` | Touch Roll-Call Mutation | Status pill click triggers atomic UPSERT | Attendance updated from 'Present' to 'Late' | **Pass** |
| `TC-07` | Domain Check Constraint | Invalid status code rejected by engine | Attempt to insert 'Invalid' rejected by `CHECK` | **Pass** |
| `TC-08` | Leave Workflow Approval | Pending application reviewed and approved | Status transitioned from 'Pending' to 'Approved' | **Pass** |
| `TC-09` | Remedial Shortage Query | Mathematical formula identifies students < 75% | Correctly computed needed classes for CS301 | **Pass** |
| `TC-10` | Interactive SQL Terminal | Custom query executed and formatted in table | Result returned with timing in single box table | **Pass** |

---

## 18. CHALLENGES AND LIMITATIONS

### 18.1 Challenges Faced
- **Cascading Integrity vs. Archival History:** Deleting student records must cleanly remove dependent attendance records without leaving orphaned foreign keys in audit tables.
- **Composite Key Concurrency:** Enforcing `UNIQUE(session_id, student_id)` while allowing high-speed touch roll-call mutations required atomic UPSERT (`INSERT OR REPLACE` / `ON CONFLICT DO UPDATE`) logic.
- **Zero-Dependency Architecture:** Developing an interactive web server and single-table CLI using only the Python standard library required custom HTTP dispatchers and Unicode box table formatting routines.

### 18.2 Limitations
- **Biometric Integration:** Attendance is recorded via web roll calls; automated biometric hardware is not integrated in the current version.
- **SMS/Email Gateway:** Debarment alerts are generated within the database; automated SMS dispatch to parents is currently not enabled.
- **Single-Host Deployment:** The system is optimized for local institutional hosting rather than multi-region distributed cloud clustering.

---

## 19. CONCLUSION, FUTURE SCOPE AND REFERENCES

### 19.1 Conclusion
This project successfully designed, implemented, and validated a normalized Relational Database Management System for student attendance tracking and leave administration. By translating academic business rules into a 3NF relational schema across 12 tables and 270 records, the system resolves the inefficiencies, reconciliation delays, and data integrity vulnerabilities of conventional manual registers. The integration of an Apple Human Interface Guidelines light-mode web application and an interactive single-table SQL CLI demonstrates the practical application of database theory in building robust administrative tools.

### 19.2 Future Scope
- **Biometric & Facial Recognition:** Integration with classroom IoT cameras for automated contactless attendance.
- **Parent Communication Gateway:** Automated WhatsApp/SMS alerts when a student accumulates consecutive unexcused absences.
- **Predictive Analytics Engine:** Machine learning models forecasting semester debarment risk based on early-term attendance trajectories.
- **Mobile Application:** Dedicated iOS/Android applications for student leave submissions and medical slip uploads.

### 19.3 References
1. Silberschatz, A., Korth, H. F., & Sudarshan, S. *Database System Concepts* (7th ed.). McGraw-Hill Education.
2. Elmasri, R., & Navathe, S. B. *Fundamentals of Database Systems* (7th ed.). Pearson Education.
3. SQLite Documentation. *SQLite SQL Understanding and Query Optimization*. https://www.sqlite.org/docs.html
4. MySQL 8.0 Reference Manual. *Oracle Corporation*. https://dev.mysql.com/doc/
5. Apple Inc. *Human Interface Guidelines — Design Principles*. https://developer.apple.com/design/human-interface-guidelines/
6. MDN Web Docs. *RESTful APIs and Modern Web Technologies*. https://developer.mozilla.org/

---

## A. GITHUB APPENDIX

### Repository Structure
```text
humzah_dbms_26/
├── Presentation-I/
│   └── Presentation_I_Problem_Description.md
├── Presentation-II/
│   ├── Presentation_II_Slide_Deck.pdf
│   ├── Slide_Deck_Presentation_II.html
│   ├── ER_Diagram_Detailed.svg
│   ├── ER_Diagram_Specification.md
│   ├── student_attendance_system_mysql.sql
│   ├── Presentation_II_Queries_and_Solutions.md
│   └── run_query_cli.sh
├── Presentation-III/
│   ├── Presentation_III_Slide_Deck.pdf
│   ├── Slide_Deck_Presentation_III.html
│   ├── Presentation_III_UI_Demo_Guide.md
│   ├── UI_Screenshots_and_Flows.md
│   ├── run_demo.sh
│   └── screenshots/
├── Project-Report/
│   ├── Comprehensive_DBMS_Project_Report.md
│   ├── DBMS_Project_Report.html
│   ├── Shaikh_Humzah_25WU0102251_DBMS_Project_Report.pdf
│   ├── woxsen_logo.svg
│   └── screenshots/
│       ├── 01_dashboard_overview.png
│       ├── 02_students_crud_management.png
│       ├── 03_live_attendance_sheet.png
│       ├── 04_database_tables_inspector.png
│       ├── 05_interactive_sql_console.png
│       ├── crud_step1_before_insert.png
│       ├── crud_modal_filled.png
│       ├── crud_03_after_insert.svg
│       ├── crud_04_delete_modal.svg
│       ├── cli_01_verify_insert.svg
│       ├── cli_02_verify_delete.svg
│       └── cli_03_query1_shortage.svg
├── sql/
│   ├── 01_schema.sql
│   ├── 02_seed.sql
│   ├── 03_queries_and_views.sql
│   ├── 04_negative_tests.sql
│   └── mysql_schema.sql
├── docs/
│   ├── ER_DIAGRAM.md
│   ├── ER_Diagram_Detailed.svg
│   ├── NORMALIZATION_AND_FD.md
│   ├── DATA_DICTIONARY.md
│   └── VIVA_DEFENSE_MATRIX.md
├── app/
│   ├── database.py
│   ├── attendance_system.db
│   ├── server.py
│   └── static/
├── query_cli.py
├── demo_runner.py
├── test_system.py
├── run.py
└── README.md
```
The repository contains the complete relational schema DDL/DML scripts, the Python REST backend, the Apple-inspired web interface, the interactive query CLI tool, documentation proofs, and presentation decks for Presentations I, II, and III.
