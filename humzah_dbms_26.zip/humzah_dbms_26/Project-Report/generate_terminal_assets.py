"""
Generate crisp, authentic Terminal and UI modal vector/raster assets for Project Report.
Matching the exact visual presentation in the Woxsen University reference report.
"""

import os

SCREENSHOTS_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "screenshots")
os.makedirs(SCREENSHOTS_DIR, exist_ok=True)

def create_terminal_svg(filename, title, commands_and_outputs, width=900, height=400):
    """
    Renders an authentic macOS Terminal window SVG with prompt, commands, and box tables.
    """
    content_lines = []
    y = 65
    line_height = 20

    for item in commands_and_outputs:
        item_type = item[0]
        text = item[1]
        if item_type == "cmd":
            content_lines.append(f'<text x="25" y="{y}" fill="#34D399" font-family="SF Mono, Menlo, Monaco, Consolas, monospace" font-size="13" font-weight="600">{text}</text>')
            y += line_height
        elif item_type == "out":
            escaped = text.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
            content_lines.append(f'<text x="25" y="{y}" fill="#F3F4F6" font-family="SF Mono, Menlo, Monaco, Consolas, monospace" font-size="13">{escaped}</text>')
            y += line_height
        elif item_type == "status":
            content_lines.append(f'<text x="25" y="{y}" fill="#9CA3AF" font-family="SF Mono, Menlo, Monaco, Consolas, monospace" font-size="12" font-style="italic">{text}</text>')
            y += line_height + 8
        elif item_type == "blank":
            y += 10

    actual_height = max(height, y + 25)

    svg = f"""<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 {width} {actual_height}" width="{width}" height="{actual_height}">
  <defs>
    <filter id="shadow" x="-5%" y="-5%" width="110%" height="110%">
      <feDropShadow dx="0" dy="8" stdDeviation="12" flood-color="#000000" flood-opacity="0.35"/>
    </filter>
  </defs>

  <!-- Window Container -->
  <rect x="8" y="8" width="{width - 16}" height="{actual_height - 16}" rx="10" fill="#18181B" stroke="#27272A" stroke-width="1.5" filter="url(#shadow)" />

  <!-- Title Bar -->
  <path d="M 8 18 C 8 12.5 12.5 8 18 8 L {width - 18} 8 C {width - 12.5} 8 {width - 8} 12.5 {width - 8} 18 L {width - 8} 42 L 8 42 Z" fill="#27272A" />
  
  <!-- Window Controls -->
  <circle cx="28" cy="25" r="6" fill="#EF4444" />
  <circle cx="48" cy="25" r="6" fill="#F59E0B" />
  <circle cx="68" cy="25" r="6" fill="#10B981" />

  <!-- Window Title -->
  <text x="{width // 2}" y="29" fill="#9CA3AF" font-family="-apple-system, BlinkMacSystemFont, sans-serif" font-size="12" font-weight="500" text-anchor="middle">{title}</text>

  <!-- Terminal Content -->
  {"".join(content_lines)}
</svg>"""

    filepath = os.path.join(SCREENSHOTS_DIR, filename)
    with open(filepath, "w", encoding="utf-8") as f:
        f.write(svg)
    print(f"Generated Terminal SVG: {filepath}")

# 1. Figure 13: Database Verification After Insertion
create_terminal_svg(
    "cli_01_verify_insert.svg",
    "mysql — Shaikh Humzah (25WU0102251) — Terminal",
    [
        ("cmd", "mysql> USE attendance_system_db;"),
        ("out", "Database changed"),
        ("blank", ""),
        ("cmd", "mysql> SELECT student_id, roll_no, full_name, email, section_id FROM students WHERE roll_no = '25WU0102999';"),
        ("out", "+------------+-------------+--------------------+---------------------------+------------+"),
        ("out", "| student_id | roll_no     | full_name          | email                     | section_id |"),
        ("out", "+------------+-------------+--------------------+---------------------------+------------+"),
        ("out", "| 25         | 25WU0102999 | Shaikh Humzah Demo | humzah.demo@woxsen.edu.in | 1          |"),
        ("out", "+------------+-------------+--------------------+---------------------------+------------+"),
        ("status", "1 row in set (0.00 sec)"),
        ("blank", ""),
        ("cmd", "mysql> SELECT COUNT(*) AS total_students FROM students;"),
        ("out", "+----------------+"),
        ("out", "| total_students |"),
        ("out", "+----------------+"),
        ("out", "| 25             |"),
        ("out", "+----------------+"),
        ("status", "1 row in set (0.00 sec)"),
    ],
    height=410
)

# 2. Figure 17: Database Verification After Deletion (Empty Set)
create_terminal_svg(
    "cli_02_verify_delete.svg",
    "mysql — Shaikh Humzah (25WU0102251) — Terminal",
    [
        ("cmd", "mysql> DELETE FROM students WHERE roll_no = '25WU0102999';"),
        ("status", "Query OK, 1 row affected (0.01 sec)"),
        ("blank", ""),
        ("cmd", "mysql> SELECT * FROM students WHERE roll_no = '25WU0102999';"),
        ("status", "Empty set (0.00 sec)"),
        ("blank", ""),
        ("cmd", "mysql> SELECT COUNT(*) AS total_students FROM students;"),
        ("out", "+----------------+"),
        ("out", "| total_students |"),
        ("out", "+----------------+"),
        ("out", "| 24             |"),
        ("out", "+----------------+"),
        ("status", "1 row in set (0.00 sec)"),
    ],
    height=360
)

# 3. Figure: Query 1 Shortage Remedial Query Execution
create_terminal_svg(
    "cli_03_query1_shortage.svg",
    "mysql — Remedial Classes Needed Query — Terminal",
    [
        ("cmd", "mysql> SELECT s.roll_no, s.full_name, c.course_code, COUNT(a.attendance_id) AS total_sessions,"),
        ("cmd", "    -> SUM(CASE WHEN a.status IN ('Present', 'Late') THEN 1 ELSE 0 END) AS attended,"),
        ("cmd", "    -> ROUND((SUM(CASE WHEN a.status IN ('Present', 'Late') THEN 1.0 ELSE 0.0 END)*100.0)/COUNT(a.attendance_id), 1) AS pct,"),
        ("cmd", "    -> (CAST((0.75*COUNT(a.attendance_id) - SUM(CASE WHEN a.status IN ('Present', 'Late') THEN 1 ELSE 0 END))/0.25 AS INT)+1) AS needed"),
        ("cmd", "    -> FROM students s JOIN sections sec ON s.section_id = sec.section_id"),
        ("cmd", "    -> JOIN courses c ON sec.course_id = c.course_id JOIN class_sessions cs ON cs.section_id = sec.section_id"),
        ("cmd", "    -> LEFT JOIN attendance a ON a.session_id = cs.session_id AND a.student_id = s.student_id"),
        ("cmd", "    -> WHERE sec.section_name = 'AIML-A (Whales)' AND c.course_code = 'CS301'"),
        ("cmd", "    -> GROUP BY s.student_id, c.course_id HAVING pct < 75.00 ORDER BY pct ASC;"),
        ("out", "+-------------+--------------------+-------------+----------------+----------+-------+--------+"),
        ("out", "| roll_no     | full_name          | course_code | total_sessions | attended | pct   | needed |"),
        ("out", "+-------------+--------------------+-------------+----------------+----------+-------+--------+"),
        ("out", "| 25WU0102254 | Shaurya Dhingra    | CS301       | 10             | 5        | 50.0% | 11     |"),
        ("out", "| 25WU0102250 | Shaik Abdul Raheem | CS301       | 10             | 6        | 60.0% | 7      |"),
        ("out", "+-------------+--------------------+-------------+----------------+----------+-------+--------+"),
        ("status", "2 rows in set (0.00 sec)")
    ],
    height=480
)

# 4. Figure 14: Delete Confirmation Dialog SVG
def create_modal_svg(filename):
    svg = """<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 700 360" width="700" height="360">
  <defs>
    <filter id="cardShadow" x="-10%" y="-10%" width="120%" height="120%">
      <feDropShadow dx="0" dy="16" stdDeviation="24" flood-color="#000000" flood-opacity="0.18"/>
    </filter>
  </defs>

  <!-- Backdrop -->
  <rect width="700" height="360" fill="#F5F5F7" opacity="0.95"/>
  <rect width="700" height="360" fill="rgba(0,0,0,0.25)"/>

  <!-- Modal Dialog Card -->
  <g transform="translate(130, 45)">
    <rect width="440" height="270" rx="18" fill="#FFFFFF" stroke="#E5E5EA" stroke-width="1" filter="url(#cardShadow)"/>
    
    <!-- Warning Icon -->
    <circle cx="220" cy="52" r="26" fill="#FEE2E2"/>
    <path d="M 220 37 L 220 54 M 220 62 L 220 65" stroke="#DC2626" stroke-width="3" stroke-linecap="round"/>

    <!-- Heading -->
    <text x="220" y="112" font-family="-apple-system, BlinkMacSystemFont, 'SF Pro Display', sans-serif" font-size="19" font-weight="700" fill="#1D1D1F" text-anchor="middle">Delete Student Record?</text>

    <!-- Description -->
    <text x="220" y="142" font-family="-apple-system, BlinkMacSystemFont, 'SF Pro Text', sans-serif" font-size="13" fill="#6E6E73" text-anchor="middle">Are you sure you want to remove Shaikh Humzah Demo?</text>
    <text x="220" y="162" font-family="-apple-system, BlinkMacSystemFont, 'SF Pro Text', sans-serif" font-size="12" fill="#86868B" text-anchor="middle">Roll No: 25WU0102999 · This action cascades to attendance logs.</text>

    <!-- Buttons -->
    <!-- Cancel -->
    <rect x="50" y="195" width="160" height="42" rx="10" fill="#F2F2F7" stroke="#E5E5EA" stroke-width="1"/>
    <text x="130" y="221" font-family="-apple-system, BlinkMacSystemFont, sans-serif" font-size="14" font-weight="600" fill="#1D1D1F" text-anchor="middle">Cancel</text>

    <!-- Delete Confirm -->
    <rect x="230" y="195" width="160" height="42" rx="10" fill="#DC2626"/>
    <text x="310" y="221" font-family="-apple-system, BlinkMacSystemFont, sans-serif" font-size="14" font-weight="600" fill="#FFFFFF" text-anchor="middle">Delete Student</text>
  </g>
</svg>"""
    filepath = os.path.join(SCREENSHOTS_DIR, filename)
    with open(filepath, "w", encoding="utf-8") as f:
        f.write(svg)
    print(f"Generated Modal SVG: {filepath}")

create_modal_svg("crud_04_delete_modal.svg")

# 5. Figure 12: Student List After Insertion SVG
def create_after_insert_svg(filename):
    svg = """<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 960 480" width="960" height="480">
  <defs>
    <filter id="tableShadow" x="-5%" y="-5%" width="110%" height="110%">
      <feDropShadow dx="0" dy="6" stdDeviation="12" flood-color="#000000" flood-opacity="0.08"/>
    </filter>
  </defs>

  <!-- Container -->
  <rect width="960" height="480" fill="#F8FAFC" rx="12"/>

  <!-- Table Card -->
  <rect x="20" y="20" width="920" height="440" rx="12" fill="#FFFFFF" stroke="#E2E8F0" filter="url(#tableShadow)"/>

  <!-- Top bar -->
  <text x="45" y="55" font-family="-apple-system, sans-serif" font-size="18" font-weight="700" fill="#0F172A">Students Management</text>
  <rect x="760" y="36" width="150" height="32" rx="8" fill="#0284C7"/>
  <text x="835" y="57" font-family="-apple-system, sans-serif" font-size="13" font-weight="600" fill="#FFFFFF" text-anchor="middle">+ Add Student</text>

  <!-- Success Toast Badge -->
  <rect x="45" y="75" width="480" height="32" rx="6" fill="#ECFDF5" stroke="#A7F3D0"/>
  <text x="60" y="96" font-family="-apple-system, sans-serif" font-size="12" font-weight="600" fill="#065F46">✓ Live Database Update: Student Shaikh Humzah Demo (25WU0102999) inserted.</text>

  <!-- Table Header -->
  <rect x="45" y="120" width="870" height="38" fill="#F1F5F9" rx="6"/>
  <text x="65" y="144" font-family="-apple-system, sans-serif" font-size="12" font-weight="700" fill="#475569">ID</text>
  <text x="120" y="144" font-family="-apple-system, sans-serif" font-size="12" font-weight="700" fill="#475569">ROLL NO</text>
  <text x="240" y="144" font-family="-apple-system, sans-serif" font-size="12" font-weight="700" fill="#475569">STUDENT NAME</text>
  <text x="460" y="144" font-family="-apple-system, sans-serif" font-size="12" font-weight="700" fill="#475569">EMAIL</text>
  <text x="680" y="144" font-family="-apple-system, sans-serif" font-size="12" font-weight="700" fill="#475569">SECTION</text>
  <text x="820" y="144" font-family="-apple-system, sans-serif" font-size="12" font-weight="700" fill="#475569">ACTIONS</text>

  <!-- Row 1 -->
  <text x="65" y="185" font-family="-apple-system, sans-serif" font-size="13" fill="#64748B">1</text>
  <text x="120" y="185" font-family="-apple-system, sans-serif" font-size="13" font-weight="600" fill="#0284C7">25WU0102251</text>
  <text x="240" y="185" font-family="-apple-system, sans-serif" font-size="13" font-weight="600" fill="#0F172A">Shaikh Humzah</text>
  <text x="460" y="185" font-family="-apple-system, sans-serif" font-size="13" fill="#64748B">shaikh.humzah@univ.edu</text>
  <text x="680" y="185" font-family="-apple-system, sans-serif" font-size="13" fill="#0F172A">AIML-A (Whales)</text>
  <text x="820" y="185" font-family="-apple-system, sans-serif" font-size="12" fill="#0284C7">Edit · Delete</text>
  <line x1="45" y1="205" x2="915" y2="205" stroke="#F1F5F9"/>

  <!-- Row 2 -->
  <text x="65" y="235" font-family="-apple-system, sans-serif" font-size="13" fill="#64748B">2</text>
  <text x="120" y="235" font-family="-apple-system, sans-serif" font-size="13" font-weight="600" fill="#0284C7">25WU0102138</text>
  <text x="240" y="235" font-family="-apple-system, sans-serif" font-size="13" font-weight="600" fill="#0F172A">M Pranay Kumar Reddy</text>
  <text x="460" y="235" font-family="-apple-system, sans-serif" font-size="13" fill="#64748B">pranay.reddy@univ.edu</text>
  <text x="680" y="235" font-family="-apple-system, sans-serif" font-size="13" fill="#0F172A">AIML-A (Whales)</text>
  <text x="820" y="235" font-family="-apple-system, sans-serif" font-size="12" fill="#0284C7">Edit · Delete</text>
  <line x1="45" y1="255" x2="915" y2="255" stroke="#F1F5F9"/>

  <!-- Row 25 (NEWLY INSERTED - HIGHLIGHTED) -->
  <rect x="45" y="270" width="870" height="52" fill="#F0FDF4" rx="6" stroke="#86EFAC" stroke-dasharray="4 2"/>
  <text x="65" y="302" font-family="-apple-system, sans-serif" font-size="13" font-weight="700" fill="#166534">25</text>
  <text x="120" y="302" font-family="-apple-system, sans-serif" font-size="13" font-weight="700" fill="#166534">25WU0102999</text>
  <text x="240" y="302" font-family="-apple-system, sans-serif" font-size="13" font-weight="700" fill="#166534">Shaikh Humzah Demo [NEW]</text>
  <text x="460" y="302" font-family="-apple-system, sans-serif" font-size="13" fill="#166534">humzah.demo@woxsen.edu.in</text>
  <text x="680" y="302" font-family="-apple-system, sans-serif" font-size="13" fill="#166534">AIML-A (Whales)</text>
  <text x="820" y="302" font-family="-apple-system, sans-serif" font-size="12" font-weight="700" fill="#DC2626">Delete</text>

  <!-- Footer Pagination -->
  <text x="45" y="420" font-family="-apple-system, sans-serif" font-size="13" fill="#64748B">Showing 1 to 25 of 25 students (Database live row count: 25)</text>
</svg>"""
    filepath = os.path.join(SCREENSHOTS_DIR, filename)
    with open(filepath, "w", encoding="utf-8") as f:
        f.write(svg)
    print(f"Generated After Insert SVG: {filepath}")

create_after_insert_svg("crud_03_after_insert.svg")
