"""
Generate an exact, publication-grade HTML Project Report for Woxsen University.
Matching the visual styling, cover page, running header, tables, code boxes,
and embedded screenshots from the 30-page reference PDF.
"""

import os
import re

REPORT_MD_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), "Comprehensive_DBMS_Project_Report.md")
REPORT_HTML_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), "DBMS_Project_Report.html")
WOXSEN_LOGO_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), "woxsen_logo.svg")

def generate_report():
    with open(REPORT_MD_PATH, "r", encoding="utf-8") as f:
        md_text = f.read()

    # Read Woxsen logo SVG content for inlining
    with open(WOXSEN_LOGO_PATH, "r", encoding="utf-8") as f:
        logo_svg = f.read()

    # HTML Template
    html_output = f"""<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Woxsen University DBMS Project Report — Shaikh Humzah (25WU0102251)</title>
  <style>
    @page {{
      size: A4;
      margin: 22mm 18mm 20mm 18mm;
      @bottom-center {{
        content: counter(page);
        font-family: -apple-system, BlinkMacSystemFont, "Times New Roman", serif;
        font-size: 10pt;
        color: #4B5563;
      }}
    }}

    @media print {{
      body {{
        background: #FFFFFF !important;
        font-size: 11pt;
      }}
      .page-break {{
        page-break-before: always;
        break-before: page;
      }}
      .no-print {{
        display: none !important;
      }}
      .running-header {{
        position: fixed;
        top: -15mm;
        right: 0;
        display: flex;
        align-items: center;
        gap: 8px;
      }}
    }}

    * {{
      box-sizing: border-box;
    }}

    body {{
      font-family: "Times New Roman", Times, Georgia, serif;
      color: #111827;
      background: #E5E7EB;
      line-height: 1.6;
      margin: 0;
      padding: 40px 0;
    }}

    .report-sheet {{
      background: #FFFFFF;
      max-width: 860px;
      margin: 0 auto 30px auto;
      padding: 70px 65px;
      box-shadow: 0 4px 20px rgba(0, 0, 0, 0.08);
      position: relative;
    }}

    /* Print action floating bar */
    .print-bar {{
      position: fixed;
      bottom: 24px;
      right: 24px;
      background: #1F3864;
      color: #FFFFFF;
      padding: 12px 24px;
      border-radius: 30px;
      font-family: -apple-system, BlinkMacSystemFont, sans-serif;
      font-size: 14px;
      font-weight: 600;
      box-shadow: 0 8px 24px rgba(0, 0, 0, 0.25);
      cursor: pointer;
      display: flex;
      align-items: center;
      gap: 10px;
      z-index: 1000;
      transition: transform 0.2s, background 0.2s;
    }}
    .print-bar:hover {{
      background: #C8102E;
      transform: translateY(-2px);
    }}

    /* Cover Page */
    .cover-page {{
      text-align: center;
      min-height: 1000px;
      display: flex;
      flex-direction: column;
      justify-content: space-between;
      padding: 40px 20px 20px 20px;
    }}

    .cover-top-line {{
      width: 100%;
      height: 1px;
      background: #9CA3AF;
      margin-bottom: 30px;
    }}

    .cover-title-main {{
      font-size: 24pt;
      font-weight: bold;
      letter-spacing: 2px;
      color: #1F3864;
      margin-bottom: 24px;
      text-transform: uppercase;
    }}

    .cover-project-statement {{
      font-size: 15pt;
      font-weight: bold;
      line-height: 1.45;
      color: #111827;
      max-width: 680px;
      margin: 0 auto 40px auto;
    }}

    .cover-logo-wrap {{
      margin: 30px auto;
      max-width: 440px;
    }}
    .cover-logo-wrap svg {{
      width: 100%;
      height: auto;
    }}

    .cover-details-block {{
      font-size: 11pt;
      line-height: 2.1;
      text-align: center;
      margin: 40px auto;
      letter-spacing: 0.5px;
    }}
    .cover-details-block strong {{
      font-weight: bold;
      color: #111827;
    }}

    .cover-footer {{
      margin-top: 30px;
      text-align: center;
    }}
    .cover-footer-uni {{
      font-size: 14pt;
      font-weight: bold;
      letter-spacing: 2px;
      color: #1F3864;
    }}
    .cover-footer-school {{
      font-size: 11pt;
      color: #4B5563;
      margin-top: 4px;
    }}

    /* Running Header */
    .page-header {{
      display: flex;
      justify-content: flex-end;
      align-items: center;
      border-bottom: 1px solid #E5E7EB;
      padding-bottom: 10px;
      margin-bottom: 35px;
    }}
    .page-header-logo {{
      width: 130px;
      height: auto;
    }}

    /* Typography */
    h1.report-h1 {{
      font-size: 18pt;
      font-weight: bold;
      color: #1F3864;
      text-transform: uppercase;
      letter-spacing: 1px;
      margin-top: 0;
      margin-bottom: 20px;
      border-bottom: 2px solid #1F3864;
      padding-bottom: 6px;
    }}

    h2.report-h2 {{
      font-size: 14pt;
      font-weight: bold;
      color: #1F3864;
      margin-top: 32px;
      margin-bottom: 14px;
      letter-spacing: 0.5px;
    }}

    h3.report-h3 {{
      font-size: 12pt;
      font-weight: bold;
      color: #374151;
      margin-top: 24px;
      margin-bottom: 10px;
    }}

    p.report-p {{
      font-size: 11pt;
      line-height: 1.65;
      color: #1F2937;
      text-align: justify;
      margin-bottom: 14px;
      text-indent: 0;
    }}

    li.report-li {{
      font-size: 11pt;
      line-height: 1.6;
      color: #1F2937;
      margin-bottom: 8px;
    }}

    ul.report-ul {{
      margin-top: 8px;
      margin-bottom: 16px;
      padding-left: 24px;
    }}

    /* Tables */
    .report-table {{
      width: 100%;
      border-collapse: collapse;
      font-size: 10pt;
      margin: 20px 0 25px 0;
      background: #FFFFFF;
    }}
    .report-table th {{
      background: #1F3864;
      color: #FFFFFF;
      font-weight: bold;
      text-align: left;
      padding: 10px 12px;
      border: 1px solid #1F3864;
      letter-spacing: 0.3px;
    }}
    .report-table td {{
      padding: 9px 12px;
      border: 1px solid #E5E7EB;
      color: #1F2937;
      vertical-align: top;
    }}
    .report-table tr:nth-child(even) {{
      background: #F9FAFB;
    }}

    /* Code Blocks */
    pre.report-code {{
      background: #18181B;
      color: #F3F4F6;
      padding: 16px 20px;
      border-radius: 6px;
      overflow-x: auto;
      font-family: "SF Mono", Menlo, Monaco, Consolas, monospace;
      font-size: 9.5pt;
      line-height: 1.45;
      margin: 16px 0 22px 0;
      border: 1px solid #27272A;
    }}
    pre.report-code code {{
      background: transparent;
      color: inherit;
      padding: 0;
      font-size: inherit;
    }}

    code.inline-code {{
      background: #F3F4F6;
      color: #B91C1C;
      padding: 2px 5px;
      border-radius: 4px;
      font-family: monospace;
      font-size: 10pt;
    }}

    /* Figures & Screenshots */
    .figure-box {{
      margin: 24px 0 28px 0;
      text-align: center;
    }}
    .figure-img {{
      max-width: 100%;
      height: auto;
      border: 1px solid #E5E7EB;
      border-radius: 6px;
      box-shadow: 0 2px 10px rgba(0, 0, 0, 0.05);
    }}
    .figure-caption {{
      font-size: 10pt;
      font-style: italic;
      color: #4B5563;
      margin-top: 8px;
      text-align: center;
    }}

    /* Page Footer */
    .page-footer {{
      margin-top: 40px;
      border-top: 1px solid #E5E7EB;
      padding-top: 10px;
      display: flex;
      justify-content: center;
      font-size: 10pt;
      color: #6B7280;
    }}

    /* Table of contents styling */
    .toc-item {{
      display: flex;
      justify-content: space-between;
      margin-bottom: 7px;
      font-size: 11pt;
    }}
    .toc-dots {{
      flex: 1;
      border-bottom: 1px dotted #9CA3AF;
      margin: 0 8px 4px 8px;
    }}
    .toc-page {{
      font-weight: bold;
      color: #1F3864;
    }}
  </style>
</head>
<body>

  <!-- Floating Print Trigger -->
  <div class="print-bar no-print" onclick="window.print()">
    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
      <polyline points="6 9 6 2 18 2 18 9"></polyline>
      <path d="M6 18H4a2 2 0 0 1-2-2v-5a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2v5a2 2 0 0 1-2 2h-2"></path>
      <rect x="6" y="14" width="12" height="8"></rect>
    </svg>
    Save as PDF / Print
  </div>

  <!-- ==================== COVER PAGE ==================== -->
  <div class="report-sheet cover-page">
    <div>
      <div class="cover-top-line"></div>
      <div class="cover-title-main">PROJECT REPORT</div>
      <div class="cover-project-statement">
        Design and Implementation of a Database Management System for<br>
        Student Attendance and Leave Approval System
      </div>
    </div>

    <div class="cover-logo-wrap">
      {logo_svg}
    </div>

    <div class="cover-details-block">
      <strong>NAME:</strong> SHAIKH HUMZAH<br>
      <strong>ROLL NO:</strong> 25WU0102251<br>
      <strong>PROGRAM:</strong> B.Tech Artificial Intelligence and Machine Learning<br>
      <strong>COURSE NAME:</strong> DATABASE MANAGEMENT SYSTEMS<br>
      <strong>FACULTY NAME:</strong> Dr. Kiran Mayee Adavala<br>
      <strong>ACADEMIC YEAR:</strong> 2025 – 2029
    </div>

    <div class="cover-footer">
      <div class="cover-footer-uni">WOXSEN UNIVERSITY</div>
      <div class="cover-footer-school">School of Technology</div>
    </div>
  </div>
"""

    # Parse sections from Markdown
    sections = re.split(r'\n---\n', md_text)
    page_num = 2

    # Logo for running header
    header_html = f"""<div class="page-header">
      <div class="page-header-logo">{logo_svg}</div>
    </div>"""

    for sec in sections[1:]:
        sec = sec.strip()
        if not sec:
            continue

        # Format markdown elements inside section
        parsed_sec = []
        lines = sec.split("\n")
        in_table = False
        in_code = False
        in_ul = False
        code_lines = []

        for line in lines:
            line_str = line.strip()

            # Code blocks
            if line_str.startswith("```"):
                if in_code:
                    in_code = False
                    parsed_sec.append(f"<pre class='report-code'><code>{'<br>'.join(code_lines)}</code></pre>")
                    code_lines = []
                else:
                    in_code = True
                continue

            if in_code:
                code_lines.append(line.replace("<", "&lt;").replace(">", "&gt;"))
                continue

            # Tables
            if line_str.startswith("|") and line_str.endswith("|"):
                if "---" in line_str:
                    continue
                cols = [c.strip() for c in line.split("|")[1:-1]]
                if not in_table:
                    in_table = True
                    parsed_sec.append("<table class='report-table'><thead><tr>")
                    for c in cols:
                        parsed_sec.append(f"<th>{c}</th>")
                    parsed_sec.append("</tr></thead><tbody>")
                else:
                    parsed_sec.append("<tr>")
                    for c in cols:
                        parsed_sec.append(f"<td>{c}</td>")
                    parsed_sec.append("</tr>")
                continue
            else:
                if in_table:
                    in_table = False
                    parsed_sec.append("</tbody></table>")

            # Lists
            if line_str.startswith("- ") or line_str.startswith("* "):
                if not in_ul:
                    in_ul = True
                    parsed_sec.append("<ul class='report-ul'>")
                item_content = line_str[2:].strip()
                item_content = re.sub(r'\*\*(.*?)\*\*', r'<strong>\1</strong>', item_content)
                item_content = re.sub(r'`(.*?)`', r'<code class="inline-code">\1</code>', item_content)
                parsed_sec.append(f"<li class='report-li'>{item_content}</li>")
                continue
            else:
                if in_ul:
                    in_ul = False
                    parsed_sec.append("</ul>")

            # Images / Figures
            if line_str.startswith("!["):
                img_match = re.match(r'!\[(.*?)\]\((.*?)\)', line_str)
                if img_match:
                    alt_txt, src = img_match.groups()
                    parsed_sec.append(f"""<div class='figure-box'>
                      <img src='{src}' alt='{alt_txt}' class='figure-img' />
                      <div class='figure-caption'>{alt_txt}</div>
                    </div>""")
                continue

            # Headings
            if line_str.startswith("# "):
                parsed_sec.append(f"<h1 class='report-h1'>{line_str[2:].strip()}</h1>")
            elif line_str.startswith("## "):
                parsed_sec.append(f"<h2 class='report-h2'>{line_str[3:].strip()}</h2>")
            elif line_str.startswith("### "):
                parsed_sec.append(f"<h3 class='report-h3'>{line_str[4:].strip()}</h3>")
            elif line_str.startswith("*Figure") and line_str.endswith("*"):
                # Captions already processed
                continue
            elif line_str:
                p_text = line_str
                p_text = re.sub(r'\*\*(.*?)\*\*', r'<strong>\1</strong>', p_text)
                p_text = re.sub(r'`(.*?)`', r'<code class="inline-code">\1</code>', p_text)
                parsed_sec.append(f"<p class='report-p'>{p_text}</p>")

        if in_table:
            parsed_sec.append("</tbody></table>")
        if in_ul:
            parsed_sec.append("</ul>")

        sec_body = "\n".join(parsed_sec)

        # Append Page
        html_output += f"""
  <div class="report-sheet page-break">
    {header_html}
    {sec_body}
    <div class="page-footer">Page {page_num}</div>
  </div>
"""
        page_num += 1

    html_output += """
</body>
</html>
"""

    with open(REPORT_HTML_PATH, "w", encoding="utf-8") as f:
        f.write(html_output)
    print(f"Generated 30-Page Woxsen University Project Report: {REPORT_HTML_PATH}")

if __name__ == '__main__':
    generate_report()
