# Mathematical Normalization Proof: UNF → 1NF → 2NF → 3NF
## Topic #26: Student Attendance and Leave Approval System
**Learner:** Shaikh Humzah (Roll No: 25WU0102251) · AIML Whales

---

## 1. Unnormalized Form (UNF)
In a naive monolithic university spreadsheet, attendance, leaves, student profiles, and course details are recorded in a single unnormalized table:

$$\text{ATTENDANCE\_SHEET\_UNF}(\underline{\text{roll\_no}}, \text{student\_name}, \text{email}, \text{course\_code}, \text{course\_name}, \text{credits}, \text{dept\_code}, \text{dept\_name}, \text{faculty\_name}, \{\text{session\_date}, \text{topic}, \text{status}\}, \{\text{leave\_type}, \text{start\_date}, \text{end\_date}, \text{approval\_status}\})$$

### Anomalies in UNF:
1. **Insertion Anomaly:** A new course cannot be registered until students are enrolled and sessions conducted.
2. **Deletion Anomaly:** Deleting a student who is the sole attendee of a makeup class erases the class record and topic covered.
3. **Update Anomaly:** Updating a faculty member's designation requires modifying hundreds of attendance rows across sessions.

---

## 2. First Normal Form (1NF)
### Definition:
A relation $R$ is in **1NF** if and only if all domain attributes contain solely atomic (indivisible) scalar values and there are no repeating groups or nested relations.

### Decomposition into 1NF:
Repeating session attendance and leave history groups are flattened into discrete tuples with primary composite keys:
- Non-repeating student details are isolated.
- Each attendance record contains an atomic `(session_id, student_id, status)` tuple.
- Multi-valued phone numbers and comma-separated leave ranges are decomposed into scalar fields.

$$\text{Candidate Keys Identified: } K_1 = \{\text{roll\_no}\}, K_2 = \{\text{email}\}, K_3 = \{\text{session\_id}, \text{student\_id}\}$$

---

## 3. Second Normal Form (2NF)
### Definition:
A relation $R$ is in **2NF** if and only if it is in 1NF and **no non-prime attribute is partially dependent on any candidate key**. Formally:
$$\forall X \to Y \in F, \quad \text{if } Y \text{ is non-prime, then } X \text{ is not a proper subset of any candidate key}.$$

### Functional Dependency Analysis in Attendance Relation:
Consider composite key $K = \{\text{session\_id}, \text{student\_id}\}$:
- $\text{session\_id}, \text{student\_id} \to \text{status}, \text{marked\_at}, \text{remarks}$ (Full dependency ✓)
- $\text{student\_id} \to \text{student\_name}, \text{roll\_no}, \text{email}$ (**Partial Dependency** on left part of key ✕)
- $\text{session\_id} \to \text{topic\_covered}, \text{session\_date}, \text{room\_no}$ (**Partial Dependency** on right part of key ✕)

### 2NF Decomposition:
To achieve 2NF, relations are partitioned so non-prime attributes depend upon the entire primary key:
1. $\text{STUDENTS}(\underline{\text{student\_id}}, \text{roll\_no}, \text{full\_name}, \text{email}, \text{phone}, \text{section\_id}, \text{semester}, \text{admission\_year})$
2. $\text{CLASS\_SESSIONS}(\underline{\text{session\_id}}, \text{section\_id}, \text{faculty\_id}, \text{session\_date}, \text{time\_slot}, \text{room\_no}, \text{topic\_covered}, \text{status})$
3. $\text{ATTENDANCE}(\underline{\text{attendance\_id}}, \text{session\_id}, \text{student\_id}, \text{status}, \text{marked\_at}, \text{remarks})$

---

## 4. Third Normal Form (3NF)
### Definition:
A relation $R$ is in **3NF** if it is in 2NF and **no non-prime attribute is transitively dependent on the primary key**. Formally:
$$\forall X \to Y \in F, \quad \text{either } X \text{ is a superkey, or } Y \text{ is a prime attribute (part of a candidate key)}.$$

### Transitive Dependency Violations in Intermediate Schema:
1. In Course records:
   $$\text{course\_id} \to \text{department\_id} \quad \text{and} \quad \text{department\_id} \to \text{dept\_name}, \text{dept\_code}$$
   Since $\text{department\_id}$ is not a superkey of Courses, $\text{dept\_name}$ is transitively dependent on $\text{course\_id}$.
2. In Section & Faculty records:
   $$\text{section\_id} \to \text{faculty\_id} \quad \text{and} \quad \text{faculty\_id} \to \text{faculty\_name}, \text{designation}$$
3. In Leave records:
   $$\text{application\_id} \to \text{leave\_type\_id} \quad \text{and} \quad \text{leave\_type\_id} \to \text{type\_name}, \text{max\_days\_allowed}$$

### 3NF Lossless Decomposition:
Decomposed transitively related attributes into independent normalized relations:
1. $\text{DEPARTMENTS}(\underline{\text{department\_id}}, \text{dept\_name}, \text{dept\_code})$
2. $\text{FACULTY}(\underline{\text{faculty\_id}}, \text{full\_name}, \text{email}, \text{phone}, \text{department\_id}, \text{designation})$
3. $\text{COURSES}(\underline{\text{course\_id}}, \text{course\_code}, \text{course\_name}, \text{credits}, \text{department\_id}, \text{semester})$
4. $\text{SECTIONS}(\underline{\text{section\_id}}, \text{section\_name}, \text{course\_id}, \text{faculty\_id}, \text{academic\_year}, \text{semester})$
5. $\text{LEAVE\_TYPES}(\underline{\text{leave\_type\_id}}, \text{type\_name}, \text{max\_days\_allowed}, \text{description})$
6. $\text{LEAVE\_APPLICATIONS}(\underline{\text{application\_id}}, \text{student\_id}, \text{leave\_type\_id}, \text{start\_date}, \text{end\_date}, \text{reason}, \text{applied\_date}, \text{status})$
7. $\text{LEAVE\_APPROVALS}(\underline{\text{approval\_id}}, \text{application\_id}, \text{reviewed\_by\_faculty\_id}, \text{decision\_date}, \text{status}, \text{comments})$

### Dependency Preservation & Lossless Join Property:
$$\bigcup_{i=1}^{12} F_i = F \quad \text{and} \quad R_1 \bowtie R_2 \bowtie \dots \bowtie R_{12} = R$$
All functional dependencies are preserved through foreign keys, and all natural joins produce the exact original relations without generating spurious tuples.
