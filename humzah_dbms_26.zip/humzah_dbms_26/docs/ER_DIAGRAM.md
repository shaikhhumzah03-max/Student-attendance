# Complete Relational ER Diagram & Cardinality Analysis
## Topic #26: Student Attendance and Leave Approval System
**Learner:** Shaikh Humzah (Roll No: 25WU0102251) · AIML Whales
**Course:** Database Management Systems (CS301)

---

## 1. High-Resolution Vector ER Diagram
The system architecture consists of **12 normalized relations** organized to eliminate functional redundancies and enforce strict academic business rules:

![3NF Detailed Entity-Relationship Diagram](ER_Diagram_Detailed.svg)

---

## 2. Complete Mermaid ER Specification

```mermaid
erDiagram
    DEPARTMENTS ||--o{ FACULTY : employs
    DEPARTMENTS ||--o{ COURSES : offers
    FACULTY ||--o{ SECTIONS : instructs
    COURSES ||--o{ SECTIONS : divides_into
    SECTIONS ||--o{ STUDENTS : contains
    SECTIONS ||--o{ CLASS_SESSIONS : holds
    FACULTY ||--o{ CLASS_SESSIONS : conducts
    STUDENTS ||--o{ ATTENDANCE : logs
    CLASS_SESSIONS ||--o{ ATTENDANCE : records
    LEAVE_TYPES ||--o{ LEAVE_APPLICATIONS : categorizes
    STUDENTS ||--o{ LEAVE_APPLICATIONS : submits
    LEAVE_APPLICATIONS ||--o| LEAVE_APPROVALS : generates
    FACULTY ||--o{ LEAVE_APPROVALS : reviews
    CLASS_SESSIONS ||--o{ MAKEUP_SESSIONS : compensates
    SECTIONS ||--o{ MAKEUP_SESSIONS : schedules
    FACULTY ||--o{ MAKEUP_SESSIONS : leads
    STUDENTS ||--o{ SHORTAGE_ALERTS : incurs
    COURSES ||--o{ SHORTAGE_ALERTS : monitors

    DEPARTMENTS {
        int department_id PK
        string dept_name UK
        string dept_code UK
    }

    FACULTY {
        int faculty_id PK
        string full_name
        string email UK
        string phone
        int department_id FK
        string designation
    }

    COURSES {
        int course_id PK
        string course_code UK
        string course_name
        int credits
        int department_id FK
        int semester
    }

    SECTIONS {
        int section_id PK
        string section_name
        int course_id FK
        int faculty_id FK
        string academic_year
        int semester
    }

    STUDENTS {
        int student_id PK
        string roll_no UK
        string full_name
        string email UK
        string phone
        int section_id FK
        int semester
        int admission_year
    }

    CLASS_SESSIONS {
        int session_id PK
        int section_id FK
        int faculty_id FK
        date session_date
        string time_slot
        string room_no
        string topic_covered
        string status
    }

    ATTENDANCE {
        int attendance_id PK
        int session_id FK
        int student_id FK
        string status
        timestamp marked_at
        string remarks
    }

    LEAVE_TYPES {
        int leave_type_id PK
        string type_name UK
        int max_days_allowed
        string description
    }

    LEAVE_APPLICATIONS {
        int application_id PK
        int student_id FK
        int leave_type_id FK
        date start_date
        date end_date
        string reason
        date applied_date
        string status
    }

    LEAVE_APPROVALS {
        int approval_id PK
        int application_id FK
        int reviewed_by_faculty_id FK
        date decision_date
        string status
        string comments
    }

    MAKEUP_SESSIONS {
        int makeup_id PK
        int original_session_id FK
        int section_id FK
        int faculty_id FK
        date scheduled_date
        string time_slot
        string reason
        string status
    }

    SHORTAGE_ALERTS {
        int alert_id PK
        int student_id FK
        int course_id FK
        float attendance_percentage
        string alert_level
        date generated_date
        int is_resolved
    }
```

---

## 3. Structural Cardinality Matrix

| Parent Entity | Relationship Verb | Child Entity | Cardinality | Business Rule Enforced |
|---|---|---|---|---|
| `DEPARTMENTS` | Employs | `FACULTY` | $1 : N$ | Every faculty belongs to exactly one department. |
| `DEPARTMENTS` | Offers | `COURSES` | $1 : N$ | Courses originate from an owning department. |
| `COURSES` | Partitioned Into | `SECTIONS` | $1 : N$ | Courses have separate sections (Whales, Panthers). |
| `FACULTY` | Coordinates | `SECTIONS` | $1 : N$ | Each section is assigned an instructor. |
| `SECTIONS` | Enrolls | `STUDENTS` | $1 : N$ | Students belong to exactly one section. |
| `SECTIONS` | Schedules | `CLASS_SESSIONS` | $1 : N$ | Class timetable is maintained per section. |
| `CLASS_SESSIONS` & `STUDENTS` | Intersection | `ATTENDANCE` | $M : N$ | Associative entity enforcing `UNIQUE(session, student)`. |
| `STUDENTS` | Submits | `LEAVE_APPLICATIONS`| $1 : N$ | Students file leave requests with date bounds. |
| `LEAVE_APPLICATIONS`| Audited By | `LEAVE_APPROVALS` | $1 : 1$ | Each application receives at most one faculty approval log. |
| `CLASS_SESSIONS` | Compensated By| `MAKEUP_SESSIONS` | $0..1 : N$ | Canceled lectures link to makeup session slots. |
| `STUDENTS` | Incurs | `SHORTAGE_ALERTS` | $1 : N$ | Automatic system alerts generated when attendance $< 75\%$. |
