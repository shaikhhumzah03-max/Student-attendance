# 12-Table Comprehensive Relational Data Dictionary
## Topic #26: Student Attendance and Leave Approval System
**Learner:** Shaikh Humzah (Roll No: 25WU0102251) · AIML Whales

---

### 1. Table: `departments`
Stores academic departments offering degrees and allocating instructors.
| Column | Type | Constraints | Description |
|---|---|---|---|
| `department_id` | INT | PRIMARY KEY, AUTO_INCREMENT | Unique surrogate department identifier |
| `dept_name` | VARCHAR(100) | NOT NULL, UNIQUE | Full formal name (e.g., Computer Science & Engineering) |
| `dept_code` | VARCHAR(20) | NOT NULL, UNIQUE | Standard abbreviation (e.g., CSE, AIML, DSE) |

---

### 2. Table: `faculty`
Maintains profile of professors, associate professors, and department heads.
| Column | Type | Constraints | Description |
|---|---|---|---|
| `faculty_id` | INT | PRIMARY KEY, AUTO_INCREMENT | Unique faculty identifier |
| `full_name` | VARCHAR(100) | NOT NULL | Academician full legal name |
| `email` | VARCHAR(100) | NOT NULL, UNIQUE | Official university email |
| `phone` | VARCHAR(25) | NULLABLE | Contact telephone |
| `department_id` | INT | NOT NULL, FOREIGN KEY | References `departments(department_id)` [RESTRICT] |
| `designation` | VARCHAR(60) | NOT NULL | Rank (Professor & HOD, Associate Professor) |

---

### 3. Table: `courses`
Academic courses with assigned credits and semester numbers.
| Column | Type | Constraints | Description |
|---|---|---|---|
| `course_id` | INT | PRIMARY KEY, AUTO_INCREMENT | Unique course identifier |
| `course_code` | VARCHAR(20) | NOT NULL, UNIQUE | Curriculum code (CS301, AI302) |
| `course_name` | VARCHAR(120) | NOT NULL | Course title |
| `credits` | INT | NOT NULL, CHECK (credits > 0) | Academic credits allocated |
| `department_id` | INT | NOT NULL, FOREIGN KEY | References `departments(department_id)` [RESTRICT] |
| `semester` | INT | NOT NULL, CHECK (1 TO 8) | Academic semester |

---

### 4. Table: `sections`
Institutional sections grouping students per course and instructor.
| Column | Type | Constraints | Description |
|---|---|---|---|
| `section_id` | INT | PRIMARY KEY, AUTO_INCREMENT | Unique section identifier |
| `section_name` | VARCHAR(60) | NOT NULL | Cohort label (AIML-A Whales, AIML-B Panthers) |
| `course_id` | INT | NOT NULL, FOREIGN KEY | References `courses(course_id)` [CASCADE] |
| `faculty_id` | INT | NOT NULL, FOREIGN KEY | References `faculty(faculty_id)` [RESTRICT] |
| `academic_year`| VARCHAR(20) | NOT NULL | Academic year (e.g. 2025-2026) |
| `semester` | INT | NOT NULL | Semester number |

---

### 5. Table: `students`
Student demographic and enrollment records.
| Column | Type | Constraints | Description |
|---|---|---|---|
| `student_id` | INT | PRIMARY KEY, AUTO_INCREMENT | Unique internal student ID |
| `roll_no` | VARCHAR(30) | NOT NULL, UNIQUE | University roll number (e.g., 25WU0102251) |
| `full_name` | VARCHAR(100) | NOT NULL | Enrolled student name |
| `email` | VARCHAR(100) | NOT NULL, UNIQUE | Institutional email |
| `phone` | VARCHAR(25) | NULLABLE | Phone number |
| `section_id` | INT | NOT NULL, FOREIGN KEY | References `sections(section_id)` [RESTRICT] |
| `semester` | INT | NOT NULL | Current semester |
| `admission_year`| INT | NOT NULL | Year of university admission |

---

### 6. Table: `class_sessions`
Lectures, lab hours, and reviews conducted by faculty.
| Column | Type | Constraints | Description |
|---|---|---|---|
| `session_id` | INT | PRIMARY KEY, AUTO_INCREMENT | Unique class session identifier |
| `section_id` | INT | NOT NULL, FOREIGN KEY | References `sections(section_id)` [CASCADE] |
| `faculty_id` | INT | NOT NULL, FOREIGN KEY | References `faculty(faculty_id)` [RESTRICT] |
| `session_date` | DATE | NOT NULL | Date of class delivery |
| `time_slot` | VARCHAR(40) | NOT NULL | Timing (e.g. 09:00 - 10:00 AM) |
| `room_no` | VARCHAR(30) | NOT NULL | Hall / Lab number (e.g. LH-201) |
| `topic_covered`| VARCHAR(200) | NOT NULL | Academic topic taught |
| `status` | ENUM/TEXT | DEFAULT 'Conducted' | 'Conducted', 'Scheduled', 'Cancelled' |

---

### 7. Table: `attendance`
Associative relation recording individual student attendance per session.
| Column | Type | Constraints | Description |
|---|---|---|---|
| `attendance_id`| INT | PRIMARY KEY, AUTO_INCREMENT | Attendance surrogate key |
| `session_id` | INT | NOT NULL, FOREIGN KEY | References `class_sessions(session_id)` [CASCADE] |
| `student_id` | INT | NOT NULL, FOREIGN KEY | References `students(student_id)` [CASCADE] |
| `status` | ENUM/TEXT | NOT NULL, CHECK (...) | 'Present', 'Absent', 'Late', 'Excused' |
| `marked_at` | TIMESTAMP | DEFAULT CURRENT_TIMESTAMP | Time timestamp of roll call |
| `remarks` | VARCHAR(255) | NULLABLE | Optional observation note |
| **COMPOSITE** | (session, student)| UNIQUE | Prevents duplicate student marking per session |

---

### 8. Table: `leave_types`
Classification of permitted leaves with quota ceilings.
| Column | Type | Constraints | Description |
|---|---|---|---|
| `leave_type_id`| INT | PRIMARY KEY, AUTO_INCREMENT | Leave category ID |
| `type_name` | VARCHAR(60) | NOT NULL, UNIQUE | 'Medical', 'Academic/Conference', 'OD' |
| `max_days_allowed`| INT | NOT NULL, CHECK (> 0) | Upper quota ceiling |
| `description` | VARCHAR(255) | NULLABLE | Terms of eligibility |

---

### 9. Table: `leave_applications`
Student leave requests requiring authorization.
| Column | Type | Constraints | Description |
|---|---|---|---|
| `application_id`| INT | PRIMARY KEY, AUTO_INCREMENT| Unique request ID |
| `student_id` | INT | NOT NULL, FOREIGN KEY | References `students(student_id)` [CASCADE] |
| `leave_type_id`| INT | NOT NULL, FOREIGN KEY | References `leave_types(leave_type_id)` [RESTRICT] |
| `start_date` | DATE | NOT NULL | Leave begin date |
| `end_date` | DATE | NOT NULL, CHECK (>= start)| Leave conclusion date |
| `reason` | TEXT | NOT NULL | Formal explanation |
| `applied_date` | DATE | NOT NULL | Date filed |
| `status` | ENUM/TEXT | DEFAULT 'Pending' | 'Pending', 'Approved', 'Rejected' |

---

### 10. Table: `leave_approvals`
Transactional faculty review decision logs.
| Column | Type | Constraints | Description |
|---|---|---|---|
| `approval_id` | INT | PRIMARY KEY, AUTO_INCREMENT| Unique decision log ID |
| `application_id`| INT | NOT NULL, UNIQUE, FOREIGN KEY| References `leave_applications` [CASCADE] |
| `reviewed_by_faculty_id`| INT | NOT NULL, FOREIGN KEY | References `faculty(faculty_id)` [RESTRICT] |
| `decision_date`| DATE | NOT NULL | Date decision executed |
| `status` | ENUM/TEXT | NOT NULL | 'Approved', 'Rejected' |
| `comments` | VARCHAR(255) | NULLABLE | Reviewer feedback remarks |

---

### 11. Table: `makeup_sessions`
Compensatory lecture sessions scheduled for students or missed lectures.
| Column | Type | Constraints | Description |
|---|---|---|---|
| `makeup_id` | INT | PRIMARY KEY, AUTO_INCREMENT| Makeup identifier |
| `original_session_id`| INT | NULLABLE, FOREIGN KEY | References `class_sessions(session_id)` [SET NULL]|
| `section_id` | INT | NOT NULL, FOREIGN KEY | References `sections(section_id)` [CASCADE] |
| `faculty_id` | INT | NOT NULL, FOREIGN KEY | References `faculty(faculty_id)` [RESTRICT] |
| `scheduled_date`| DATE | NOT NULL | Scheduled makeup date |
| `time_slot` | VARCHAR(40) | NOT NULL | Time window |
| `reason` | VARCHAR(255) | NOT NULL | Justification for makeup |
| `status` | ENUM/TEXT | DEFAULT 'Scheduled' | 'Scheduled', 'Completed', 'Cancelled' |

---

### 12. Table: `shortage_alerts`
System-generated alerts for students whose attendance drops below 75%.
| Column | Type | Constraints | Description |
|---|---|---|---|
| `alert_id` | INT | PRIMARY KEY, AUTO_INCREMENT| Unique alert ticket |
| `student_id` | INT | NOT NULL, FOREIGN KEY | References `students(student_id)` [CASCADE] |
| `course_id` | INT | NOT NULL, FOREIGN KEY | References `courses(course_id)` [CASCADE] |
| `attendance_percentage`| DECIMAL(5,2)| CHECK (BETWEEN 0 AND 100)| Computed cumulative percentage |
| `alert_level` | ENUM/TEXT | NOT NULL | 'Warning' (<75%), 'Critical' (<65%), 'Debarred' |
| `generated_date`| DATE | NOT NULL | Timestamp of audit trigger |
| `is_resolved` | TINYINT(1) | DEFAULT 0, CHECK (IN 0,1) | 0 = Active, 1 = Resolved |
