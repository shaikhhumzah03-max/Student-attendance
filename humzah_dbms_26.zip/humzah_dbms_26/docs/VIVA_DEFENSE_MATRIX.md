# Viva Voce Defense Matrix: Tactical Answers for Evaluator Questions
## Topic #26: Student Attendance and Leave Approval System
**Learner:** Shaikh Humzah (Roll No: 25WU0102251) · AIML Whales

---

### Q1: "Why did you use a separate `attendance` table instead of an array or JSON column in `students` or `class_sessions`?"
> **Tactical Defense:**  
> *"Storing attendance as an array or JSON inside `students` violates First Normal Form (1NF), which requires all attributes to be atomic scalar values. Furthermore, query performance on aggregations like `COUNT()` and `SUM()` across millions of sessions would degrade into full-table unindexed deserialization scans. By modeling `attendance` as a dedicated associative relation with foreign keys to both `class_sessions` and `students`, we achieve 3NF compliance, enforce index-accelerated `UNIQUE(session_id, student_id)` composite constraints, and support atomic row-level locking during live roll-call operations."*

---

### Q2: "What happens if an instructor tries to mark attendance for the same student twice in the same lecture?"
> **Tactical Defense:**  
> *"The schema enforces a strict composite candidate key constraint: `CONSTRAINT uq_session_student UNIQUE (session_id, student_id)`. If an insert is attempted with an existing pair, the relational engine immediately rejects the transaction with a unique constraint violation error. In our application layer, we handle this through an idempotent `UPSERT` (`ON CONFLICT(session_id, student_id) DO UPDATE SET status = excluded.status`), which allows the faculty member to correct an accidental mark from Absent to Present without corrupting row counts."*

---

### Q3: "How does your system prevent students from submitting a leave application where the end date is earlier than the start date?"
> **Tactical Defense:**  
> *"At the database level, we enforce a domain check constraint: `CONSTRAINT chk_leave_dates CHECK (end_date >= start_date)` directly on the `leave_applications` table. In MySQL, we also implement a `BEFORE INSERT` trigger (`trg_validate_leave_duration`) that cross-references `leave_types.max_days_allowed` and raises a `SIGNAL SQLSTATE '45000'` if the requested duration exceeds the statutory quota for that leave category."*

---

### Q4: "Show me where 3NF is demonstrated versus 2NF in your database."
> **Tactical Defense:**  
> *"In 2NF, all non-key attributes are fully functionally dependent on the primary key, eliminating partial dependencies. However, transitive dependencies could still exist. For example, if we kept `dept_name` and `dept_code` inside the `courses` table, we would have $\text{course\_id} \to \text{department\_id}$ and $\text{department\_id} \to \text{dept\_name}$. Since `department_id` is not a superkey of Courses, this is a transitive dependency that would cause update anomalies. We decomposed this into a dedicated `departments` relation, ensuring every determinant is a candidate key, thereby satisfying 3NF."*

---

### Q5: "If a class session is cancelled, what happens to the attendance and makeup records?"
> **Tactical Defense:**  
> *"For `attendance`, referential integrity is governed by `ON DELETE CASCADE`: if a class session is purged, its corresponding attendance logs cascade cleanly to prevent orphaned foreign keys. For compensatory sessions in `makeup_sessions`, we configured `original_session_id INT NULL` with `ON DELETE SET NULL`. This ensures the scheduled makeup lecture remains on the institutional timetable even if the historical canceled session record is removed."*

---

### Q6: "How do you calculate attendance percentage and identify shortages in real time?"
> **Tactical Defense:**  
> *"We avoid storing a static `attendance_percentage` column on the student table because derived attributes introduce synchronization anomalies. Instead, we compute percentages dynamically through the view `v_student_attendance_summary` using SQL aggregation:  
> `ROUND((SUM(CASE WHEN status IN ('Present', 'Late') THEN 1.0 ELSE 0.0 END) * 100.0) / COUNT(attendance_id), 2)`.  
> For alerts, our system runs an automated audit query with `HAVING attendance_percentage < 75.00`, categorizing students into Warning ($65\%\text{--}74\%$), Critical ($50\%\text{--}64\%$), and Debarred ($< 50\%$) tiers."*

---

### Q7: "How is data integrity guaranteed during faculty leave approval?"
> **Tactical Defense:**  
> *"The approval action is executed inside an atomic transaction. When a faculty member clicks 'Approve', two statements execute within a single unit of work: first, `UPDATE leave_applications SET status = 'Approved'`, and second, `INSERT INTO leave_approvals (application_id, reviewed_by_faculty_id, decision_date, status, comments)`. If either operation fails, the transaction is rolled back completely, guaranteeing the ACID atomicity and consistency properties."*
