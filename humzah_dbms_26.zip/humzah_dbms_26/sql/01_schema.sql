-- ==============================================================================
-- 01_schema.sql : Relational Schema DDL (3NF Normalized)
-- Project #26: Student Attendance and Leave Approval System
-- Learner: Shaikh Humzah (Roll No: 25WU0102251) - AIML Whales
-- ==============================================================================

PRAGMA foreign_keys = ON;

-- 1. Departments
CREATE TABLE IF NOT EXISTS departments (
    department_id INTEGER PRIMARY KEY AUTOINCREMENT,
    dept_name TEXT NOT NULL UNIQUE,
    dept_code TEXT NOT NULL UNIQUE
);

-- 2. Faculty
CREATE TABLE IF NOT EXISTS faculty (
    faculty_id INTEGER PRIMARY KEY AUTOINCREMENT,
    full_name TEXT NOT NULL,
    email TEXT NOT NULL UNIQUE,
    phone TEXT,
    department_id INTEGER NOT NULL,
    designation TEXT NOT NULL,
    FOREIGN KEY (department_id) REFERENCES departments(department_id) ON DELETE RESTRICT
);

-- 3. Courses
CREATE TABLE IF NOT EXISTS courses (
    course_id INTEGER PRIMARY KEY AUTOINCREMENT,
    course_code TEXT NOT NULL UNIQUE,
    course_name TEXT NOT NULL,
    credits INTEGER NOT NULL CHECK (credits > 0),
    department_id INTEGER NOT NULL,
    semester INTEGER NOT NULL CHECK (semester BETWEEN 1 AND 8),
    FOREIGN KEY (department_id) REFERENCES departments(department_id) ON DELETE RESTRICT
);

-- 4. Sections
CREATE TABLE IF NOT EXISTS sections (
    section_id INTEGER PRIMARY KEY AUTOINCREMENT,
    section_name TEXT NOT NULL,
    course_id INTEGER NOT NULL,
    faculty_id INTEGER NOT NULL,
    academic_year TEXT NOT NULL,
    semester INTEGER NOT NULL,
    FOREIGN KEY (course_id) REFERENCES courses(course_id) ON DELETE CASCADE,
    FOREIGN KEY (faculty_id) REFERENCES faculty(faculty_id) ON DELETE RESTRICT
);

-- 5. Students
CREATE TABLE IF NOT EXISTS students (
    student_id INTEGER PRIMARY KEY AUTOINCREMENT,
    roll_no TEXT NOT NULL UNIQUE,
    full_name TEXT NOT NULL,
    email TEXT NOT NULL UNIQUE,
    phone TEXT,
    section_id INTEGER NOT NULL,
    semester INTEGER NOT NULL,
    admission_year INTEGER NOT NULL,
    FOREIGN KEY (section_id) REFERENCES sections(section_id) ON DELETE RESTRICT
);

-- 6. Class Sessions
CREATE TABLE IF NOT EXISTS class_sessions (
    session_id INTEGER PRIMARY KEY AUTOINCREMENT,
    section_id INTEGER NOT NULL,
    faculty_id INTEGER NOT NULL,
    session_date DATE NOT NULL,
    time_slot TEXT NOT NULL,
    room_no TEXT NOT NULL,
    topic_covered TEXT NOT NULL,
    status TEXT NOT NULL DEFAULT 'Conducted' CHECK (status IN ('Conducted', 'Scheduled', 'Cancelled')),
    FOREIGN KEY (section_id) REFERENCES sections(section_id) ON DELETE CASCADE,
    FOREIGN KEY (faculty_id) REFERENCES faculty(faculty_id) ON DELETE RESTRICT
);

-- 7. Attendance
CREATE TABLE IF NOT EXISTS attendance (
    attendance_id INTEGER PRIMARY KEY AUTOINCREMENT,
    session_id INTEGER NOT NULL,
    student_id INTEGER NOT NULL,
    status TEXT NOT NULL CHECK (status IN ('Present', 'Absent', 'Late', 'Excused')),
    marked_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    remarks TEXT,
    UNIQUE(session_id, student_id),
    FOREIGN KEY (session_id) REFERENCES class_sessions(session_id) ON DELETE CASCADE,
    FOREIGN KEY (student_id) REFERENCES students(student_id) ON DELETE CASCADE
);

-- 8. Leave Types
CREATE TABLE IF NOT EXISTS leave_types (
    leave_type_id INTEGER PRIMARY KEY AUTOINCREMENT,
    type_name TEXT NOT NULL UNIQUE,
    max_days_allowed INTEGER NOT NULL CHECK (max_days_allowed > 0),
    description TEXT
);

-- 9. Leave Applications
CREATE TABLE IF NOT EXISTS leave_applications (
    application_id INTEGER PRIMARY KEY AUTOINCREMENT,
    student_id INTEGER NOT NULL,
    leave_type_id INTEGER NOT NULL,
    start_date DATE NOT NULL,
    end_date DATE NOT NULL CHECK (end_date >= start_date),
    reason TEXT NOT NULL,
    applied_date DATE NOT NULL,
    status TEXT NOT NULL DEFAULT 'Pending' CHECK (status IN ('Pending', 'Approved', 'Rejected')),
    FOREIGN KEY (student_id) REFERENCES students(student_id) ON DELETE CASCADE,
    FOREIGN KEY (leave_type_id) REFERENCES leave_types(leave_type_id) ON DELETE RESTRICT
);

-- 10. Leave Approvals
CREATE TABLE IF NOT EXISTS leave_approvals (
    approval_id INTEGER PRIMARY KEY AUTOINCREMENT,
    application_id INTEGER NOT NULL UNIQUE,
    reviewed_by_faculty_id INTEGER NOT NULL,
    decision_date DATE NOT NULL,
    status TEXT NOT NULL CHECK (status IN ('Approved', 'Rejected')),
    comments TEXT,
    FOREIGN KEY (application_id) REFERENCES leave_applications(application_id) ON DELETE CASCADE,
    FOREIGN KEY (reviewed_by_faculty_id) REFERENCES faculty(faculty_id) ON DELETE RESTRICT
);

-- 11. Makeup Sessions
CREATE TABLE IF NOT EXISTS makeup_sessions (
    makeup_id INTEGER PRIMARY KEY AUTOINCREMENT,
    original_session_id INTEGER,
    section_id INTEGER NOT NULL,
    faculty_id INTEGER NOT NULL,
    scheduled_date DATE NOT NULL,
    time_slot TEXT NOT NULL,
    reason TEXT NOT NULL,
    status TEXT NOT NULL DEFAULT 'Scheduled' CHECK (status IN ('Scheduled', 'Completed', 'Cancelled')),
    FOREIGN KEY (original_session_id) REFERENCES class_sessions(session_id) ON DELETE SET NULL,
    FOREIGN KEY (section_id) REFERENCES sections(section_id) ON DELETE CASCADE,
    FOREIGN KEY (faculty_id) REFERENCES faculty(faculty_id) ON DELETE RESTRICT
);

-- 12. Shortage Alerts
CREATE TABLE IF NOT EXISTS shortage_alerts (
    alert_id INTEGER PRIMARY KEY AUTOINCREMENT,
    student_id INTEGER NOT NULL,
    course_id INTEGER NOT NULL,
    attendance_percentage REAL NOT NULL CHECK (attendance_percentage BETWEEN 0 AND 100),
    alert_level TEXT NOT NULL CHECK (alert_level IN ('Warning', 'Critical', 'Debarred')),
    generated_date DATE NOT NULL,
    is_resolved INTEGER NOT NULL DEFAULT 0 CHECK (is_resolved IN (0, 1)),
    FOREIGN KEY (student_id) REFERENCES students(student_id) ON DELETE CASCADE,
    FOREIGN KEY (course_id) REFERENCES courses(course_id) ON DELETE CASCADE
);

-- Indexes for performance
CREATE INDEX IF NOT EXISTS idx_student_roll ON students(roll_no);
CREATE INDEX IF NOT EXISTS idx_session_date ON class_sessions(session_date);
CREATE INDEX IF NOT EXISTS idx_attendance_status ON attendance(status);
CREATE INDEX IF NOT EXISTS idx_leave_status ON leave_applications(status);
