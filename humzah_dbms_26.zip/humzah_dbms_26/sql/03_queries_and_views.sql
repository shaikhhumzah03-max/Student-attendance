-- ==============================================================================
-- 03_queries_and_views.sql : 7 Analytical Reports & Operational Views
-- Project #26: Student Attendance and Leave Approval System
-- Learner: Shaikh Humzah (Roll No: 25WU0102251) - AIML Whales
-- ==============================================================================

-- -----------------------------------------------------------------------------
-- VIEW 1: Comprehensive Student Attendance Summary
-- -----------------------------------------------------------------------------
CREATE VIEW IF NOT EXISTS v_student_attendance_summary AS
SELECT 
    s.student_id,
    s.roll_no,
    s.full_name,
    sec.section_name,
    c.course_code,
    c.course_name,
    COUNT(a.attendance_id) AS total_sessions,
    SUM(CASE WHEN a.status IN ('Present', 'Late') THEN 1 ELSE 0 END) AS attended_sessions,
    SUM(CASE WHEN a.status = 'Absent' THEN 1 ELSE 0 END) AS absent_sessions,
    ROUND(
        CASE 
            WHEN COUNT(a.attendance_id) > 0 
            THEN (SUM(CASE WHEN a.status IN ('Present', 'Late') THEN 1.0 ELSE 0.0 END) * 100.0) / COUNT(a.attendance_id) 
            ELSE 0.0 
        END, 2
    ) AS attendance_percentage,
    CASE 
        WHEN COUNT(a.attendance_id) = 0 THEN 'No Data'
        WHEN (SUM(CASE WHEN a.status IN ('Present', 'Late') THEN 1.0 ELSE 0.0 END) * 100.0) / COUNT(a.attendance_id) >= 75.0 THEN 'Safe'
        WHEN (SUM(CASE WHEN a.status IN ('Present', 'Late') THEN 1.0 ELSE 0.0 END) * 100.0) / COUNT(a.attendance_id) >= 65.0 THEN 'Warning'
        ELSE 'Critical Shortage'
    END AS status_badge
FROM students s
JOIN sections sec ON s.section_id = sec.section_id
JOIN courses c ON sec.course_id = c.course_id
LEFT JOIN class_sessions cs ON cs.section_id = sec.section_id
LEFT JOIN attendance a ON a.session_id = cs.session_id AND a.student_id = s.student_id
GROUP BY s.student_id, c.course_id;

-- -----------------------------------------------------------------------------
-- VIEW 2: Pending Student Leave Applications
-- -----------------------------------------------------------------------------
CREATE VIEW IF NOT EXISTS v_pending_leave_applications AS
SELECT 
    la.application_id,
    s.roll_no,
    s.full_name AS student_name,
    sec.section_name,
    lt.type_name AS leave_type,
    la.start_date,
    la.end_date,
    CAST((julianday(la.end_date) - julianday(la.start_date) + 1) AS INTEGER) AS total_days,
    la.reason,
    la.applied_date,
    la.status
FROM leave_applications la
JOIN students s ON la.student_id = s.student_id
JOIN sections sec ON s.section_id = sec.section_id
JOIN leave_types lt ON la.leave_type_id = lt.leave_type_id
WHERE la.status = 'Pending';

-- -----------------------------------------------------------------------------
-- QUERY 1: Presentation-II Evaluated Shortage Remedial Query
-- -----------------------------------------------------------------------------
SELECT 
    s.student_id,
    s.roll_no,
    s.full_name,
    c.course_code,
    c.course_name,
    COUNT(a.attendance_id) AS total_sessions,
    SUM(CASE WHEN a.status IN ('Present', 'Late') THEN 1 ELSE 0 END) AS attended_sessions,
    SUM(CASE WHEN a.status = 'Absent' THEN 1 ELSE 0 END) AS absent_sessions,
    ROUND((SUM(CASE WHEN a.status IN ('Present', 'Late') THEN 1.0 ELSE 0.0 END) * 100.0) / COUNT(a.attendance_id), 2) AS attendance_percentage,
    (CAST((0.75 * COUNT(a.attendance_id) - SUM(CASE WHEN a.status IN ('Present', 'Late') THEN 1 ELSE 0 END)) / (1 - 0.75) AS INTEGER) + 1) AS classes_needed_for_75
FROM students s
JOIN sections sec ON s.section_id = sec.section_id
JOIN courses c ON sec.course_id = c.course_id
JOIN class_sessions cs ON cs.section_id = sec.section_id
LEFT JOIN attendance a ON a.session_id = cs.session_id AND a.student_id = s.student_id
WHERE sec.section_name = 'AIML-A (Whales)' AND c.course_code = 'CS301'
GROUP BY s.student_id, c.course_id
HAVING attendance_percentage < 75.00
ORDER BY attendance_percentage ASC;

-- -----------------------------------------------------------------------------
-- QUERY 2: Course-Wise Attendance Performance & Enrollment
-- -----------------------------------------------------------------------------
SELECT 
    c.course_code,
    c.course_name,
    d.dept_code,
    COUNT(DISTINCT cs.session_id) AS sessions_held,
    COUNT(DISTINCT s.student_id) AS enrolled_students,
    ROUND((SUM(CASE WHEN a.status IN ('Present', 'Late') THEN 1.0 ELSE 0.0 END) * 100.0) / COUNT(a.attendance_id), 2) AS avg_attendance_pct
FROM courses c
JOIN departments d ON c.department_id = d.department_id
JOIN sections sec ON sec.course_id = c.course_id
JOIN students s ON s.section_id = sec.section_id
JOIN class_sessions cs ON cs.section_id = sec.section_id
JOIN attendance a ON a.session_id = cs.session_id AND a.student_id = s.student_id
GROUP BY c.course_id
ORDER BY avg_attendance_pct DESC;

-- -----------------------------------------------------------------------------
-- QUERY 3: Faculty Workload & Session Delivery Report
-- -----------------------------------------------------------------------------
SELECT 
    f.faculty_id,
    f.full_name AS faculty_name,
    f.designation,
    d.dept_code,
    COUNT(cs.session_id) AS total_sessions_conducted,
    COUNT(DISTINCT ms.makeup_id) AS makeup_sessions_held
FROM faculty f
JOIN departments d ON f.department_id = d.department_id
LEFT JOIN class_sessions cs ON f.faculty_id = cs.faculty_id
LEFT JOIN makeup_sessions ms ON f.faculty_id = ms.faculty_id AND ms.status = 'Completed'
GROUP BY f.faculty_id
ORDER BY total_sessions_conducted DESC;

-- -----------------------------------------------------------------------------
-- QUERY 4: Faculty Leave Approval Audit
-- -----------------------------------------------------------------------------
SELECT 
    f.faculty_id,
    f.full_name AS faculty_name,
    f.designation,
    COUNT(appr.approval_id) AS total_reviews,
    SUM(CASE WHEN appr.status = 'Approved' THEN 1 ELSE 0 END) AS approved,
    SUM(CASE WHEN appr.status = 'Rejected' THEN 1 ELSE 0 END) AS rejected
FROM faculty f
JOIN leave_approvals appr ON f.faculty_id = appr.reviewed_by_faculty_id
GROUP BY f.faculty_id
ORDER BY total_reviews DESC;

-- -----------------------------------------------------------------------------
-- QUERY 5: Active Unresolved Shortage Debarment Risk List
-- -----------------------------------------------------------------------------
SELECT 
    sa.alert_id,
    s.roll_no,
    s.full_name,
    c.course_code,
    sa.attendance_percentage,
    sa.alert_level,
    sa.generated_date
FROM shortage_alerts sa
JOIN students s ON sa.student_id = s.student_id
JOIN courses c ON sa.course_id = c.course_id
WHERE sa.is_resolved = 0
ORDER BY sa.attendance_percentage ASC;
