-- ==============================================================================
-- mysql_schema.sql : MySQL 8.0+ Compatible InnoDB Schema with SIGNAL Triggers
-- Project #26: Student Attendance and Leave Approval System
-- Learner: Shaikh Humzah (Roll No: 25WU0102251) - AIML Whales
-- ==============================================================================

DROP DATABASE IF EXISTS student_attendance_db;
CREATE DATABASE student_attendance_db CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE student_attendance_db;

-- 1. Departments
CREATE TABLE departments (
    department_id INT AUTO_INCREMENT PRIMARY KEY,
    dept_name VARCHAR(100) NOT NULL UNIQUE,
    dept_code VARCHAR(20) NOT NULL UNIQUE
) ENGINE=InnoDB;

-- 2. Faculty
CREATE TABLE faculty (
    faculty_id INT AUTO_INCREMENT PRIMARY KEY,
    full_name VARCHAR(100) NOT NULL,
    email VARCHAR(100) NOT NULL UNIQUE,
    phone VARCHAR(25),
    department_id INT NOT NULL,
    designation VARCHAR(60) NOT NULL,
    CONSTRAINT fk_fac_dept FOREIGN KEY (department_id) 
        REFERENCES departments(department_id) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB;

-- 3. Courses
CREATE TABLE courses (
    course_id INT AUTO_INCREMENT PRIMARY KEY,
    course_code VARCHAR(20) NOT NULL UNIQUE,
    course_name VARCHAR(120) NOT NULL,
    credits INT NOT NULL CHECK (credits > 0),
    department_id INT NOT NULL,
    semester INT NOT NULL CHECK (semester BETWEEN 1 AND 8),
    CONSTRAINT fk_crs_dept FOREIGN KEY (department_id) 
        REFERENCES departments(department_id) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB;

-- 4. Sections
CREATE TABLE sections (
    section_id INT AUTO_INCREMENT PRIMARY KEY,
    section_name VARCHAR(60) NOT NULL,
    course_id INT NOT NULL,
    faculty_id INT NOT NULL,
    academic_year VARCHAR(20) NOT NULL,
    semester INT NOT NULL,
    CONSTRAINT fk_sec_crs FOREIGN KEY (course_id) 
        REFERENCES courses(course_id) ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT fk_sec_fac FOREIGN KEY (faculty_id) 
        REFERENCES faculty(faculty_id) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB;

-- 5. Students
CREATE TABLE students (
    student_id INT AUTO_INCREMENT PRIMARY KEY,
    roll_no VARCHAR(30) NOT NULL UNIQUE,
    full_name VARCHAR(100) NOT NULL,
    email VARCHAR(100) NOT NULL UNIQUE,
    phone VARCHAR(25),
    section_id INT NOT NULL,
    semester INT NOT NULL,
    admission_year INT NOT NULL,
    CONSTRAINT fk_stu_sec FOREIGN KEY (section_id) 
        REFERENCES sections(section_id) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB;

-- 6. Class Sessions
CREATE TABLE class_sessions (
    session_id INT AUTO_INCREMENT PRIMARY KEY,
    section_id INT NOT NULL,
    faculty_id INT NOT NULL,
    session_date DATE NOT NULL,
    time_slot VARCHAR(40) NOT NULL,
    room_no VARCHAR(30) NOT NULL,
    topic_covered VARCHAR(200) NOT NULL,
    status ENUM('Conducted', 'Scheduled', 'Cancelled') NOT NULL DEFAULT 'Conducted',
    CONSTRAINT fk_ses_sec FOREIGN KEY (section_id) 
        REFERENCES sections(section_id) ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT fk_ses_fac FOREIGN KEY (faculty_id) 
        REFERENCES faculty(faculty_id) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB;

-- 7. Attendance
CREATE TABLE attendance (
    attendance_id INT AUTO_INCREMENT PRIMARY KEY,
    session_id INT NOT NULL,
    student_id INT NOT NULL,
    status ENUM('Present', 'Absent', 'Late', 'Excused') NOT NULL,
    marked_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    remarks VARCHAR(255),
    CONSTRAINT uq_session_student UNIQUE (session_id, student_id),
    CONSTRAINT fk_att_ses FOREIGN KEY (session_id) 
        REFERENCES class_sessions(session_id) ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT fk_att_stu FOREIGN KEY (student_id) 
        REFERENCES students(student_id) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB;

-- 8. Leave Types
CREATE TABLE leave_types (
    leave_type_id INT AUTO_INCREMENT PRIMARY KEY,
    type_name VARCHAR(60) NOT NULL UNIQUE,
    max_days_allowed INT NOT NULL CHECK (max_days_allowed > 0),
    description VARCHAR(255)
) ENGINE=InnoDB;

-- 9. Leave Applications
CREATE TABLE leave_applications (
    application_id INT AUTO_INCREMENT PRIMARY KEY,
    student_id INT NOT NULL,
    leave_type_id INT NOT NULL,
    start_date DATE NOT NULL,
    end_date DATE NOT NULL,
    reason TEXT NOT NULL,
    applied_date DATE NOT NULL,
    status ENUM('Pending', 'Approved', 'Rejected') NOT NULL DEFAULT 'Pending',
    CONSTRAINT chk_dates CHECK (end_date >= start_date),
    CONSTRAINT fk_lapp_stu FOREIGN KEY (student_id) 
        REFERENCES students(student_id) ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT fk_lapp_typ FOREIGN KEY (leave_type_id) 
        REFERENCES leave_types(leave_type_id) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB;

-- 10. Leave Approvals
CREATE TABLE leave_approvals (
    approval_id INT AUTO_INCREMENT PRIMARY KEY,
    application_id INT NOT NULL UNIQUE,
    reviewed_by_faculty_id INT NOT NULL,
    decision_date DATE NOT NULL,
    status ENUM('Approved', 'Rejected') NOT NULL,
    comments VARCHAR(255),
    CONSTRAINT fk_lappr_app FOREIGN KEY (application_id) 
        REFERENCES leave_applications(application_id) ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT fk_lappr_fac FOREIGN KEY (reviewed_by_faculty_id) 
        REFERENCES faculty(faculty_id) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB;

-- 11. Makeup Sessions
CREATE TABLE makeup_sessions (
    makeup_id INT AUTO_INCREMENT PRIMARY KEY,
    original_session_id INT NULL,
    section_id INT NOT NULL,
    faculty_id INT NOT NULL,
    scheduled_date DATE NOT NULL,
    time_slot VARCHAR(40) NOT NULL,
    reason VARCHAR(255) NOT NULL,
    status ENUM('Scheduled', 'Completed', 'Cancelled') NOT NULL DEFAULT 'Scheduled',
    CONSTRAINT fk_mkup_orig FOREIGN KEY (original_session_id) 
        REFERENCES class_sessions(session_id) ON DELETE SET NULL ON UPDATE CASCADE,
    CONSTRAINT fk_mkup_sec FOREIGN KEY (section_id) 
        REFERENCES sections(section_id) ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT fk_mkup_fac FOREIGN KEY (faculty_id) 
        REFERENCES faculty(faculty_id) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB;

-- 12. Shortage Alerts
CREATE TABLE shortage_alerts (
    alert_id INT AUTO_INCREMENT PRIMARY KEY,
    student_id INT NOT NULL,
    course_id INT NOT NULL,
    attendance_percentage DECIMAL(5,2) NOT NULL CHECK (attendance_percentage BETWEEN 0 AND 100),
    alert_level ENUM('Warning', 'Critical', 'Debarred') NOT NULL,
    generated_date DATE NOT NULL,
    is_resolved TINYINT(1) NOT NULL DEFAULT 0,
    CONSTRAINT fk_alt_stu FOREIGN KEY (student_id) 
        REFERENCES students(student_id) ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT fk_alt_crs FOREIGN KEY (course_id) 
        REFERENCES courses(course_id) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB;

-- -----------------------------------------------------------------------------
-- TRIGGER 1: Signal Error if Leave Exceeds Max Days for Leave Type
-- -----------------------------------------------------------------------------
DELIMITER //
CREATE TRIGGER trg_validate_leave_duration
BEFORE INSERT ON leave_applications
FOR EACH ROW
BEGIN
    DECLARE allowed_max INT;
    SELECT max_days_allowed INTO allowed_max FROM leave_types WHERE leave_type_id = NEW.leave_type_id;
    IF (DATEDIFF(NEW.end_date, NEW.start_date) + 1) > allowed_max THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'Leave duration exceeds maximum allowable days for this category';
    END IF;
END //
DELIMITER ;

-- -----------------------------------------------------------------------------
-- TRIGGER 2: Signal Error if Marking Attendance for Cancelled Session
-- -----------------------------------------------------------------------------
DELIMITER //
CREATE TRIGGER trg_check_session_validity
BEFORE INSERT ON attendance
FOR EACH ROW
BEGIN
    DECLARE sess_status VARCHAR(20);
    SELECT status INTO sess_status FROM class_sessions WHERE session_id = NEW.session_id;
    IF sess_status = 'Cancelled' THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'Cannot mark attendance for a cancelled session';
    END IF;
END //
DELIMITER ;
