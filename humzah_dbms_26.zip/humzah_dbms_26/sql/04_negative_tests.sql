-- ==============================================================================
-- 04_negative_tests.sql : Intentional Violation Statements for Live Constraint Testing
-- Project #26: Student Attendance and Leave Approval System
-- Learner: Shaikh Humzah (Roll No: 25WU0102251) - AIML Whales
-- ==============================================================================
-- RUN THESE QUERIES LIVE DURING VIVA VOCE TO PROVE RELATIONAL INTEGRITY

PRAGMA foreign_keys = ON;

-- -----------------------------------------------------------------------------
-- TEST 1: Unique Constraint Violation on Student Roll Number
-- EXPECTED: Error: UNIQUE constraint failed: students.roll_no
-- -----------------------------------------------------------------------------
INSERT INTO students (roll_no, full_name, email, phone, section_id, semester, admission_year)
VALUES ('25WU0102251', 'Duplicate Humzah', 'dup.humzah@univ.edu', '+91 99999 99999', 1, 4, 2024);

-- -----------------------------------------------------------------------------
-- TEST 2: Foreign Key Violation (Inserting Student into Non-Existent Section 999)
-- EXPECTED: Error: FOREIGN KEY constraint failed
-- -----------------------------------------------------------------------------
INSERT INTO students (roll_no, full_name, email, phone, section_id, semester, admission_year)
VALUES ('25WU0102998', 'Ghost Student', 'ghost@univ.edu', '+91 99999 11111', 999, 4, 2024);

-- -----------------------------------------------------------------------------
-- TEST 3: Composite Unique Constraint Violation on Attendance
-- (Cannot record attendance twice for the same student in the same session)
-- EXPECTED: Error: UNIQUE constraint failed: attendance.session_id, attendance.student_id
-- -----------------------------------------------------------------------------
INSERT INTO attendance (session_id, student_id, status, remarks)
VALUES (1, 1, 'Present', 'Duplicate attempt to mark Shaikh Humzah for Session 1');

-- -----------------------------------------------------------------------------
-- TEST 4: Domain Check Constraint Violation on Attendance Status
-- (Valid values: 'Present', 'Absent', 'Late', 'Excused')
-- EXPECTED: Error: CHECK constraint failed: status IN ('Present', 'Absent', 'Late', 'Excused')
-- -----------------------------------------------------------------------------
INSERT INTO attendance (session_id, student_id, status)
VALUES (14, 1, 'Holiday');

-- -----------------------------------------------------------------------------
-- TEST 5: Temporal Logic Check Constraint Violation on Leave Application
-- (End date cannot precede start date)
-- EXPECTED: Error: CHECK constraint failed: end_date >= start_date
-- -----------------------------------------------------------------------------
INSERT INTO leave_applications (student_id, leave_type_id, start_date, end_date, reason, applied_date)
VALUES (1, 1, '2026-10-15', '2026-10-10', 'Time traveler leave application', '2026-10-07');

-- -----------------------------------------------------------------------------
-- TEST 6: Check Constraint Violation on Academic Course Credits
-- (Credits must be strictly positive)
-- EXPECTED: Error: CHECK constraint failed: credits > 0
-- -----------------------------------------------------------------------------
INSERT INTO courses (course_code, course_name, credits, department_id, semester)
VALUES ('CS999', 'Zero Credit Dummy Course', 0, 1, 4);

-- -----------------------------------------------------------------------------
-- TEST 7: Percentage Boundary Check Constraint on Shortage Alerts
-- (Percentage must be between 0.0 and 100.0)
-- EXPECTED: Error: CHECK constraint failed: attendance_percentage BETWEEN 0 AND 100
-- -----------------------------------------------------------------------------
INSERT INTO shortage_alerts (student_id, course_id, attendance_percentage, alert_level, generated_date)
VALUES (1, 1, 125.0, 'Warning', '2026-10-07');
