#!/usr/bin/env python3
"""
Main entry point for DBMS Review 3 Project:
Student Attendance and Leave Approval System (Topic #26)
Student: Shaikh Humzah (Roll No: 25WU0102251)
"""

import sys
import os

# Add root and app directory to path
root_dir = os.path.dirname(os.path.abspath(__file__))
if root_dir not in sys.path:
    sys.path.insert(0, root_dir)

from app.database import init_database, seed_database, DB_PATH
from app.server import run_server, PORT

if __name__ == "__main__":
    print("=" * 70)
    print("Starting Student Attendance & Leave Approval System (Topic 26)...")
    print("=" * 70)
    init_database()
    # Check if database has data
    import sqlite3
    conn = sqlite3.connect(DB_PATH)
    count = conn.execute("SELECT COUNT(*) FROM students").fetchone()[0]
    conn.close()
    if count == 0:
        print("Database is empty. Populating with 270+ seed records...")
        seed_database()
    else:
        print(f"Database ready with existing records (students: {count}).")

    port = int(os.environ.get("PORT", PORT))
    run_server(port)
