# Presentation-I: Problem Identification and Conceptual Design
## Course: Database Management Systems (DBMS) Course Project
### Topic #26: Student Attendance and Leave Approval System

---

### Student Information
- **Name:** Shaikh Humzah
- **Roll Number:** 25WU0102251
- **Section:** AIML Whales
- **Degree:** B.Tech in Artificial Intelligence & Machine Learning
- **Semester:** 4th Semester (Academic Year 2025–2026)

---

## 1. Problem Identification & Context
In tertiary educational institutions, tracking student attendance, evaluating eligibility for university examinations, and managing leaves of absence are mission-critical administrative workflows. 

Traditional paper registers, disparate spreadsheets, and disconnected filing systems present critical systemic challenges:
1. **Consolidation Latency:** Manual compilation of attendance percentages at the end of each month is laborious and delays identification of at-risk students.
2. **Data Inconsistency:** Inconsistent status records between faculty roll-call sheets and official medical or on-duty leave approvals.
3. **Shortage Alert Deficit:** Students frequently discover attendance shortages (< 75%) right before examination hall-ticket issuance, preventing timely remedial or makeup sessions.
4. **Fraud & Proxy Risk:** Lack of strict uniqueness constraints per class session and student permits duplicate or unauthorized entries.

## 2. Project Scope & Objectives
The goal of this project is to architect and implement an enterprise-grade, 3NF-normalized relational database management system (RDBMS) paired with an Apple-inspired minimalist user interface to automate and integrate the entire attendance lifecycle.

### Key Objectives:
- **Course-Wise & Section-Wise Tracking:** Maintain granular lecture and laboratory attendance records across distinct academic departments, courses, sections, and faculty.
- **Enforce Business Constraints:**
  - Exactly one attendance record per student per class session (`UNIQUE(session_id, student_id)`).
  - Valid attendance status domain (`Present`, `Absent`, `Late`, `Excused`).
  - Attendance percentages strictly bound between `0.00%` and `100.00%`.
  - Leave duration validity (`end_date >= start_date`).
- **Multi-Tier Leave Workflow:** Facilitate structured leave application submission by students with multi-tiered faculty review and transactional auditing.
- **Shortage Detection & Alerts:** Automatically calculate cumulative percentages and trigger stratified shortage alerts (`Warning`, `Critical`, `Debarred`).
- **Remedial & Makeup Sessions:** Link makeup class sessions to compensate for faculty leaves or missed academic topics.

## 3. Stakeholders & User Roles
1. **Students:** View personal attendance percentages, course breakdown, submit leave applications with justifications, and track approval status.
2. **Faculty Members:** Create class sessions, conduct live digital roll-calls, review leave applications with remarks, and schedule makeup classes.
3. **Head of Department (HOD) & Academic Deans:** Monitor department-wide attendance health, evaluate shortage reports, and make final debarment determinations.
4. **Database Administrator (DBA):** Maintain relational integrity, enforce foreign key cascades, optimize queries via indexes, and ensure transaction durability.

## 4. Functional Requirements
- **FR1: Course & Section Allocation:** Assign courses, academic years, semesters, and faculty coordinators to distinct student sections.
- **FR2: Live Attendance Roll-Call:** Record and mutate student attendance status per session with sub-second feedback.
- **FR3: Student Leave Lifecycle:** Submission, validation of date intervals, and faculty decision-making (`Approved` / `Rejected`).
- **FR4: Automated Percentage Aggregation:** Provide live aggregate calculation `(Attended / Conducted) * 100` via database views.
- **FR5: Shortage & Alert Management:** Automatically flag records with attendance `< 75%` and categorize severity.
- **FR6: Administrative Reporting:** Provide tabular reporting for course summaries, monthly attendance trends, and pending leaves.

## 5. Non-Functional Requirements
- **Data Integrity:** ACID-compliant relational transactions with foreign key cascades and domain check constraints.
- **Performance:** Sub-10ms query execution time on join queries and aggregate views.
- **Minimalist Light Mode UI:** Apple Human Interface Guidelines compliance, high legibility, and responsive interaction design.
- **Zero-Dependency Deployment:** Instant portability across macOS and Linux environments.
