# Presentation-III: Working UI Demonstration & Live CRUD Walkthrough
## Topic #26: Student Attendance and Leave Approval System
**Learner:** Shaikh Humzah (Roll No: 25WU0102251) · AIML Whales
**Evaluator Reference:** Presentation-III Live Evaluation (5 Marks)

---

## 1. Quickstart: Launching the Application
To run the live application on macOS or Linux:

```bash
# Clone repository and navigate to project root
cd /path/to/DBMS-Course-Project

# Run the zero-dependency Python server
python3 run.py
```

- **Web UI URL:** `http://localhost:8000`
- **Database Backend:** SQLite 3.x (with matching MySQL 8.0 schema & seed scripts included in `Presentation-II/student_attendance_system_mysql.sql`)
- **Total Initial Records:** 270 rows across 12 normalized tables.

---

## 2. Live CRUD Demonstration Procedure for Review-3 Viva

### STEP 1: Viewing Database Records (READ)
1. Open `http://localhost:8000` in Safari or Chrome.
2. Note the **top-level KPI metrics** on the Dashboard:
   - Overall Attendance Rate: `~88.9%`
   - Enrolled Students: `24`
   - Total Database Records: `270`
3. Click **"Database Tables"** in the sidebar.
   - Choose `students`, `class_sessions`, or `attendance` from the dropdown.
   - Show the evaluator the exact table columns, types, primary keys, and data rows directly retrieved from the database.

---

### STEP 2: Live Insertion of Records (CREATE)
1. Navigate to the **"Students (CRUD)"** view from the sidebar.
2. Note the student count (24).
3. Click the **"+ Add Student"** button.
4. Enter the sample record:
   - **Roll Number:** `25WU0102299`
   - **Full Name:** `Zaid Al-Mansoor`
   - **Email:** `zaid.m@univ.edu`
   - **Phone:** `+91 91234 99999`
   - **Section:** `AIML-A (Whales)`
   - **Semester:** `4`
5. Click **"Save to Database"**.
6. **Live Verification Shown to Evaluator:**
   - The top Dynamic Island capsule drops down: *"Student Inserted into Database — Zaid Al-Mansoor (25WU0102299) saved"*.
   - The newly created row `#25` immediately appears with a **smooth blue glow highlight**.
   - Switch to **"Database Tables Inspector"** -> Table `students`: The row count is now **25** (Total DB Records updated to **271**).

---

### STEP 3: Live Real-Time Mutation (UPDATE / ATTENDANCE UPSERT)
1. Navigate to **"Live Attendance"** in the sidebar.
2. Select Session `#1` (`Introduction to Relational DBMS & ER Modeling`).
3. Locate student **Shaikh Humzah (25WU0102251)** or **Zaid Al-Mansoor**.
4. Click the **"Late"** pill or **"Absent"** pill.
5. **Live Verification:**
   - The status pill toggles instantaneously.
   - A live HTTP request updates the database `attendance` table using `ON CONFLICT(session_id, student_id) DO UPDATE SET status = ...`.
   - The row flashes green/blue.
   - The attendance percentage in the Student view updates in real time!

---

### STEP 4: Live Deletion of Records (DELETE)
1. Go back to **"Students (CRUD)"** view.
2. Find the newly created test student `25WU0102299 (Zaid Al-Mansoor)`.
3. Click the red **"Delete"** button.
4. Confirm the alert prompt.
5. **Live Verification:**
   - The row scales down and smoothly animates out of view.
   - The Dynamic Island alerts: *"Student Deleted from Database — Record #25 removed. Remaining: 24"*.
   - Navigate to **"Database Tables Inspector"**: The `students` table count has decremented back to **24** and total records back to **270**.

---

### STEP 5: Interactive SQL Console Demonstration
1. Click **"Live SQL Console"** in the sidebar or top bar.
2. Click any of the query presets:
   - `SELECT * FROM v_student_attendance_summary LIMIT 10;`
   - `SELECT * FROM students s JOIN sections sec ON s.section_id = sec.section_id JOIN courses c ON sec.course_id = c.course_id;`
3. Click **"Execute SQL"** (or press `Cmd + Enter`).
4. Show the evaluator the exact execution time in milliseconds (e.g. `2.14 ms`) and the live tabular result set.

---

## 3. UI Design Principles & Apple HIG Compliance
- **Minimalist Light Palette:** High-contrast pure white (`#FFFFFF`) card surfaces on macOS canvas (`#F5F5F7`).
- **Typography:** Apple San Francisco font stack (`-apple-system, SF Pro Display, SF Pro Text`) with optical sizing and tight tracking (`-0.015em`).
- **Translucent Frosted Glass:** Header with `backdrop-filter: blur(20px)` and subtle 1px border separation.
- **Dynamic Feedback:** Apple Dynamic Island notification banner giving immediate confirmation of SQL statements executed.
