# Presentation-III: UI Screen Architecture & Before/After CRUD Proof
## Topic #26: Student Attendance and Leave Approval System
**Learner:** Shaikh Humzah (Roll No: 25WU0102251) · AIML Whales

---

## 1. Screen 1: Dashboard Overview (Initial State)
- **Top Bar:** Frosted glass header, Live DBMS Status pill (`● LIVE DBMS`), Student credentials (`Shaikh Humzah · 25WU0102251`).
- **Key Performance Indicators:**
  - Overall Attendance Rate: `88.9%`
  - Enrolled Students: `24`
  - Conducted Sessions: `15`
  - Total Database Records: `270`
- **Widgets:**
  - Table Counts Live Inventory (12 normalized tables with real-time badges).
  - Shortage Action Items (< 75% attendance alert roster).

---

## 2. Screen 2: Students Management — BEFORE & AFTER INSERTION

### Before Insertion:
- Total Students: `24`
- Total Database Records: `270`
- Last Student ID: `#24` (`Manthena Naga Sri Rohan`)

### Action:
User clicks `+ Add Student` and enters:
- Roll: `25WU0102299` | Name: `Zaid Al-Mansoor` | Email: `zaid.m@univ.edu` | Section: `AIML-A (Whales)`

### After Insertion:
- Total Students: `25` (Incremented by 1)
- Total Database Records: `271`
- Dynamic Island Notification: `✓ Student Inserted into Database — Zaid Al-Mansoor (25WU0102299) saved`
- New Row: `#25` appears at the bottom with high-visibility CSS highlight pulse.
- Database Tables Inspector confirms: Table `students` has 25 rows.

---

## 3. Screen 3: Live Attendance Sheet — REAL-TIME STATUS MUTATION

### Initial State:
- Session `#1`: Introduction to Relational DBMS & ER Modeling
- Shaikh Humzah (Roll: `25WU0102251`): Status `Present`

### Live Mutation Action:
Faculty taps `Late` pill for student Shaikh Humzah.

### Database Change Reflected:
- HTTP `POST /api/attendance/mark` executes atomic UPSERT on `attendance` table.
- Row badge immediately transitions from green `Present` to orange `Late`.
- Dynamic Island notification confirms: `✓ Attendance Updated Live — Shaikh Humzah marked as 'Late' in SQLite`.

---

## 4. Screen 4: Students Management — BEFORE & AFTER DELETION

### Before Deletion:
- Total Students: `25`
- Target Row: `#25` (`Zaid Al-Mansoor`, `25WU0102299`)

### Action:
User clicks red `Delete` button on row `#25` and confirms dialog.

### After Deletion:
- Row smoothly scales down and vanishes from DOM.
- Total Students: `24` (Decremented by 1).
- Total Database Records: `270`.
- Dynamic Island Notification: `✕ Student Deleted from Database — Record #25 removed. Remaining: 24`.
- Database Tables Inspector confirms: Table `students` row count decremented back to 24.

---

## 5. Screen 5: Dedicated Database Tables Inspector
- Dropdown selector featuring all 12 schema tables:
  1. `departments` (4 rows)
  2. `faculty` (8 rows)
  3. `courses` (6 rows)
  4. `sections` (6 rows)
  5. `students` (24 rows)
  6. `class_sessions` (15 rows)
  7. `attendance` (156 rows)
  8. `leave_types` (5 rows)
  9. `leave_applications` (16 rows)
  10. `leave_approvals` (12 rows)
  11. `makeup_sessions` (8 rows)
  12. `shortage_alerts` (10 rows)
- Displays table column schema pills with primary key indicators (`🔑`).
- Allows direct row insertion and deletion with immediate count update.

---

## 6. Screen 6: Interactive SQL Query Console
- Raw SQL command input area.
- 1-click preset buttons:
  - 3-Table JOIN query
  - Attendance summary view
  - Shortage audit query
  - Group By aggregation
- Execution metrics bar reporting precise execution time in milliseconds (e.g., `1.85 ms`).
- Formatted tabular data grid showing records returned directly by SQLite engine.
