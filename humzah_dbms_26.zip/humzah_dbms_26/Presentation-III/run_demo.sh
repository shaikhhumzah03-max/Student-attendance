#!/bin/bash
# ==============================================================================
# DBMS Course Project — Topic 26: Student Attendance & Leave Approval System
# Student: Shaikh Humzah (Roll No: 25WU0102251) - AIML Whales
# Review 3 Live Demo Launcher
# ==============================================================================

echo "======================================================================"
echo " Starting AttendSync Live DBMS Server..."
echo " Topic #26: Student Attendance and Leave Approval System"
echo " Shaikh Humzah (25WU0102251) — AIML Whales"
echo "======================================================================"

# Determine directory
DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )/.." && pwd )"
cd "$DIR"

# Run Python Server
python3 run.py
